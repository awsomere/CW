package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ChildPermissions_Checked extends WrapperClass{

	 public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "BookParent";
	  String ChildEntity = "BookChild";
	  String GrantChildEntity = "BookGrantChild";
	  String GreatGrantChildEntity = "BookGreatGrantChild";
	  
	  @Test(priority=94, enabled = true)
	  public void EditPermission_GlobalRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(2000);
	        
	       /* //Select Controls - Global/Media sub-module under Risk determination Module 
	        assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
	        Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
	        Thread.sleep(3000);
	        Thread.sleep(5000);
	        //Thread.sleep(3000);		  
		  
		    // Select Child Entity from drop down
	 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   Thread.sleep(5000);
		   
		  //Enter Created Entity Name in Search box
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		   //Reporter.log("Enter Created Entity Name in Search box | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   
		   //Select the Searched Entity
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   
		 //Click on Control Type Filter drop-down
	   	     clickByXpath("//*[@id='control-type']");
	   	     Thread.sleep(3000);
	   	     clickByXpath("//*[@id='cw-panelbar']/div/div[3]/cw-drop-list[1]/div/ul/li[2]/a");
	   	     Thread.sleep(5000);
	   	     Thread.sleep(5000); 
	   	     Thread.sleep(5000); */
	   	     
	      	// Click on Notes button 
	   	     assertTextXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
	   	     clickByXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
	   	     //Reporter.log("Click on Notes button | ");
	   	     Thread.sleep(5000);
	   	     Thread.sleep(3000);    
	   	     
	      	// Click on Listed Notes
	   	     assertTextXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
	   	     clickByXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
	   	     //Reporter.log("Click on Notes button | ");
	   	     Thread.sleep(5000);
	   	     Thread.sleep(3000);  
	   	     	   	     
	     	// Click on Edit button
	   	     clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[2]");
	   	     //Reporter.log("Click on Notes button | ");
	   	     Thread.sleep(5000);
	   	     Thread.sleep(3000);  
	   	     
	       	//Enter Created Entity Name in Search box
			   assertTextXpath("//*[@id='DTE_Field_text']");
			   sendvaluebyxpath("//*[@id='DTE_Field_text']", "Edit Notes using Child EditPermission");
			   //Reporter.log("Enter Created Entity Name in Search box | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);	   	     
	   	 
			// Click on Save button
			clickByXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
			//Reporter.log("Click on Notes button | ");
			
			Thread.sleep(2000);  
			
	  }
			
	  @Test(priority=95, enabled = true)
	  public void DeletePermission_GlobalRelated() throws IOException, InterruptedException {
	   
		  //Thread.sleep(5000);
		 		  
		// Click on Delete button
		  clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[3]");
		  //Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);  
		  
		// Click on Delete button in Delete Confirmation pop-up
		  clickByXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
		  //Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);		
			
			// Click on CLose button
			clickByXpath("html/body/div[4]/div/div/div[1]/button");
			//Reporter.log("Click on Notes button | ");
			Thread.sleep(5000);
			//Thread.sleep(3000);      
	   	     
	  }
	  
	  @Test(priority=96, enabled = true)
	  public void EditPermission_MediaRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(3000);
		  		  
		  // Select Risk Questionnaire list sub-module under Risk Determination Module
	        try {
	        	assertTextLink("Risk Questionnaire List");
	            clickBylinktext("Risk Questionnaire List");
	            Reporter.log("Select Risk Questionnaire List | ");
	       }catch(Exception e)
		    {
		        e.printStackTrace();
		        Reporter.log("Select Risk Questionnaire List doesn't reached | ");
		    }
	        Thread.sleep(5000);
	        Thread.sleep(3000);
	        //Thread.sleep(3000);
	  
	  // Click on 'Review' button of Media/Asset
      try {
      	assertTextXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
	        clickByXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
	        Reporter.log("Click on 'Review' button of Media/Asset | ");
      }catch(Exception e)
	    {
	         e.printStackTrace();
	         Reporter.log("Click on 'continue' button of Media/Asset doesn't work | ");
	    }
      Thread.sleep(5000);
      Thread.sleep(5000);
           
      //Expand the Controls
      assertTextXpath("//td[2]/span[1]");
      clickByXpath("//td[2]/span[1]");
      //Reporter.log("Expand the Controls | ");
      Thread.sleep(5000); 
        
     //Click on Notes button to add text
      assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a/i");
      clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a/i");
      //Reporter.log("Click on Notes button to add text | ");
      Thread.sleep(5000);
      Thread.sleep(3000);
      
	// Click on Listed Notes
      assertTextXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
      clickByXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
      //Reporter.log("Click on Notes button | ");
      Thread.sleep(5000);
      Thread.sleep(3000);  
  	     	   	     
    // Click on Edit button
      clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[2]");
      //Reporter.log("Click on Notes button | ");
      Thread.sleep(5000);
      Thread.sleep(3000);  
      
      //Enter Created Entity Name in Search box
      assertTextXpath("//*[@id='DTE_Field_text']");
      sendvaluebyxpath("//*[@id='DTE_Field_text']", "Edit Notes using Child EditPermission");
      //Reporter.log("Enter Created Entity Name in Search box | ");
      Thread.sleep(3000);
      //Thread.sleep(3000);	   	     
  	 	
	   // Click on Save button
	   clickByXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
	   //Reporter.log("Click on Notes button | "); 
	  }
	  
	  @Test(priority=97, enabled = true)
	  public void DeletedPermission_MediaRelated() throws IOException, InterruptedException {
	    
		  Thread.sleep(3000);	 
		  
		// Click on Delete button
		  clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[3]");
		  //Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  Thread.sleep(3000);  
			  
		// Click on Delete button in Delete Confirmation pop-up
		  clickByXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
		  //Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  Thread.sleep(3000);	
		  
		//Click on Close button in popup
		  assertTextXpath("//div[4]/div/div/div[1]/button");
		  clickByXpath("//div[4]/div/div/div[1]/button");
		  //Reporter.log("Click on Close button in popup | ");
		  Thread.sleep(5000);
		  Thread.sleep(3000);	   
		  
		  //Expand the Controls
		  assertTextXpath("//td[2]/span[1]");
		  clickByXpath("//td[2]/span[1]");
		  //Reporter.log("Expand the Controls | ");
		  Thread.sleep(5000); 
		  
		  // Click on 'GoTo next Thread' button
		  try {
			  assertTextXpath("//*[@id='rMedia']");
			  clickByXpath("//*[@id='rMedia']");
			  //Reporter.log("First page - Click on 'GoTo next Thread' button | ");
		      }catch(Exception e)
			    {
			        e.printStackTrace();
			        Reporter.log("Click on 'GoTo next Thread' button doesn't reached | ");
			    }
		      Thread.sleep(5000);
		      Thread.sleep(5000);
	  }
	  
	  @Test(priority=98, enabled = true)
	  public void EditPermission_RiskEvalation() throws IOException, InterruptedException {
	  
	  
		  //Thread.sleep(5000);
		  //Thread.sleep(5000);
		  
		    //Click on Risk Response Module
	 	    assertTextXpath("//*[@id='sidebar-left']/ul/li[5]/a/span[2]");
	        clickByXpath("//*[@id='sidebar-left']/ul/li[5]/a/span[2]");
	        Reporter.log("Click on Risk Response Module | ");
	        Thread.sleep(5000);
	        //Thread.sleep(3000);
	        //Thread.sleep(3000);
	        //Thread.sleep(3000);
	        
	        //Click on Risk Response List Sub-module
	        assertTextLink("Risk Response List");
	        clickBylinktext("Risk Response List");
	        Reporter.log("Click on Risk Response List Sub-module | ");
	        Thread.sleep(5000);
	        Thread.sleep(3000); 
	  
	        //Click on TBD Button 
		       assertTextXpath("//tr[2]/td[9]/div/div/cw-section-change-button-caller/div/span");
		       clickByXpath("//tr[2]/td[9]/div/div/cw-section-change-button-caller/div/span");
		       //Reporter.log("Click on TBD Button | ");
		       Thread.sleep(5000);
		       Thread.sleep(3000);
		       //Thread.sleep(3000);
		            		       
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       
		     //Click on ImplementationPlanning Button 
		       assertTextXpath("//*[@id='rtIp']");
		       clickByXpath("//*[@id='rtIp']");
		      // Reporter.log("Click on ImplementationPlanning Button | ");
		       Thread.sleep(5000);
		       Thread.sleep(5000);
		       
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       
		       
		     //Enter some text in Description textarea
		       sendvaluebyxpath("//*[@id='ipData']/tbody/tr[1]/td[4]/cw-rr-text-area/div/textarea", "EditDesc using Child EditPermission");
		       Reporter.log("Enter some text in Description textarea | ");
		       Thread.sleep(3000);
		       
		       //Enter some text in Plans for Monitoring Effectiveness textarea
		       sendvaluebyxpath("//*[@id='ipData']/tbody/tr[1]/td[5]/cw-rr-text-area/div/textarea", "Editplans using Child Editpermission");
		       Reporter.log("Enter some text in Plans for Monitoring Effectiveness textarea | ");
		       Thread.sleep(5000);
		       
		       //Click on Implementation Manager drop-down
		       clickByXpath("//*[@id='ipData']/tbody/tr[1]/td[6]/cw-rr-planning-choices/div/button");
		       Reporter.log("Click on Implementation Manager drop-down | ");
		       Thread.sleep(3000);
		       
		       // Select any option from Implementation Manager drop-down
		       clickByXpath("//*[@id='ipData']/tbody/tr[1]/td[6]/cw-rr-planning-choices/div/ul/li[2]/a");
		       Reporter.log("Select any option from Implementation Manager drop-down| ");
		       Thread.sleep(5000);
		       
		       //Select Date from Implementation Due Date 
		       sendvaluebyxpath("//td[7]/div/input", "01/02/2018");
		       Reporter.log("Select Date from Implementation Due Date  | ");
		       Thread.sleep(5000);
		       //Thread.sleep(3000);
		       
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       Thread.sleep(2000);
		       
		     //Click on Risk Likelihood drop-down
		       assertTextXpath("//cw-risk-choices/div/button");
		       clickByXpath("//cw-risk-choices/div/button");
		       Reporter.log("Click on Risk Likelihood drop-down | ");
		       Thread.sleep(3000);
		       
		       //Select Moderate Option from Risk Likelihood drop-down
		       assertTextXpath("//cw-risk-choices/div/ul/li[4]/a");
		       clickByXpath("//cw-risk-choices/div/ul/li[4]/a");
		       Reporter.log("Select Moderate Option from Risk Likelihood drop-down | ");
		       Thread.sleep(5000);
		       
		       //Click on Keep Rating from Pop-up window
		       assertTextXpath("//div[3]/button[2]");
		       clickByXpath("//div[3]/button[2]");
		       Reporter.log("Click on Keep Rating from Pop-up window | ");
		       Thread.sleep(5000);
		       Thread.sleep(3000);
		       //Thread.sleep(3000);
		       
		       //Click on Risk Impact drop-down
		       assertTextXpath("//*[@id='_residualData']/div[3]/div/cw-risk-choices/div/button");
		       clickByXpath("//*[@id='_residualData']/div[3]/div/cw-risk-choices/div/button");
		       Reporter.log("Click on Risk Impact drop-down | ");
		       Thread.sleep(3000);
		       
		       //Select Major Option from Risk Likelihood drop-down
		       assertTextXpath("//*[@id='_residualData']/div[3]/div/cw-risk-choices/div/ul/li[5]/a");
		       clickByXpath("//*[@id='_residualData']/div[3]/div/cw-risk-choices/div/ul/li[5]/a");
		       Reporter.log("Select Major Option from Risk Likelihood drop-down | ");
		       Thread.sleep(5000);
		       
		       //Click on Keep Rating from Pop-up window
		       assertTextXpath("//div[3]/button[2]");
		       clickByXpath("//div[3]/button[2]");
		       Reporter.log("Click on Keep Rating from Pop-up window | ");
		       Thread.sleep(5000);
		       Thread.sleep(3000);
		       //Thread.sleep(3000);
		       
	  }
		       
	  @Test(priority=99, enabled = true)
	  public void DeletePermission_RiskEvalation() throws IOException, InterruptedException {       

		  Thread.sleep(3000);	  
		  
		// Select added Risk notes icon
	       clickByXpath("//*[@id='rtData']/div[2]/div/div[1]/div[1]/div/div/a");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);	       
	       
	    // Select any Listed Notes
	       clickByXpath("//*[@id='note-details-table']/tbody/tr[1]/td[2]");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	  
	    // Click on Delete button
	       clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[3]");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	       clickByXpath("html/body/div[7]/div/div/div/div[4]/div[3]/button[1]");
	       Thread.sleep(5000);
	       
	       // Select Close button
	       clickByXpath("html/body/div[5]/div/div/div[1]/button");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	       
	       //Click on Risk Response List Sub-module
	       assertTextLink("Risk Response List");
	       clickBylinktext("Risk Response List");
	       Reporter.log("Click on Risk Response List Sub-module | ");
	       Thread.sleep(5000);
	       Thread.sleep(3000);

	  }
	  
	  @Test(priority=100, enabled = true)
	  public void EditPermission_RiskImplementation() throws IOException, InterruptedException {       
	
		  
		  //Click on Risk Action Plan Sub-module
		  assertTextLink("Risk Action Plan");
		  clickBylinktext("Risk Action Plan");
		  Reporter.log("Click on Risk Action Plan Sub-module | ");
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  
		  
		  // Select Priority from drop-down
	       selectByXpath_Visibletext("//td[6]/div/select","Medium");
	       Reporter.log("Select Priority from drop-down | ");
	       Thread.sleep(3000);
	       
	     //Select Completed Date
	       sendvaluebyxpath("//td[8]/div/input", "24/06/2018");
	       Reporter.log("Select Completed Date | ");
	       Thread.sleep(3000);
	       
	       Thread.sleep(5000);
			//Click on Notes button to add text
	       assertTextXpath("//*[@id='content']/tr[1]/td[10]/span/a");
	       clickByXpath("//*[@id='content']/tr[1]/td[10]/span/a");
	       //Reporter.log("Click on Notes button to add text | ");
	       Thread.sleep(5000);
	       Thread.sleep(3000);       
	       	       
	    // Select any Listed Notes
	       clickByXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	  
	    // Click on Edit button
	       clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[1]");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	       
	     //Enter edit text
	       sendvaluebyxpath("//*[@id='DTE_Field_text']", "Edit notes using Edit Permission");
	       Reporter.log("Select Date from Implementation Due Date  | ");
	       Thread.sleep(5000);
	       //Thread.sleep(3000);
	      
	    // Click on Save button 
	       clickByXpath("html/body/div[7]/div/div/div/div[4]/div[3]/button[1]");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	       	       
	  
	  }
	  
	  @Test(priority=101, enabled = true)
	  public void DeletePermission_RiskImplementation() throws IOException, InterruptedException {       
	  
		  Thread.sleep(5000);		  
	  
	    // Click on Delete button
	       clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[3]");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(3000);
	      
	    // Click on Delete button 
	       clickByXpath("html/body/div[7]/div/div/div/div[4]/div[3]/button[1]");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	       	       
	    // Select Close button
	       clickByXpath("html/body/div[5]/div/div/div[1]/button");
	       Reporter.log("Select any option from Implementation Manager drop-down| ");
	       Thread.sleep(5000);
	  }

}
