package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Child_AssetRelated extends WrapperClass{
	
	public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "ChildEntityStage";
	  String ChildEntity = "GrantChildEntityStage";
	  
	  
	  @Test(priority=131, enabled = true)
	  public void Navigate_ParentEntity_AssetRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  
		  //Select the Asset module at sidebar-left
		   assertTextXpath("//*[@id='sidebar-left']/ul/li[3]/a/span[2]");
		   clickByXpath("//*[@id='sidebar-left']/ul/li[3]/a/span[2]");  	
		   Reporter.log("Selected the Asset module at sidebar-left | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);  
        
		   // Select the Media/Asset Groups sub-modules listed in Asset Inventory List	  
		    assertTextXpath("//*[@id='sidebar-left']/ul/li[3]/ul/li[3]/a");
	      clickByXpath("//*[@id='sidebar-left']/ul/li[3]/ul/li[3]/a");
	      Reporter.log("Select the Media/Asset Groups sub-modules listed in Asset Inventory List | ");
		    Thread.sleep(3000); 
		    
		   // Select Parent Entity from drop down
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    Thread.sleep(5000);
		    
		    //Enter Created Entity Name in Search box
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		    //Reporter.log("Enter Created Entity Name in Search box | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Select the Searched Entity
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		    //Reporter.log("Select the Searched Entity | ");
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(3000);
		    
	  }
	  
	  
	  @Test(priority=132, enabled = true)
	  public void Parent_CascdeIcon_AssetRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);	    
	   	   /* //Click on Parent cascade Icon
	   	     assertTextXpath("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[2]/cw-cascade/span/span/button");
	   	     clickByXpath("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[2]/cw-cascade/span/span/button");
	   	     Thread.sleep(5000);		   	 
	   	     
	   	     //Click on Close button in Parent cascade Icon
	   	     assertTextXpath("html/body/div[4]/div/div/div[1]/button");
	   	     clickByXpath("html/body/div[4]/div/div/div[1]/button");*/
	   	     Thread.sleep(5000); 
	   	     
	  }
	   	     
	   	  @Test(priority=133, enabled = true)
		  public void Parent_MediaLabelName_AssetRelated() throws IOException, InterruptedException {
		   
			  Thread.sleep(5000);	    
	   	     
	   	      // Get the Parent MediaLabelNameValue
			   ParentMediaLabelNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[3]");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(3000);	
			   
	   	  }
	   	  
	  @Test(priority=134, enabled = true)
	  public void Parent_AssetName_AssetRelated() throws IOException, InterruptedException {
		   
			  Thread.sleep(5000);	    
			   
			// Get the Parent AssetNameValue
			   ParentAssetNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[4]/ul/li");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(3000);	
	   	 }
	   	 
	 @Test(priority=135, enabled = true)
		  public void Parent_MediaName_AssetRelated() throws IOException, InterruptedException {
		   
			  Thread.sleep(5000);	    
			   
			// Get the Parent MediaNameValue
			   ParentMediaNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[2]");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(3000);	
			   
	 }
	 
			   	    
	 @Test(priority=136, enabled = true)
	  public void Navigate_ChildEntity_AssetRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);	    		    
		  //Click on the Created new Entity drop-down from Header 
		  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		  clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		  //Reporter.log("Click on the Created new Entity drop-down from Header | ");
		  Thread.sleep(3000);
		  
		  //Enter Created Entity Name in Search box
		  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		  sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		  //Reporter.log("Enter Created Entity Name in Search box | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  //Select the Searched Entity
		  clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		  //Reporter.log("Select the Searched Entity | ");
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(3000);
	 }
	 
	 @Test(priority=137, enabled = true)
	  public void Child_CascdeIcon_AssetRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);	    
		  /*//Click on Child cascade Icon
		  assertTextXpath("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[2]/cw-cascade/span/span/button");
		  clickByXpath("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[2]/cw-cascade/span/span/button");
		  Thread.sleep(5000);		   	 
		  
		  //Click on Close button in Child cascade Icon
		  assertTextXpath("html/body/div[4]/div/div/div[1]/button");
		  clickByXpath("html/body/div[4]/div/div/div[1]/button");
		  Thread.sleep(5000); */
		  
	 }
	 
	 @Test(priority=138, enabled = true)
	  public void Child_MediaLabelName_AssetRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);	    
		   	     
		  // Get the Parent MediaLabelNameValue
		  ChildMediaLabelNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[3]");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);	
		  
	 }
	 
	 @Test(priority=139, enabled = true)
	  public void Child_AssetName_AssetRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);	    
		  
		  // Get the Parent AssetNameValue
		  ChildAssetNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[4]/ul/li");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);	
		  
	 }
	 
	 @Test(priority=140, enabled = true)
	  public void Child_MediaName_AssetRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);	    
		  // Get the Parent MediaNameValue
		  ChildMediaNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[2]");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);	
		  
		  // Select Parent Entity from drop down
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    Thread.sleep(5000);
		    
		    //Enter Created Entity Name in Search box
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		    //Reporter.log("Enter Created Entity Name in Search box | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Select the Searched Entity
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		    //Reporter.log("Select the Searched Entity | ");
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(3000);
		  
	 }
	 
	 @Test(priority=141, enabled = true)
	  public void Compare_MediaLabelName_AssetRelated() throws IOException, InterruptedException {
	       
		  
		  // Get the Compare the Response Color
		  CompareMediaLabelNameValue("ParentMediaLabelNameValue","ChildMediaLabelNameValue");
		  Thread.sleep(2000);
	   	     
	  }  	
	   	     
	  @Test(priority=142, enabled = true)
	  public void Compare_AssetName_AssetRelated() throws IOException, InterruptedException {
	
		// Get the Compare the Asset Name
			CompareAssetNameValue("ParentAssetNameValue","ChildAssetNameValue");
		    Thread.sleep(3000);
			  
	  }
	  
	  @Test(priority=143, enabled = true)
	  public void Compare_MediaName_AssetRelated() throws IOException, InterruptedException {
	   
		//  Thread.sleep(5000);
		// Get the Compare the Documents TextValue
		    CompareMediaNameValue("ParentMediaNameValue","ChildMediaNameValue");
		    Thread.sleep(3000);
		 
	  } 	  
	  
}
