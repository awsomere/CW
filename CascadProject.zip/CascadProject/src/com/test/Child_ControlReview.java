package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Child_ControlReview extends WrapperClass{
	
	public WebDriver driver;
	  String browser=null;

	  String ParentEntity = "ChildEntityStage";
	  String ChildEntity = "GrantChildEntityStage";
	  
	 
	  @Test(priority=105, enabled = true)
	   public void Navigate_ParentEntity() throws IOException, InterruptedException {
		   
		     	
		  Thread.sleep(5000);
		          
		    //Click on Controls Review Page
	        assertTextLink("Controls Review");
		    clickBylinktext("Controls Review");
		    Reporter.log("Click on Controls Review Page | ");
		    Thread.sleep(8000);
		    Thread.sleep(8000);
		    Thread.sleep(8000);
		    Thread.sleep(8000);
		    Thread.sleep(8000);
		    Thread.sleep(8000);
			  Thread.sleep(8000);
			  Thread.sleep(8000);
			  Thread.sleep(8000);
			    Thread.sleep(8000);
				  Thread.sleep(8000);
				  Thread.sleep(8000);
			  
		  // Select Parent Entity from drop down
	 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   Thread.sleep(3000);
		   
		  //Enter Created Entity Name in Search box
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		   //Reporter.log("Enter Created Entity Name in Search box | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   
		   //Select the Searched Entity
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(8000);
		    Thread.sleep(8000);
			  Thread.sleep(8000);
			  Thread.sleep(8000);
			  Thread.sleep(8000);
			    Thread.sleep(8000);
				  Thread.sleep(8000);
				  Thread.sleep(8000);
		   Thread.sleep(5000);	
		   Thread.sleep(5000);
		   
	  }
	  
	  @Test(priority=106, enabled = true)
	   public void Parent_CascadeIcon_MediaRelated() throws IOException, InterruptedException {
		   
		 /*//Click on Parent cascade Icon
		   assertTextXpath("//*[@id='rrReport']/tbody/tr[1]/td[1]/cw-cascade/span/span/button");
		   clickByXpath("//*[@id='rrReport']/tbody/tr[1]/td[1]/cw-cascade/span/span/button");
		   Thread.sleep(3000);

		   //Click on Close button in Parent cascade Icon
		   assertTextXpath("html/body/div[4]/div/div/div[1]/button");
		   clickByXpath("html/body/div[4]/div/div/div[1]/button");
		   Thread.sleep(3000); */
		   
	  }
	  
	  @Test(priority=107, enabled = true)
	   public void Parent_Response_MediaRelated() throws IOException, InterruptedException {
	  
		  Thread.sleep(5000);
		  
		// Get the Parent Response Color
		   ParentMediaResponseColor("//*[@id='rrReport']/tbody/tr[1]/td[11]/cw-s-response-choices/div/div/label[1]");
		   Thread.sleep(3000);	
			   	     	    
	  }
	  
	  @Test(priority=108, enabled = true)
	   public void Parent_Notes_MediaRelated() throws IOException, InterruptedException {
		  
		  //Click on Notes button to add text
		   assertTextXpath("//*[@id='rrReport']/tbody/tr[1]/td[14]/div/a");
		   clickByXpath("//*[@id='rrReport']/tbody/tr[1]/td[14]/div/a");
		   //Reporter.log("Click on Notes button to add text | ");
		   Thread.sleep(5000);
		   //Thread.sleep(3000);	
		   
		// Get the Parent Note TextValue
		   ParentMediaNotevalue("//*[@id='note-details-table_info']");
		   //Reporter.log(" Get the Parent Note TextValue | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   			  
		   // Click on Close Button in note pop-up window
		   assertTextXpath("//div[4]/div/div/div[1]/button");
		   clickByXpath("//div[4]/div/div/div[1]/button");
		   //Reporter.log("Click on Close Button in note pop-up window | ");
		   Thread.sleep(3000);
		   Thread.sleep(3000);
		   
	  }
	  
	  @Test(priority=109, enabled = true)
	   public void Navigate_ChildEntity() throws IOException, InterruptedException {
		   
		     Thread.sleep(3000);
			     
		   //Click on the Created new Entity drop-down from Header 
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   //Reporter.log("Click on the Created new Entity drop-down from Header | ");
		   Thread.sleep(3000);
		   
		   //Enter Created Entity Name in Search box
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		   //Reporter.log("Enter Created Entity Name in Search box | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   
		   //Select the Searched Entity
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(8000);
		    Thread.sleep(8000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
		   
	  }
	  
	  @Test(priority=110, enabled = true)
	   public void Child_CascadeIcon_MediaRelated() throws IOException, InterruptedException {	   			
		   
		   //Click on Child cascade Icon
		  /* assertTextXpath("//*[@id='rrReport']/tbody/tr[1]/td[1]/cw-cascade/span/span/button");
		   clickByXpath("//*[@id='rrReport']/tbody/tr[1]/td[1]/cw-cascade/span/span/button");
		   Thread.sleep(3000);
		   	//Thread.sleep(3000);			
			     
		   //Click on Close button in Parent cascade Icon
		   assertTextXpath("html/body/div[4]/div/div/div[1]/button");
		   clickByXpath("html/body/div[4]/div/div/div[1]/button");*/
		  Thread.sleep(3000);	
		  
	  }
	  
	  @Test(priority=111, enabled = true)
	   public void Child_Response_MediaRelated() throws IOException, InterruptedException {
		  
		// Get the Parent Response Color
		  ChildMediaResponseColor("//*[@id='rrReport']/tbody/tr[1]/td[11]/cw-s-response-choices/div/div/label[1]");
		  // Reporter.log(" Get the Parent Note TextValue | ");
		   Thread.sleep(3000);	
		   
	  }
				
	  @Test(priority=112, enabled = true)
	   public void Child_Notes_MediaRelated() throws IOException, InterruptedException {
		  
		  //Click on Notes button to add text
		  assertTextXpath("//*[@id='rrReport']/tbody/tr[1]/td[14]/div/a");
		  clickByXpath("//*[@id='rrReport']/tbody/tr[1]/td[14]/div/a");
		  //Reporter.log("Click on Notes button to add text | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);	
							   
		  // Get the Parent Note TextValue
		  ChildMediaNotevalue("//*[@id='note-details-table_info']");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  // Click on Close Button in note pop-up window
		  assertTextXpath("//div[4]/div/div/div[1]/button");
		  clickByXpath("//div[4]/div/div/div[1]/button");
		  //Reporter.log("Click on Close Button in note pop-up window | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  //Thread.sleep(3000);
		  Thread.sleep(5000);
		  
	  }
	  
	  @Test(priority=113, enabled = true)
	   public void Compare_Response_MediaRelated() throws IOException, InterruptedException {
		  
		  
		// Get the Compare the Response Color
		    CompareMediaResponseColor("ParentMediaResponse","ChildMediaResponse");
		    Thread.sleep(3000);
		  
	  }
	  
	  @Test(priority=114, enabled = true)
	   public void Compare_Notes_MediaRelated() throws IOException, InterruptedException {
		  
		//  Thread.sleep(3000);
		  
		// Get the Compare the Note TextValue
		  CompareMediaNotevalue("ParentMediaNote","ChildMediaNote");
		  Thread.sleep(3000);
		 
		  }	
   
}
