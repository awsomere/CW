package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Child_RiskEvalations extends WrapperClass{
	
	public WebDriver driver;
	  String browser=null;
	  
	  String ParentEntity = "ChildEntityStage";
	  String ChildEntity = "GrantChildEntityStage";
	  
	  @Test(priority=144, enabled = true)
	   public void Navigate_ParentyEntity_RiskEvalation() throws IOException, InterruptedException {
		   
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  
		    //Click on Risk Response Module
	 	    assertTextXpath("//*[@id='sidebar-left']/ul/li[5]/a/span[2]");
	        clickByXpath("//*[@id='sidebar-left']/ul/li[5]/a/span[2]");
	        Reporter.log("Click on Risk Response Module | ");
	        Thread.sleep(5000);
	        //Thread.sleep(3000);
	        //Thread.sleep(3000);
	        //Thread.sleep(3000);
	        
	        //Click on Risk Response List Sub-module
	        assertTextLink("Risk Response List");
	        clickBylinktext("Risk Response List");
	        Reporter.log("Click on Risk Response List Sub-module | ");
	        Thread.sleep(5000);
	        Thread.sleep(3000); 
	        Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
	        
	        // Select Parent Entity from drop down
		 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			   Thread.sleep(5000);
			   
			  //Enter Created Entity Name in Search box
			   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
			   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
			   //Reporter.log("Enter Created Entity Name in Search box | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);
			   
			   //Select the Searched Entity
			   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
			   //Reporter.log("Select the Searched Entity | ");
			   Thread.sleep(5000);
			   Thread.sleep(5000);
			   Thread.sleep(5000);
			   
	  }
	  
	  @Test(priority=145, enabled = true)
	   public void Parent_CascadeIcon_RiskEvalation() throws IOException, InterruptedException {
		   
      
			/* //Click on Parent cascade Icon
			  assertTextXpath("//*[@id='content']/tr[2]/td[2]/cw-cascade/span/span/button");
			  clickByXpath("//*[@id='content']/tr[2]/td[2]/cw-cascade/span/span/button");
			  Thread.sleep(5000);
			   
			  //Click on Close button in Parent cascade Icon
			  assertTextXpath("html/body/div[4]/div/div/div[1]/button");
			  clickByXpath("html/body/div[4]/div/div/div[1]/button");*/
			  Thread.sleep(5000);  
	  }
	  
	  @Test(priority=146, enabled = true)
	  public void Parent_RiskTreatmentType_RiskEvalation() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
		  		   
		  //Click on TBD Button 
	       assertTextXpath("//tr[2]/td[9]/div/div/cw-section-change-button-caller/div/span");
	       clickByXpath("//tr[2]/td[9]/div/div/cw-section-change-button-caller/div/span");
	       //Reporter.log("Click on TBD Button | ");
	       Thread.sleep(5000);
	       Thread.sleep(3000);
	       //Thread.sleep(3000);
	       
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       
	     //Click on ImplementationPlanning Button 
	       assertTextXpath("//*[@id='rtIp']");
	       clickByXpath("//*[@id='rtIp']");
	      // Reporter.log("Click on ImplementationPlanning Button | ");
	       Thread.sleep(5000);
	       Thread.sleep(5000);	       
	       
	       // Get the Risk Treatment Type
		   ParentRiskTreatmentTypevalue("//*[@id='body-content']/div[1]/div/div/div[2]/div[2]/div[2]/div/div[2]/cw-rt-treatment-choices/div/span/b");
		   Thread.sleep(3000);
		   mouseHoverByXpath("//*[@id='body-content']/div[1]/div/div/div[2]/div[2]/div[2]/div/div[1]/div[1]/ul/li[1]/cw-cascade/span/span/button/i");
		   Thread.sleep(5000);
		   
	  }
	  
	  @Test(priority=147, enabled = true)
	  public void Parent_EvalationControlsCascadeIcon_RiskEvalation() throws IOException, InterruptedException {
		   
	// Production Code      
		   /*//Click on Parent cascade Icon
		   assertTextXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
	       clickByXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
	       Thread.sleep(5000);
			   
	       //Click on Close button in Parent cascade Icon
	       assertTextXpath("html/body/div[5]/div/div/div[1]/button");
	       clickByXpath("html/body/div[5]/div/div/div[1]/button");
	       Thread.sleep(5000); 
			  
	       //Click on Parent cascade Icon
		   assertTextXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[4]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
		   clickByXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[4]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
		   Thread.sleep(5000);
			   
		   //Click on Close button in Parent cascade Icon
		   assertTextXpath("html/body/div[5]/div/div/div[1]/button");
		   clickByXpath("html/body/div[5]/div/div/div[1]/button");
		   Thread.sleep(5000); */
		   
		 /*//Click on Parent cascade Icon
		 assertTextXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[3]/ul/li[4]/cw-cascade/span/span/button");
		   clickByXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[3]/ul/li[4]/cw-cascade/span/span/button");
		   Thread.sleep(5000);
			   
		   //Click on Close button in Parent cascade Icon
		   assertTextXpath("html/body/div[5]/div/div/div[1]/button");
		   clickByXpath("html/body/div[5]/div/div/div[1]/button");
		   Thread.sleep(5000);*/
	  }
	  
	  @Test(priority=148, enabled = true)
	  public void Parent_Effectiveness_RiskEvalation() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
		   
		   // Get the Effectiveness option text
		  // ParentEffectivenessvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[5]/cw-rt-evaluate-alternative-choices/div/button/b");
		   ParentEffectivenessvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[6]/cw-rt-evaluate-alternative-choices/div/button/b");
		   Thread.sleep(5000); 
		   
	  }
	  @Test(priority=149, enabled = true)
	  public void Parent_EstimatedCost_RiskEvalation() throws IOException, InterruptedException {
		  
		   // Get the Estimated Cost
		  // ParentEstimatedCostvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[6]/div/input");
		   ParentEstimatedCostvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[7]/div/input");
		   Thread.sleep(5000); 
	  }
	  
	  @Test(priority=150, enabled = true)
	  public void Parent_Feasibility_RiskEvalation() throws IOException, InterruptedException {
		     
		   // Get the Feasibility Option Text
		   //ParentFeasibilityvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[7]/cw-rt-evaluate-alternative-choices/div/button/b");
		   ParentFeasibilityvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[8]/cw-rt-evaluate-alternative-choices/div/button/b");
		   Thread.sleep(5000); 
		   
	  }
	  @Test(priority=151, enabled = true)
	  public void Parent_Action_RiskEvalation() throws IOException, InterruptedException {
		       
		   // Get the Action 
		   //ParentActionvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[9]/cw-rt-evaluate-alternative-choices/div/button/b");
		   ParentActionvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[10]/cw-rt-evaluate-alternative-choices/div/button/b");
		   Thread.sleep(5000); 
		   
		   
	  }
	  
	  @Test(priority=152, enabled = true)
	  public void Parent_ImplementationControlsCascadeIcon_RiskEvalation() throws IOException, InterruptedException {
		  
		  /* //Click on Parent cascade Icon
	        //clickByXpath("//*[@id='ipData']/tbody/tr[1]/td[2]/cw-cascade/span/span/button");
	       clickByXpath("//*[@id='ipData']/tbody/tr[1]/td[3]/cw-cascade/span/span/button");
	       Thread.sleep(5000);
			   
	       //Click on Close button in Parent cascade Icon
	       assertTextXpath("html/body/div[5]/div/div/div[1]/button");
	       clickByXpath("html/body/div[5]/div/div/div[1]/button");
	       Thread.sleep(5000); */
	       
			  
	      /* //Click on Parent cascade Icon
		   assertTextXpath("//*[@id='ipData']/tbody/tr[2]/td[2]/cw-cascade/span/span/button/i");
		   clickByXpath("//*[@id='ipData']/tbody/tr[2]/td[2]/cw-cascade/span/span/button/i");
		   Thread.sleep(5000);
			   
		   //Click on Close button in Parent cascade Icon
		   assertTextXpath("html/body/div[5]/div/div/div[1]/button");
		   clickByXpath("html/body/div[5]/div/div/div[1]/button");
		   Thread.sleep(5000); */		
	       
	  }
	  
	  @Test(priority=153, enabled = true)
	  public void Parent_RiskNotes_RiskEvalation() throws IOException, InterruptedException {
		  
	       
		   ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       ArrowDown();
	       Thread.sleep(2000);  
	       
		   //Click on Notes button to add text
		 assertTextXpath("//*[@id='rtData']/div[2]/div/div[1]/div[1]/div/div/a");
		    clickByXpath("//*[@id='rtData']/div[2]/div/div[1]/div[1]/div/div/a");
		    //Reporter.log("Click on Notes button to add text | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    // Get the parent Note TextValue
		    ParentNotevalue("//*[@id='note-details-table_info']");
		    //Reporter.log(" Get the Parent Note TextValue | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
			  
		    // Click on Close Button in note pop-up window
		    assertTextXpath("//div[5]/div/div/div[1]/button");
		    clickByXpath("//div[5]/div/div/div[1]/button");
		    //Reporter.log("Click on Close Button in note pop-up window | ");
		    Thread.sleep(3000);
		    Thread.sleep(3000);
		    
	  }
	  
	  @Test(priority=154, enabled = true)
	  public void Parent_MousehoverCascadeIcon_RiskEvalation() throws IOException, InterruptedException {
		  
	        // Mousehover on RiskOwner
            mouseHoverByXpath("//*[@id='rtData']/div[1]/div/div[1]/div[1]/cw-cascade/span/span/button");
            Thread.sleep(2000);
      
		    // Mousehover on RiskNotes
		    mouseHoverByXpath("//*[@id='rtData']/div[2]/div/div[1]/div[1]/cw-cascade/span/span/button");
		    Thread.sleep(2000); 
		    
		    // Mousehover on Residual Risk
		    mouseHoverByXpath("//*[@id='rtData']/div[3]/div/div[1]/div[2]/div/cw-cascade/span/span/button");
		    Thread.sleep(2000);
		    
		 // Mousehover on Status
		    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[1]/div[1]/div[3]/cw-cascade/span/span/button");
		    Thread.sleep(2000); 
		    
		    // Mousehover on Evaluated
		    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[1]/div[2]/div[1]/div[3]/cw-cascade/span/span/button");
		    Thread.sleep(2000);
		    
		 // Mousehover on Approved
		    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[2]/div[2]/div/div[3]/cw-cascade/span/span/button");
		    Thread.sleep(2000);
		    
		 // Mousehover on Planned
		    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[1]/div[2]/div[2]/div[3]/cw-cascade/span/span/button");
		    Thread.sleep(2000); 
	  }
	  
	  @Test(priority=155, enabled = true)
	  public void Parent_RiskLikelihood_RiskEvalation() throws IOException, InterruptedException {
		  
		    
		    // Get the RiskLikelihood value
		    ParentRiskLikelihoodvalue("//*[@id='_residualData']/div[2]/div/cw-risk-choices/div/button");
		    Thread.sleep(3000);
	  }
	  
	  @Test(priority=156, enabled = true)
	  public void Parent_RiskImpact_RiskEvalation() throws IOException, InterruptedException {
		  
		    
		 // Get the RiskImpact value
		    ParentRiskImpactvalue("//*[@id='_residualData']/div[3]/div/cw-risk-choices/div/button");
		    Thread.sleep(3000);
		    
	  }
	  
	  @Test(priority=157, enabled = true)
	  public void Parent_RiskRating_RiskEvalation() throws IOException, InterruptedException {
		  
		    
		    // Get the RiskRating value
		    ParentRiskRatingvalue("//*[@id='_residualData']/div[4]/div[2]/div/div/div/span");
		    Thread.sleep(5000);   
		    
	  }
	  
	  @Test(priority=158, enabled = true)
	  public void Navigate_ChildEntity_RiskEvalation() throws IOException, InterruptedException {
		 
		    
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    ArrowUp();
		    Thread.sleep(2000);  
		    
		   // Select Child Entity from drop down
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/a/span/span[1]");
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/a/span/span[1]");
		    Thread.sleep(5000);
		    
		    //Enter Created Entity Name in Search box
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/ul/li[1]/input");
		    sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/ul/li[1]/input", ChildEntity);
		    //Reporter.log("Enter Created Entity Name in Search box | ");
		    Thread.sleep(3000);
			//Thread.sleep(3000);
		    
		    //Select the Searched Entity
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/ul/li[2]/a");
		    //Reporter.log("Select the Searched Entity | ");
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
			    Thread.sleep(5000);
			    Thread.sleep(5000);
			    Thread.sleep(5000);
				  Thread.sleep(5000);
			  Thread.sleep(5000);
		    
	  }
	  
	  @Test(priority=159, enabled = true)
	   public void Child_CascadeIcon_RiskEvalation() throws IOException, InterruptedException {
		   
	          Thread.sleep(3000);
	           
     
			 /*//Click on Child cascade Icon
			  assertTextXpath("//*[@id='content']/tr[2]/td[2]/cw-cascade/span/span/button");
			  clickByXpath("//*[@id='content']/tr[2]/td[2]/cw-cascade/span/span/button");
			  Thread.sleep(5000);
			   
			  //Click on Close button in Parent cascade Icon
			  assertTextXpath("html/body/div[4]/div/div/div[1]/button");
			  clickByXpath("html/body/div[4]/div/div/div[1]/button");*/
			  Thread.sleep(5000);  
	  }
		    
	  @Test(priority=160, enabled = true)
	  public void Child_RiskTreatmentType_RiskEvalation() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
		//Click on TBD Button 
	       assertTextXpath("//tr[2]/td[9]/div/div/cw-section-change-button-caller/div/span");
	       clickByXpath("//tr[2]/td[9]/div/div/cw-section-change-button-caller/div/span");
	       //Reporter.log("Click on TBD Button | ");
	       Thread.sleep(5000);
	       Thread.sleep(3000);
		    //Thread.sleep(3000);
		       
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       
		       Thread.sleep(5000);
		       
		       //Click on ImplementationPlanning Button 
		       assertTextXpath("//*[@id='rtIp']");
		       clickByXpath("//*[@id='rtIp']");
		      // Reporter.log("Click on ImplementationPlanning Button | ");
		       Thread.sleep(5000);
		       Thread.sleep(5000);   
		       
			    Thread.sleep(5000);
			    Thread.sleep(5000);
			    Thread.sleep(5000);
				  Thread.sleep(5000);
		       
		    		    
		  
		    // Get the Risk Treatment Type
		       ChildRiskTreatmentTypevalue("//*[@id='body-content']/div[1]/div/div/div[2]/div[2]/div[2]/div/div[2]/cw-rt-treatment-choices/div/span/b");
			   Thread.sleep(5000);
			   mouseHoverByXpath("//*[@id='body-content']/div[1]/div/div/div[2]/div[2]/div[2]/div/div[1]/div[1]/ul/li[1]/cw-cascade/span/span/button/i");
			   Thread.sleep(5000);
			   
	  }
	  
	  @Test(priority=161, enabled = true)
	  public void Child_EvalationControlCascadeIcons_RiskEvalation() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
			 
	//Production code		   
		       /*//Click on Child cascade Icon
		        assertTextXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
		       clickByXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
		       Thread.sleep(5000);
				   
		       //Click on Close button in Child Icon
		       assertTextXpath("html/body/div[5]/div/div/div[1]/button");
		       clickByXpath("html/body/div[5]/div/div/div[1]/button");
		       Thread.sleep(5000); 
				  
		       //Click on Child cascade Icon
			   assertTextXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[4]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
			   clickByXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[4]/td[2]/ul/li[4]/cw-cascade/span/span/button/i");
			   Thread.sleep(5000);
				   
			   //Click on Close button in Parent cascade Icon
			   assertTextXpath("html/body/div[5]/div/div/div[1]/button");
			   clickByXpath("html/body/div[5]/div/div/div[1]/button");
			   Thread.sleep(5000); */
			   
			  /* //Click on Child cascade Icon
			   assertTextXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[3]/ul/li[4]/cw-cascade/span/span/button");
			   clickByXpath("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[3]/ul/li[4]/cw-cascade/span/span/button");
			   Thread.sleep(5000);
			   
			   //Click on Close button in Child cascade Icon
			   assertTextXpath("html/body/div[5]/div/div/div[1]/button");
			   clickByXpath("html/body/div[5]/div/div/div[1]/button");
			   Thread.sleep(5000);*/
			   
	  }
	  
	  @Test(priority=162, enabled = true)
	  public void Child_Effectiveness_RiskEvalation() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
			   
			   // Get the Effectiveness option text
			   // ParentEffectivenessvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[5]/cw-rt-evaluate-alternative-choices/div/button/b");
			   ChildEffectivenessvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[6]/cw-rt-evaluate-alternative-choices/div/button/b");
			   Thread.sleep(5000); 
			   
	  }
	  
	  @Test(priority=163, enabled = true)
	  public void Child_EstimatedCost_RiskEvalation() throws IOException, InterruptedException {
		  
			   
			   // Get the Estimated Cost
			   // ParentEstimatedCostvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[6]/div/input");
			   ChildEstimatedCostvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[7]/div/input");
			   Thread.sleep(5000); 
			   
	  }
	  
	  @Test(priority=164, enabled = true)
	  public void Child_Feasibility_RiskEvalation() throws IOException, InterruptedException {
		  	   
			   // Get the Feasibility Option Text
			   //ParentFeasibilityvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[7]/cw-rt-evaluate-alternative-choices/div/button/b");
			   ChildFeasibilityvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[8]/cw-rt-evaluate-alternative-choices/div/button/b");
			   Thread.sleep(5000); 
			   
	  }
	  @Test(priority=165, enabled = true)
	  public void Child_Action_RiskEvalation() throws IOException, InterruptedException {
		  	 
	  		   // Get the Action 
			   //ParentActionvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[9]/cw-rt-evaluate-alternative-choices/div/button/b");
			   ChildActionvalue("//*[@id='rist-treatment-alternative-evaluation']/tbody/tr[3]/td[10]/cw-rt-evaluate-alternative-choices/div/button/b");
			   Thread.sleep(5000); 
			   
	  }
	  @Test(priority=166, enabled = true)
	  public void Child_ImplementationControlCascadeIcon_RiskEvalation() throws IOException, InterruptedException {
		  	
	 	   
			  /* //Click on Child cascade Icon
			   //clickByXpath("//*[@id='ipData']/tbody/tr[1]/td[2]/cw-cascade/span/span/button");
			   clickByXpath("//*[@id='ipData']/tbody/tr[1]/td[3]/cw-cascade/span/span/button");
			   Thread.sleep(5000);
			   
			   //Click on Close button in Parent cascade Icon
			   assertTextXpath("html/body/div[5]/div/div/div[1]/button");
			   clickByXpath("html/body/div[5]/div/div/div[1]/button");
			   Thread.sleep(5000); */
			   
			   /* //Click on Parent cascade Icon
			      assertTextXpath("//*[@id='ipData']/tbody/tr[2]/td[2]/cw-cascade/span/span/button/i");
				  clickByXpath("//*[@id='ipData']/tbody/tr[2]/td[2]/cw-cascade/span/span/button/i");
				  Thread.sleep(5000);
					   
				  //Click on Close button in Parent cascade Icon
				  assertTextXpath("html/body/div[5]/div/div/div[1]/button");
				  clickByXpath("html/body/div[5]/div/div/div[1]/button");
			      Thread.sleep(5000); */	
			   
	  }
	  
	  @Test(priority=167, enabled = true)
	  public void Child_RiskNotes_RiskEvalation() throws IOException, InterruptedException {
		  	
			   
			   ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       ArrowDown();
		       Thread.sleep(2000); 
		       
			   //Click on Notes button to add text
			 assertTextXpath("//*[@id='rtData']/div[2]/div/div[1]/div[1]/div/div/a");
			    clickByXpath("//*[@id='rtData']/div[2]/div/div[1]/div[1]/div/div/a");
			    //Reporter.log("Click on Notes button to add text | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			    
			    // Get the Child Note TextValue
			    ChildNotevalue("//*[@id='note-details-table_info']");
			    //Reporter.log(" Get the Child Note TextValue | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
				  
			    // Click on Close Button in note pop-up window
			    assertTextXpath("//div[5]/div/div/div[1]/button");
			    clickByXpath("//div[5]/div/div/div[1]/button");
			    //Reporter.log("Click on Close Button in note pop-up window | ");
			    Thread.sleep(3000);
			    Thread.sleep(3000);
			    
	  }
	   
	  @Test(priority=168, enabled = true)
	  public void Child_MousehoverCascadeIcon_RiskEvalation() throws IOException, InterruptedException {
		  	
	          // Mousehover on RiskOwner
              mouseHoverByXpath("//*[@id='rtData']/div[1]/div/div[1]/div[1]/cw-cascade/span/span/button");
              Thread.sleep(2000); 
			    
			    // Mousehover on RiskNotes
			    mouseHoverByXpath("//*[@id='rtData']/div[2]/div/div[1]/div[1]/cw-cascade/span/span/button");
			    Thread.sleep(2000); 
			    
			    // Mousehover on Residual Risk
			    mouseHoverByXpath("//*[@id='rtData']/div[3]/div/div[1]/div[2]/div/cw-cascade/span/span/button");
			    Thread.sleep(2000);
			    
			 // Mousehover on Status
			    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[1]/div[1]/div[3]/cw-cascade/span/span/button");
			    Thread.sleep(2000); 
			    
			    // Mousehover on Evaluated
			    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[1]/div[2]/div[1]/div[3]/cw-cascade/span/span/button");
			    Thread.sleep(2000);
			    
			 // Mousehover on Approved
			    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[2]/div[2]/div/div[3]/cw-cascade/span/span/button");
			    Thread.sleep(2000);
			    
			 // Mousehover on Planned
			    mouseHoverByXpath("//*[@id='rtData']/div[4]/div/div[1]/div[2]/div[2]/div[3]/cw-cascade/span/span/button");
			    Thread.sleep(2000);	
			    
	  }
	  
	  @Test(priority=169, enabled = true)
	  public void Child_RiskLikelihood_RiskEvalation() throws IOException, InterruptedException {
		  	
		  
			    // Get the RiskLikelihoodvalue
			    ChildRiskLikelihoodvalue("//*[@id='_residualData']/div[2]/div/cw-risk-choices/div/button");
			    Thread.sleep(3000);
	  }
	  
	  @Test(priority=170, enabled = true)
	  public void Child_RiskImpact_RiskEvalation() throws IOException, InterruptedException {
		  	
			 // Get the RiskImpactvalue
			    ChildRiskImpactvalue("//*[@id='_residualData']/div[3]/div/cw-risk-choices/div/button");
			    Thread.sleep(3000);
			    
	  }
	  
	  @Test(priority=171, enabled = true)
	  public void Child_RiskRating_RiskEvalation() throws IOException, InterruptedException {
		  	
			    
			 // Get the RiskRating value
			  ChildRiskRatingvalue("//*[@id='_residualData']/div[4]/div[2]/div/div/div/span");
			    Thread.sleep(3000);    
			    
	  }
	  
	  @Test(priority=172, enabled = true)
	  public void Compare_RiskTreatmentType_RiskEvalation() throws IOException, InterruptedException {
		  	
			    			    		    		    
			  //Compare RiskTreatmentTypevalue
			  CompareRiskTreatmentTypevalue("ParentRiskTreatmentType","ChildRiskTreatmentType");
			  Thread.sleep(2000);
			  
	  }
	  
	  @Test(priority=173, enabled = true)
	   public void Compare_Effectiveness_RiskEvalation() throws IOException, InterruptedException {
		  
		 
			  
			//Compare Effectiveness value
		     CompareEffectivenessvalue("ParentEffectiveness","ChildEffectiveness");
		     Thread.sleep(2000);
		     
	  }
	  
	  @Test(priority=173, enabled = true)
	   public void Compare_EstimatedCost_RiskEvalation() throws IOException, InterruptedException {
		  
		  
		     
		   //Compare EstimatedCost value 
		      CompareEstimatedCostvalue("ParentEstimatedCost","ChildEstimatedCost");
		      Thread.sleep(2000);
		      
	  }
	  
	  @Test(priority=174, enabled = true)
	   public void Compare_Feasibility_RiskEvalation() throws IOException, InterruptedException {
	      
		    //Compare Feasibility value
		      CompareFeasibilityvalue("ParentFeasibility","ChildFeasibility");
		      Thread.sleep(2000);
	  }
	  
	  @Test(priority=175, enabled = true)
	   public void Compare_Action_RiskEvalation() throws IOException, InterruptedException {
		  
		
		      		      
		    //Compare Action value   
		      CompareActionvalue("ParentAction","ChildAction");
		      Thread.sleep(2000);
		      
	  }
	  @Test(priority=176, enabled = true)
	   public void Compare_RiskNotes_RiskEvalation() throws IOException, InterruptedException {
		  
		      
		    //Compare Note value
		      CompareNotevalue("ParentNote","ChildNote");
		      Thread.sleep(2000);
		     
	  }
		     
	  
	  @Test(priority=177, enabled = true)
	   public void Compare_RiskLikelihood_RiskEvalation() throws IOException, InterruptedException {
		  
		    //Compare RiskLikelihood value
		      CompareRiskLikelihood("ParentRiskLikelihood","ChildRiskLikelihood");
		      Thread.sleep(2000);
	  
	  }
	  
	  @Test(priority=178, enabled = true)
	   public void Compare_RiskImpact_RiskEvalation() throws IOException, InterruptedException {
		  
		 	      
		    //Compare RiskImpact value
		      CompareRiskImpact("ParentRiskImpact","ChildRiskImpact");
		      Thread.sleep(2000);
	  }
	  
	  @Test(priority=179, enabled = true)
	   public void Compare_RiskRating_RiskEvalation() throws IOException, InterruptedException {
		  
		       
		    //Compare RiskRating value
		  CompareRiskRatingvalue("ParentRiskRating","ChildRiskRating");
		  Thread.sleep(2000);	
		  
		  //Click on Risk Response List Sub-module
		  assertTextLink("Risk Response List");
		  clickBylinktext("Risk Response List");
		  //Reporter.log("Click on Risk Response List Sub-module | ");
		  Thread.sleep(3000);
		  //clickByXpath("html/body/div[5]/div/div/div[3]/button[2]");
		  Thread.sleep(3000);
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  
	  }

}
