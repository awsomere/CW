package com.test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Child_RiskQuestionnaireList extends WrapperClass{
		
	public WebDriver driver;
	  String browser=null;
	  
	  String ParentEntity = "ChildEntityStage";
	  String ChildEntity = "GrantChildEntityStage";
	  
	  
 
 @Test(priority=78, enabled = true)
 public void Child_CascadingStatistics() throws IOException, InterruptedException {
		   
	 Thread.sleep(5000);

	  Thread.sleep(5000);
	 
	 // Select Risk Questionnaire list sub-module under Risk Determination Module
	        try {
	        	assertTextLink("Risk Questionnaire List");
	        	clickBylinktext("Risk Questionnaire List");
	            Reporter.log("Select Risk Questionnaire List | ");
	       }catch(Exception e)
		    {
		        e.printStackTrace();
		        Reporter.log("Select Risk Questionnaire List doesn't reached | ");
		    }
	        Thread.sleep(5000);
	        Thread.sleep(5000);
	        Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
	        //Thread.sleep(3000);
	        
	        /*//Click on cascad button for Child Entity
	        assertTextXpath("//*[@id='content']/tr[1]/td[2]/span/cw-cascade/span/span/button");
	        mouseHoverByXpath("//*[@id='content']/tr[1]/td[2]/span/cw-cascade/span/span/button");
	        Thread.sleep(3000);
		    clickByXpath("//*[@id='content']/tr[1]/td[2]/span/cw-cascade/span/span/button");
		    Thread.sleep(3000);
		    
		       // Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[1]/h4", "Child Cascading Statistics");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(1000);
			   Thread.sleep(1000);
			   
			// Click on Parent Name Field
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[1]/td[1]", "Parent Name:");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(1000);
			   Thread.sleep(1000);
			   
			// Click on Parent Name text
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[1]/td[2]/span", ParentEntity);
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(1000);
			   Thread.sleep(1000);
			   
			   
			// Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[2]/td[1]", "First Cascaded:");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(1000);
			   Thread.sleep(1000);
			   
			  // Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[3]/td[1]", "Last Cascaded:");
			  // Reporter.log("Click on Page header Title | ");
			   Thread.sleep(1000);
			   Thread.sleep(1000);
			   
			// Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[4]/td[1]", "Last Updated:");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(1000);
			   Thread.sleep(1000);
			   
		    // Click on Close button
		    assertTextXpath("//div[5]/div/div/div[1]/button");
		    clickByXpath("//div[5]/div/div/div[1]/button");
	        Thread.sleep(3000);		  */
	           
		  }
		  
		  @Test(priority=79, enabled = true)
		  public void Navigate_ParentEntity() throws IOException, InterruptedException {
			  
			  Thread.sleep(3000);		
			  
			  // Select Parent Entity from drop down
	 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   Thread.sleep(3000);
		   
		  //Enter Created Entity Name in Search box
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		   //Reporter.log("Enter Created Entity Name in Search box | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   
		   //Select the Searched Entity
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   
		  }
		  
		   @Test(priority=80, enabled = true)
		  public void Parent_CascadingStatistics() throws IOException, InterruptedException {	   
		   
		  /* // Click on cascad button for Parent Entity
	       assertTextXpath("//*[@id='content']/tr[1]/td[2]/span/cw-cascade/span/span/button");
	       mouseHoverByXpath("//*[@id='content']/tr[1]/td[2]/span/cw-cascade/span/span/button");
	       Thread.sleep(3000);
		    clickByXpath("//*[@id='content']/tr[1]/td[2]/span/cw-cascade/span/span/button");
		    Thread.sleep(3000);
		    
		      // Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[1]/h4", "Parent Cascading Statistics");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(2000);
			  		   
			// Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[1]/td[1]", "First Cascaded:");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(2000);
			  
			   
			// Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[2]/td[1]", "Most Recent Cascaded:");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(2000);
			  // Thread.sleep(1000);
			   
			  // Click on Page header Title
			   assertEquals("html/body/div[5]/div/div/div[2]/div/table/tbody/tr[3]/td[1]", "Last Record Update:");
			   //Reporter.log("Click on Page header Title | ");
			   Thread.sleep(2000);
			   //Thread.sleep(1000);
			   
		       // Click on Close button
		       assertTextXpath("//div[5]/div/div/div[1]/button");
	          clickByXpath("//div[5]/div/div/div[1]/button");
	          Thread.sleep(3000);*/
		   
		}
	         		 
		  @Test(priority=81, enabled =true)
		  public void Parent_CascadeIcon_MediaRelated() throws InterruptedException, IOException {
				   
			  Thread.sleep(3000);
			  Thread.sleep(3000);
			  
			  // Click on 'Review' button of Media/Asset
			  assertTextXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
			  clickByXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
			  Reporter.log("Click on 'Review' button of Media/Asset | ");
			  Thread.sleep(8000);
			  Thread.sleep(8000);
		        
		        //Expand the Controls
		        assertTextXpath("//td[2]/span[1]");
		        clickByXpath("//td[2]/span[1]");
		        //Reporter.log("Expand the Controls | ");
		        Thread.sleep(5000);    
		        
		     /*// Click on cascad button for Parent Entity
		        assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[2]/span[2]/cw-cascade/span/span/button");
		        mouseHoverByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[2]/span[2]/cw-cascade/span/span/button");
		        Thread.sleep(3000);
			    clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[2]/span[2]/cw-cascade/span/span/button");
			    Thread.sleep(3000);
			       
			  // Click on Close button
			   assertTextXpath("//div[4]/div/div/div[1]/button");
		       clickByXpath("//div[4]/div/div/div[1]/button");
		       Thread.sleep(3000);   */
		       
		  }
		  @Test(priority=82, enabled =true)
		  public void Parent_Response_MediaRelated() throws InterruptedException, IOException {
		       
		       // Get the Parent Response Color
			      ParentMediaResponseColor("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[4]/cw-s-response-choices/div/div/label[1]");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);	
		       
		  }
		  
		  @Test(priority=83, enabled =true)
		  public void Parent_Notes_MediaRelated() throws InterruptedException, IOException {
			  
		       //Click on Notes button to add text
			    assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a");
			    clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a");
			    //Reporter.log("Click on Notes button to add text | ");
			    Thread.sleep(5000);
			    //Thread.sleep(3000);
			      
			     // Get the Parent Note TextValue
				  ParentMediaNotevalue("//*[@id='note-details-table_info']");
				 // Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
			    
			    //Click on Close button in popup
			    assertTextXpath("//div[4]/div/div/div[3]/button");
			    clickByXpath("//div[4]/div/div/div[3]/button");
			    //Reporter.log("Click on Close button in popup | ");
			    Thread.sleep(5000);
			    Thread.sleep(3000);
			    
			  //Expand the Controls
		        assertTextXpath("//td[2]/span[1]");
		        clickByXpath("//td[2]/span[1]");
		        //Reporter.log("Expand the Controls | ");
		        Thread.sleep(3000);
		        
		  }
		  
		  @Test(priority=84, enabled =false)
		  public void Parent_Document_GlobalRelated() throws InterruptedException, IOException {
			    
			  
			  
			     //Click on Document to upload
				 //assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[9]/a[2]/a");
				  clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[9]/a[1]/a");
				  //Reporter.log("Click on Document to upload | ");
				  Thread.sleep(5000);		  
				  
				  //Control global media for document model
				  assertEquals("//*[@id='document-details-table']/thead/tr/th[3]", "Cascade Statistics");
				  //Reporter.log("Click on Page header Title | ");
				  Thread.sleep(2000);
				  //Thread.sleep(1000);
				  
				  //Checking Cascade Statistics Text for document model
				  gettext("//*[@id='document-details-table']/tbody/tr/td[3]");
				  //Reporter.log("Click on Page header Title | ");
				  Thread.sleep(2000);
				  //Thread.sleep(1000);
				  
				// Get the Parent Documents TextValue
				  ParentGlobalDocumentvalue("//*[@id='document-details-table_info']");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
				  
				  //Click on listed Document
				  assertTextXpath("//*[@id='document-details-table']/tbody/tr/td[2]");
				  clickByXpath("//*[@id='document-details-table']/tbody/tr/td[2]");
				  //Reporter.log("Click on Document to upload | ");
				  Thread.sleep(3000);
				  
				  //Click on Document to download
				  assertTextXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
				  clickByXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
				  //Reporter.log("Click on Document to upload | ");
				  Thread.sleep(3000);
				  
				  // Click on Close button		  
				  assertTextXpath("//div[4]/div/div/div[3]/button");
				  clickByXpath("//div[4]/div/div/div[3]/button");
				  //Reporter.log("Click on CLose Button | ");
				  Thread.sleep(5000); 
				  // Thread.sleep(2000); 
				  
		  }
		  
		  @Test(priority=85, enabled =true)
		  public void Parent_CascadeIcon_RiskImpact_RiskRelated() throws InterruptedException, IOException {   
			  
			 /*// Click on Response N/A
		        assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[6]/cw-s-response-choices/div/div/label[4]");
	            clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[6]/cw-s-response-choices/div/div/label[4]");
	            Thread.sleep(1000);
	            //Thread.sleep(3000);			
	*/            
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            Thread.sleep(3000);
	            
	            // Mousehover on Risk Impact
	            mouseHoverByXpath("//*[@id='body-content']/div[1]/div[3]/div/div/div[2]/table/tbody/tr[2]/td[1]/cw-cascade/span/span/button");
	            Thread.sleep(5000);
	            
		  }
	            
	     @Test(priority=86, enabled =true)
	     public void Parent_RiskLikelihood_RiskRelated() throws InterruptedException, IOException {   
	            
	         // Get the RiskLikelihood value
	       	   ParentRiskLikelihoodvalue("//*[@id='riskLikelihoodSelect']/cw-risk-choices/div/button");
	       	    Thread.sleep(3000);
	       	    
	     }
	            
	      @Test(priority=87, enabled =true)
	     public void Parent_RiskImpact_RiskRelated() throws InterruptedException, IOException {  
	            	
	       	 // Get the RiskImpact value
	       	   ParentRiskImpactvalue("//*[@id='riskImpactSelect']/cw-risk-choices/div/button");
	       	     Thread.sleep(3000);
	       	     
	      }
	      
	      @Test(priority=88, enabled =true)
	      public void Parent_RiskRating_RiskRelated() throws InterruptedException, IOException {  
	       	    
	       	    // Get the RiskRating value
	       	    ParentRiskRatingvalue("//*[@id='body-content']/div[1]/div[3]/div/div/div[2]/table/tbody/tr[1]/td[4]/div/div");
	       	   Thread.sleep(3000);         
					
		        // Click on 'GoTo next Thread' button
		        try {
		        	assertTextXpath("//*[@id='rMedia']");
		            clickByXpath("//*[@id='rMedia']");
		            //Reporter.log("First page - Click on 'GoTo next Thread' button | ");
		        }catch(Exception e)
			    {
			        e.printStackTrace();
			        Reporter.log("Click on 'GoTo next Thread' button doesn't reached | ");
			    }
		        Thread.sleep(5000);
			  Thread.sleep(5000);
			  
	      }
	      
	      @Test(priority=89, enabled =true)
	      public void Navigate_ChildEntity() throws InterruptedException, IOException {   
			  
			   // Select Child Entity from drop down
		 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			   Thread.sleep(3000);
			   
			  //Enter Created Entity Name in Search box
			   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
			   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
			   //Reporter.log("Enter Created Entity Name in Search box | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);
			   
			   //Select the Searched Entity
			   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
			   //Reporter.log("Select the Searched Entity | ");
			   Thread.sleep(5000);
			   Thread.sleep(5000);
			   Thread.sleep(5000);
			   
	      }
	      
	      @Test(priority=90, enabled =true)
	      public void Child_CascadeIcon_MediaRelated() throws InterruptedException, IOException { 
				
				 // Click on 'Review' button of Media/Asset
		        try {
		        	assertTextXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
		 	        clickByXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
		 	        Reporter.log("Click on 'Review' button of Desktop Media/Asset | ");
		        }catch(Exception e)
			    {
			         e.printStackTrace();
			         Reporter.log("Click on 'continue' button of Media/Asset doesn't work | ");
			    }
		        Thread.sleep(8000);
		        Thread.sleep(8000);
		        Thread.sleep(3000);  
		        
		        //Expand the Controls
		        assertTextXpath("//td[2]/span[1]");
		        clickByXpath("//td[2]/span[1]");
		        //Reporter.log("Expand the Controls | ");
		        Thread.sleep(5000);    
		        
		    /* // Click on cascad button for Child Entity
		        assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[2]/span[2]/cw-cascade/span/span/button");
		        mouseHoverByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[2]/span[2]/cw-cascade/span/span/button");
		        Thread.sleep(3000);
			    clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[2]/span[2]/cw-cascade/span/span/button");
			    Thread.sleep(3000);
			       
			  // Click on Close button
			   assertTextXpath("//div[4]/div/div/div[1]/button");
		       clickByXpath("//div[4]/div/div/div[1]/button");
		       Thread.sleep(3000);  */      
		       
	      }
	      
	      @Test(priority=91, enabled =true)
	      public void Child_Response_MediaRelated() throws InterruptedException, IOException { 
		       	       
		       // Get the Parent Response Color
			     ChildMediaResponseColor("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[4]/cw-s-response-choices/div/div/label[1]");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);	
		       
	      }
	      
	      @Test(priority=92, enabled =true)
	      public void Child_Notes_MediaRelated() throws InterruptedException, IOException { 
	    	  
		       //Click on Notes button to add text
			    assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a");
			    clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a");
			    //Reporter.log("Click on Notes button to add text | ");
			    Thread.sleep(5000);
			    //Thread.sleep(3000);
			      
			     // Get the Child Note TextValue
				  ChildMediaNotevalue("//*[@id='note-details-table_info']");
				 // Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
			    
			    //Click on Close button in popup
			    assertTextXpath("//div[4]/div/div/div[3]/button");
			    clickByXpath("//div[4]/div/div/div[3]/button");
			    //Reporter.log("Click on Close button in popup | ");
			    Thread.sleep(3000);
			    Thread.sleep(3000);
				  
			    //Expand the Controls
		        assertTextXpath("//td[2]/span[1]");
		        clickByXpath("//td[2]/span[1]");
		        //Reporter.log("Expand the Controls | ");
		        Thread.sleep(3000);
		        
	      }
	      
	      @Test(priority=93, enabled =false)
	      public void Child_Documents_GlobalRelated() throws InterruptedException, IOException { 
		        
		         //Click on Document to upload
				// assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[9]/a[2]/a");
				 clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[9]/a[1]/a");
				  //Reporter.log("Click on Document to upload | ");
				  Thread.sleep(5000);		  
				  
				  //Checking Cascade Statistics Field for document model
				  assertEquals("//*[@id='document-details-table']/thead/tr/th[3]", "Cascade Statistics");
				  //Reporter.log("Click on Page header Title | ");
				  Thread.sleep(2000);
				  
				  //Checking Cascade Statistics Text for document model
				  GetText("//*[@id='document-details-table']/tbody/tr/td[3]");
				  //Reporter.log("Click on Page header Title | ");
				  Thread.sleep(5000);
				  //Thread.sleep(1000);			
				  
				// Get the Parent Documents TextValue
				  ChildGlobalDocumentvalue("//*[@id='document-details-table_info']");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
				  
				//Click on listed Document
				  assertTextXpath("//*[@id='document-details-table']/tbody/tr/td[2]");
				  clickByXpath("//*[@id='document-details-table']/tbody/tr/td[2]");
				  //Reporter.log("Click on Document to upload | ");
				  Thread.sleep(3000);
				  
				  //Click on Document to download
				  assertTextXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
				  clickByXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
				  //Reporter.log("Click on Document to upload | ");
				  Thread.sleep(3000);			  
				  
				  // Click on Close button		  
				  assertTextXpath("//div[4]/div/div/div[3]/button");
				  clickByXpath("//div[4]/div/div/div[3]/button");
				  //Reporter.log("Click on CLose Button | ");
				  Thread.sleep(5000); 
				  // Thread.sleep(2000); 
		            		    
	      }
	      
	      @Test(priority=94, enabled =true)
	      public void Child_CascadeIcon_RiskImpact_RiskRelated() throws InterruptedException, IOException { 
	    	  
			 /*// Click on Response N/A
		        assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[6]/cw-s-response-choices/div/div/label[4]");
	            clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[1]/td[6]/cw-s-response-choices/div/div/label[4]");
	           // Thread.sleep(3000);
	            Thread.sleep(1000);*/
					
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            ArrowDown();
	            Thread.sleep(3000);
	            
	            // Mousehover on Risk Impact
	            mouseHoverByXpath("//*[@id='body-content']/div[1]/div[3]/div/div/div[2]/table/tbody/tr[2]/td[1]/cw-cascade/span/span/button");
	            Thread.sleep(5000);
	            
	      }
	      
	      @Test(priority=95, enabled =true)
	      public void Child_RiskLikelihood_RiskRelated() throws InterruptedException, IOException { 
	    	  
	         // Get the RiskLikelihood value
	    	   ChildRiskLikelihoodvalue("//*[@id='riskLikelihoodSelect']/cw-risk-choices/div/button");
	    	   Thread.sleep(2000);
	    	    
	      }
	      
	      @Test(priority=96, enabled =true)
	      public void Child_RiskImpact_RiskRelated() throws InterruptedException, IOException { 
	      
	    	 // Get the RiskImpact value
	    	   ChildRiskImpactvalue("//*[@id='riskImpactSelect']/cw-risk-choices/div/button");
	    	   Thread.sleep(2000);
	    	    
	      }
	      
	      @Test(priority=97, enabled =true)
	      public void Child_RiskRating_RiskRelated() throws InterruptedException, IOException { 
	    
	    	    // Get the RiskRating value
	    	    ChildRiskRatingvalue("//*[@id='body-content']/div[1]/div[3]/div/div/div[2]/table/tbody/tr[1]/td[4]/div/div");
	    	   Thread.sleep(2000);               
	           				
		        // Click on 'GoTo next Thread' button
		        try {
		        	assertTextXpath("//*[@id='rMedia']");
		            clickByXpath("//*[@id='rMedia']");
		            //Reporter.log("First page - Click on 'GoTo next Thread' button | ");
		        }catch(Exception e)
			    {
			        e.printStackTrace();
			        Reporter.log("Click on 'GoTo next Thread' button doesn't reached | ");
			    }
		        Thread.sleep(5000);
		        Thread.sleep(5000);      
		       
	      }  
	      
	      
	      
	      @Test(priority=98, enabled =true)
	      public void Compare_Response_MediaRelated() throws InterruptedException, IOException { 
		    
		         // Get the Compare ResponseColor
	    	  CompareMediaResponseColor("ParentMediaResponseColor","ChildMediaResponseColor");
			    Thread.sleep(3000);
		                  
			    
		  }
		  
	      @Test(priority=99, enabled =true)
	      public void Compare_Notes_MediaRelated() throws InterruptedException, IOException { 
		    
		         // Get the Compare ResponseColor
	    	  CompareMediaNotevalue("ParentMediaNotevalue","ChildMediaNotevalue");
			    Thread.sleep(3000);
		                  
			    
		  }
	      
	      @Test(priority=100, enabled =false)
	      public void Compare_Documents_GlobalRelated() throws InterruptedException, IOException { 
		    
		         // Get the Compare ResponseColor
	    	  CompareGlobalDocumentvalue("ParentGlobalDocumentvalue","ChildGlobalDocumentvalue");
			    Thread.sleep(3000);
		                  
			    
		  }
	      
	      
		  @Test(priority=101, enabled = true)
		  public void Compare_CascadingText_DocumentModal() throws IOException, InterruptedException {
			 
			// Get the Compare the Text Value
			  CompareTextValue("gettext","GetText");
			  Thread.sleep(3000);   
		  }
		  
		  @Test(priority=102, enabled = true)
		  public void Compare_RiskLikelihood_RiskRelated() throws IOException, InterruptedException {
			 
			// Get the Compare RiskLikelihood
			    CompareRiskLikelihood("ParentRiskLikelihood","ChildRiskLikelihood");
			    Thread.sleep(3000);  
		  }
		  
		  @Test(priority=103, enabled = true)
		  public void Compare_RiskImpact_RiskRelated() throws IOException, InterruptedException {
			 
			  //Thread.sleep(3000);
				 // Get the Compare RiskImpact
				    CompareRiskImpact("ParentRiskImpact","ChildRiskImpact");
				    Thread.sleep(3000);
		  }
		  
		  @Test(priority=104, enabled = true)
		  public void Compare_RiskRating_RiskRelated() throws IOException, InterruptedException {
			 
			// Get the Compare RiskRating 
			    CompareRiskRatingvalue("ParentRiskRating","ChildRiskRating");
			    Thread.sleep(3000); 
		  }
		
	      
	}
