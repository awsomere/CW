package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ControlGlobalMediaPage extends WrapperClass{
	
	public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "ParentStageAgain";
	  String ChildEntity = "ChildStageAgain";
	  String GrantChildEntity = "GrantChildStageAgain";
	  String GreatGrantChildEntity = "GreatGrantChildStageAgain";
	  String GreatGreatGrantChildEntity = "Great-GreatGrantChildStageAgain";
	  
	  @Test(priority=35, enabled = true)
	  public void Parent_CascadeIcon_GlobalRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(8000);
		  Thread.sleep(8000);	
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		  		 
	 //Select Risk Determination sidebar-left Module
	    try {
	    	assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
 	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
 	        Reporter.log("Select Risk Determination sidebar-left Module | ");
        }catch(Exception e)
		{
	        e.printStackTrace();
		    Reporter.log("Select Risk Determination sidebar-left Module doesn't reached | ");
		}
        Thread.sleep(3000);
        //Thread.sleep(3000);
        
        //Select Controls - Global/Media sub-module under Risk determination Module 
		  assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
		  clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
		  Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(3000);
		  		  
		    //Click on Control Type Filter drop-down
	   	     clickByXpath("//*[@id='control-type']");
	   	     Thread.sleep(3000);
	   	     clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[1]/div/ul/li[2]/a");
	   	     Thread.sleep(8000);
	   	     Thread.sleep(8000); 
	   	     Thread.sleep(8000); 	
	   	     
	   	    //Click on Parent cascade Icon
	   	    /* assertTextXpath("//*[@id='container-body']/tr[3]/td[3]/cw-cascade/span/span/button");
	   	     clickByXpath("//*[@id='container-body']/tr[3]/td[3]/cw-cascade/span/span/button");
	   	     Thread.sleep(3000);		   	 
	   	     
	   	     //Click on Close button in Parent cascade Icon
	   	     assertTextXpath("html/body/div[4]/div/div/div[1]/button");
	   	     clickByXpath("html/body/div[4]/div/div/div[1]/button");
	   	     Thread.sleep(3000); 	*/
	   	     
	  }
	  
	  @Test(priority=36, enabled = true)
	  public void Parent_Response_GlobalRelated() throws IOException, InterruptedException {
	   	     
	   	      // Get the Parent Response Color
			   ParentResponseColor("//*[@id='container-body']/tr[3]/td[4]/cw-s-response-choices/div/div/label[1]");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(1000);	
			   
			// Get the Parent Response Color
			   ParentResponseColor1("//*[@id='container-body']/tr[1]/td[4]/cw-s-response-choices/div/div/label[1]");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(1000);
			   
			// Get the Parent Response Color
			   ParentResponseColor2("//*[@id='container-body']/tr[5]/td[4]/cw-s-response-choices/div/div/label[1]");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(1000);
			   
			// Get the Parent Response Color
			   ParentResponseColor3("//*[@id='container-body']/tr[7]/td[4]/cw-s-response-choices/div/div/label[3]");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(3000);
	  }
	  
	  @Test(priority=37, enabled = true)
	  public void Parent_Notes_GlobalRelated() throws IOException, InterruptedException {	   
			   
	      	// Click on Notes button 
			  assertTextXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
			  clickByXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
			  //Reporter.log("Click on Notes button | ");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  
			 // Get the Parent Note TextValue
			  ParentGlobalNotevalue("//*[@id='note-details-table_info']");
			  //Reporter.log(" Get the Parent Note TextValue | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			// Click on Close Button in note pop-up window
			  assertTextXpath("//div[4]/div/div/div[3]/button");
			  clickByXpath("//div[4]/div/div/div[3]/button");
			  //Reporter.log("Click on Close Button in note pop-up window | ");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			   }
	  
	  @Test(priority=38, enabled = true)
	  public void Parent_Documents_GlobalRelated() throws IOException, InterruptedException {
			  
			  			  
			//Click on Document to upload
			  assertTextXpath("//*[@id='container-body']/tr[3]/td[7]/a/a");
			  clickByXpath("//*[@id='container-body']/tr[3]/td[7]/a/a");
			  //Reporter.log("Click on Document to upload | ");
			  Thread.sleep(5000);		  
			  
			  //Control global media for document model
			  assertEquals("//*[@id='document-details-table']/thead/tr/th[3]", "Cascade Statistics");
			  //Reporter.log("Click on Page header Title | ");
			  Thread.sleep(6000);
			  //Thread.sleep(1000);
			  
			// Get the Parent Documents TextValue
			  ParentGlobalDocumentvalue("//*[@id='document-details-table_info']");
			  //Reporter.log(" Get the Parent Note TextValue | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			  /*//Click on listed Document
			  assertTextXpath("//*[@id='document-details-table']/tbody/tr[1]/td[2]");
			  clickByXpath("//*[@id='document-details-table']/tbody/tr[1]/td[2]");
			  //Reporter.log("Click on Document to upload | ");
			  Thread.sleep(3000);
			  
			  //Click on Document to download
			  assertTextXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
			  clickByXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
			  //Reporter.log("Click on Document to upload | ");
			  Thread.sleep(5000);*/			  
			  
			  // Click on Close button		  
			  assertTextXpath("//div[4]/div/div/div[3]/button");
			  clickByXpath("//div[4]/div/div/div[3]/button");
			  //Reporter.log("Click on CLose Button | ");
			  Thread.sleep(5000); 
			  Thread.sleep(2000);
			  
	  }
	  
	  @Test(priority=39, enabled = true)
	  public void Parent_CascadeIcon_MediaRelated() throws IOException, InterruptedException {
			  
			//Click on Control Type Filter drop-down
	        clickByXpath("//*[@id='control-type']");
		   	 Thread.sleep(3000);
		     clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[1]/div/ul/li[3]/a");
     	     Thread.sleep(5000);
	   	     Thread.sleep(5000); 
	   	  Thread.sleep(8000);
		    Thread.sleep(8000);
	   	     Thread.sleep(5000); 	
		   	     
				 //Click on + Icon to open Control 
				  assertTextXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
				  clickByXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
				  //Reporter.log("Click on + Icon to open Control | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
				  //Thread.sleep(3000);
				    
				  //Click on Parent cascade Icon
				 /* clickByXpath("//*[@id='1-control']/td[2]/table/tbody/tr[1]/td[3]/cw-cascade/span/span/button");
				 // clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[3]/cw-cascade/span/span/button");
				  Thread.sleep(3000);		   	 
			   	     
				  //Click on Close button in Parent cascade Icon
				  assertTextXpath("html/body/div[4]/div/div/div[1]/button");
				  clickByXpath("html/body/div[4]/div/div/div[1]/button");
				  Thread.sleep(3000); 	*/
				  
	  }
	  
	  @Test(priority=40, enabled = true)
	  public void Parent_Response_MediaRelated() throws IOException, InterruptedException {  	
		  
			   	  // Get the Parent Response Color
				  //ParentResponseColor("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[4]/cw-s-response-choices/div/div/label[1]");
				  ParentMediaResponseColor("//tr[4]/td[2]/table/tbody/tr/td[5]/cw-s-response-choices/div/div/label[1]");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);	
			   	     
				  
	  }
	  
	  @Test(priority=41, enabled = true)
	  public void Parent_Notes_MediaRelated() throws IOException, InterruptedException {
	  
			      // Click on Notes button 
				  //clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[6]/div/a");
				  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[7]/div/a/i");
				  // Reporter.log("Click on Notes button | ");
				  Thread.sleep(5000);
				  //Thread.sleep(3000);
					  
				  // Get the Parent Note TextValue
				  ParentMediaNotevalue("//*[@id='note-details-table_info']");
				  //Reporter.log(" Get the Child Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
					  
				// Click on Close Button in note pop-up window
				  assertTextXpath("//div[4]/div/div/div[3]/button");
				  clickByXpath("//div[4]/div/div/div[3]/button");
				  //Reporter.log("Click on Close Button in note pop-up window | ");
				  Thread.sleep(3000);
				  Thread.sleep(2000);
				  
	  }
	  
	  @Test(priority=42, enabled = true)
	  public void Parent_Documents_MediaRelated() throws IOException, InterruptedException {
					  
			     //Click on Document to upload
				  //clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[7]/a/a");
				  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[8]/a/a/i");
				  //Reporter.log("Click on Document to upload | ");
				  Thread.sleep(5000);
				  
				  // Get the Parent Documents TextValue
				  ParentMediaDocumentvalue("//*[@id='document-details-table_info']");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
					   
				  // Click on Close button		  
				  assertTextXpath("//div[4]/div/div/div[3]/button");
				  clickByXpath("//div[4]/div/div/div[3]/button");
				  	Thread.sleep(3000); 
				  	Thread.sleep(2000); 
					  
				  	// Click on '-' Icon to close Controls
				  	assertTextXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
				  	clickByXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
				  	//Reporter.log("Click on '-' Icon to close Controls | ");
				  	Thread.sleep(3000);	  
	  }  
			  
	  
	  @Test(priority=43, enabled = true)
	  public void Parent_CascadeIcon_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000); 

	// Click on Filter button		  
	  assertTextXpath("//*[@id='cw-panelbar']/div/div[4]/ul/li[1]/cw-filter/div/span[1]/i");
	  clickByXpath("//*[@id='cw-panelbar']/div/div[4]/ul/li[1]/cw-filter/div/span[1]/i");
	  //Reporter.log("Click on CLose Button | ");
	  Thread.sleep(5000); 
	  // Thread.sleep(2000);
	  	  
	 //Enter Custom Control textbox
	assertTextXpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div/ul/li/input");
	sendvaluebyxpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div/ul/li/input", "Edit Sample custom controls");
	Thread.sleep(2000);
	//Reporter.log("Enter Created Entity Name in Search box | ");
	enter();
	Thread.sleep(3000);
	
	//CLick on Submit button
	assertTextXpath("html/body/div[4]/div/div/div[3]/button[2]");
	clickByXpath("html/body/div[4]/div/div/div[3]/button[2]");
	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
	Thread.sleep(3000);
	Thread.sleep(3000);
	
	 // Expand the icon		  
  	assertTextXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
  	clickByXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
  	Thread.sleep(5000); 
  	Thread.sleep(2000); 
	    
	  //Click on Parent cascade Icon
	 // assertTextXpath("//*[@id='0-control']/td[2]/table/tbody/tr/td[3]/cw-cascade/span/span[1]/button");
	  //clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr/td[3]/cw-cascade/span/span[1]/button");
	  //Thread.sleep(5000);		   	 
	     
	  //Click on Close button in Parent cascade Icon
	  //assertTextXpath("html/body/div[4]/div/div/div[1]/button");
	 // clickByXpath("html/body/div[4]/div/div/div[1]/button");
	  Thread.sleep(5000); 	  
	 
	  }
	  
	  @Test(priority=44, enabled = true)
	  public void Parent_Response_NewCustomControl() throws IOException, InterruptedException {
	   
	  Thread.sleep(5000);
	  //Get the Parent Response Color
	  ParentCustomControlResponseColor("//td[5]/cw-s-response-choices/div/div/label[1]");
	  Thread.sleep(1000);	
	  
	  }
	  
	  @Test(priority=45, enabled = true)
	  public void Parent_Notes_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000); 
	     
      // Click on Notes button 
	  assertTextXpath("//td[7]/div/a");
	  clickByXpath("//td[7]/div/a");
	  // Reporter.log("Click on Notes button | ");
	  Thread.sleep(3000);
	  //Thread.sleep(3000);
		  
	  // Get the Parent Note TextValue
	  ParentCustomControlNotevalue("//*[@id='note-details-table_info']");
	  //Reporter.log(" Get the Child Note TextValue | ");
	  Thread.sleep(3000);
	  //Thread.sleep(3000);
		  
	// Click on Close Button in note pop-up window
	  assertTextXpath("//div[4]/div/div/div[3]/button");
	  clickByXpath("//div[4]/div/div/div[3]/button");
	  //Reporter.log("Click on Close Button in note pop-up window | ");
	  Thread.sleep(5000);
	  Thread.sleep(2000);
	  
	  }
	  
	  @Test(priority=46, enabled = true)
	  public void Parent_Documents_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
		  
      //Click on Document to upload
	  assertTextXpath("//td[8]/a/a/i");
	  clickByXpath("//td[8]/a/a/i");
	  //Reporter.log("Click on Document to upload | ");
	  Thread.sleep(5000);
	  
	  // Get the Parent Documents TextValue
	  ParentCustomControlDocumentvalue("//*[@id='document-details-table_info']");
	  //Reporter.log(" Get the Parent Note TextValue | ");
	  Thread.sleep(3000);
	  //Thread.sleep(3000);
		   
	  // Click on Close button		  
	  assertTextXpath("//div[4]/div/div/div[3]/button");
	  clickByXpath("//div[4]/div/div/div[3]/button");
	  	Thread.sleep(5000); 
	  	Thread.sleep(2000); 
	  	
	 // Expand the icon		  
	  	assertTextXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
	  	clickByXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
	  	Thread.sleep(5000); 
	  	Thread.sleep(2000); 
	  	
	  //Click on 'Clear Filter' Button 
   	  	assertTextXpath("//i[2]");
   	  	clickByXpath("//i[2]");
   	  	Reporter.log("Click on 'Clear Filter' Button  | ");
   	  	Thread.sleep(8000);
   	  	Thread.sleep(8000);
	  	
	  }
	  
	  @Test(priority=47, enabled = true)
	  public void Parent_Response_NewControl() throws IOException, InterruptedException {	  
				
			//Click on Control Type Filter drop-down
				clickByXpath("//*[@id='view-filter']");
				Thread.sleep(3000);
				clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[2]/div/ul/li[3]/a");
				Thread.sleep(5000);
				Thread.sleep(5000); 
				Thread.sleep(8000);
			    Thread.sleep(8000);
				Thread.sleep(5000);
				
				 // Get the Parent New COntrol Response Color
				ParentNewControlResponseColor("//tr[4]/td[2]/table/tbody/tr/td[5]/cw-s-response-choices/div/div/label[4]");
				//Reporter.log(" Get the Parent Note TextValue | ");
				Thread.sleep(3000);
				
	  }
	  
	
	 @Test(priority=48, enabled = true)
	  public void Parent_Notes_NewControl() throws IOException, InterruptedException {
	  
	  
		 // Click on Notes button 
		  assertTextXpath("//tr[4]/td[2]/table/tbody/tr/td[7]/div/a");
		  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[7]/div/a");
	   	  // Reporter.log("Click on Notes button | ");
	   	  Thread.sleep(3000);
	   	  //Thread.sleep(3000);
			    
			     // Get the Child Note TextValue
				  ParentNewControlNotevalue("//*[@id='note-details-table_info']");
				 // Reporter.log(" Get the Child Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
				  
				// Click on Close Button in note pop-up window
				    assertTextXpath("//div[4]/div/div/div[3]/button");
				    clickByXpath("//div[4]/div/div/div[3]/button");
				    //Reporter.log("Click on Close Button in note pop-up window | ");
				    Thread.sleep(5000);
				    //Thread.sleep(3000);
				    //Thread.sleep(3000);
				    Thread.sleep(3000);
				    }
				    
	  @Test(priority=49, enabled = true)
	  public void Parent_Documents_NewControl() throws IOException, InterruptedException {
				    
		//Click on Document to upload
		  assertTextXpath("//tr[4]/td[2]/table/tbody/tr/td[8]/a/a");
		  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[8]/a/a");
		  //Reporter.log("Click on Document to upload | ");
		  Thread.sleep(5000);
				    
				  //Checking Cascade Statistics
				    assertEquals("//*[@id='document-details-table']/thead/tr/th[3]", "Cascade Statistics");
				    //Reporter.log("Click on Page header Title | ");
				    Thread.sleep(2000);
				    //Thread.sleep(1000);
				    
				    // Get the Child Documents TextValue
				    ParentNewControlDocumentvalue("//*[@id='document-details-table_info']");
				    //Reporter.log(" Get the Parent Note TextValue | ");
				    Thread.sleep(3000);
				    //Thread.sleep(3000);
		 	   
				    // Click on Close button		  
				    assertTextXpath("//div[4]/div/div/div[3]/button");
				    clickByXpath("//div[4]/div/div/div[3]/button");
				    //Reporter.log("Click on CLose Button | ");
				    Thread.sleep(3000); 
				    Thread.sleep(2000); 	 
				    
				  //Click on Control Type Filter drop-down
					clickByXpath("//*[@id='view-filter']");
					Thread.sleep(3000);
					clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[2]/div/ul/li[1]/a");
					Thread.sleep(5000);
					Thread.sleep(5000); 
					Thread.sleep(5000);
				    }
			  
	  @Test(priority=50, enabled = true)
	  public void Navigate_ChildEntity() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
		  
			  //Click on the Created new Entity drop-down from Header 
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
		    	Thread.sleep(3000);
						   
		    	//Enter Created Entity Name in Search box
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    	sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		    	//Reporter.log("Enter Created Entity Name in Search box | ");
		    	Thread.sleep(3000);
		    	//Thread.sleep(3000);
		    	
		    	//Select the Searched Entity
				clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
				//Reporter.log("Select the Searched Entity | ");
				Thread.sleep(8000);
				Thread.sleep(8000);
				Thread.sleep(8000);
				Thread.sleep(8000);
				Thread.sleep(8000);
				
	  }
	  
	  @Test(priority=51, enabled = true)
	  public void Child_CascadeIcon_GlobalRelated() throws IOException, InterruptedException {
						   
				//Click on Control Type Filter drop-down
				clickByXpath("//*[@id='control-type']");
				Thread.sleep(3000);
				clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[1]/div/ul/li[2]/a");
				Thread.sleep(8000);
				Thread.sleep(8000); 
				Thread.sleep(8000);
						   		
			    //Click on Child cascade Icon
				/*assertTextXpath("//*[@id='container-body']/tr[3]/td[3]/cw-cascade/span/span/button");
				clickByXpath("//*[@id='container-body']/tr[3]/td[3]/cw-cascade/span/span/button");
				Thread.sleep(3000);
				//Thread.sleep(3000);			
				
				//Click on Close button in child cascade Icon
				assertTextXpath("html/body/div[4]/div/div/div[1]/button");
				clickByXpath("html/body/div[4]/div/div/div[1]/button");
			    Thread.sleep(3000);	*/
			    
	  }
	  
	  @Test(priority=52, enabled = true)
	  public void Child_Response_GlobalRelated() throws IOException, InterruptedException {
		  
			    // Get the Child Response Color
				ChildResponseColor("//*[@id='container-body']/tr[3]/td[4]/cw-s-response-choices/div/div/label[1]");
				//Reporter.log(" Get the Parent Note TextValue | ");
				Thread.sleep(3000);
				
				// Get the Parent Response Color
			     ChildResponseColor1("//*[@id='container-body']/tr[1]/td[4]/cw-s-response-choices/div/div/label[1]");
			    //Reporter.log(" Get the Parent Note TextValue | ");
				   Thread.sleep(1000);
				   
				// Get the Parent Response Color
				ChildResponseColor2("//*[@id='container-body']/tr[5]/td[4]/cw-s-response-choices/div/div/label[1]");
				   //Reporter.log(" Get the Parent Note TextValue | ");
				   Thread.sleep(1000);
				   
				// Get the Parent Response Color
				   ChildResponseColor3("//*[@id='container-body']/tr[7]/td[4]/cw-s-response-choices/div/div/label[3]");
				   //Reporter.log(" Get the Parent Note TextValue | ");
				   Thread.sleep(3000);
				   
	  }
	  
	  @Test(priority=53, enabled = true)
	  public void Child_Notes_GlobalRelated() throws IOException, InterruptedException {
						   	
			    // Click on Notes button 
			    assertTextXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
			    clickByXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
			    //Reporter.log("Click on Notes button | ");
			    Thread.sleep(5000);
			    //Thread.sleep(3000);
			    
			     // Get the Child Note TextValue
				  ChildGlobalNotevalue("//*[@id='note-details-table_info']");
				 // Reporter.log(" Get the Child Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
				  
				// Click on Close Button in note pop-up window
				    assertTextXpath("//div[4]/div/div/div[3]/button");
				    clickByXpath("//div[4]/div/div/div[3]/button");
				    //Reporter.log("Click on Close Button in note pop-up window | ");
				    Thread.sleep(5000);
				    //Thread.sleep(3000);
				    //Thread.sleep(3000);
				    Thread.sleep(3000);
				    
	  }
	  
	  @Test(priority=54, enabled = true)
	  public void Child_Documents_GlobalRelated() throws IOException, InterruptedException {
				    
				    //Click on Document to upload
				    assertTextXpath("//*[@id='container-body']/tr[3]/td[7]/a/a");
				    clickByXpath("//*[@id='container-body']/tr[3]/td[7]/a/a");
				    //Reporter.log("Click on Document to upload | ");
				    Thread.sleep(5000);
				    
				  //Control global media for document model
				    assertEquals("//*[@id='document-details-table']/thead/tr/th[3]", "Cascade Statistics");
				    //Reporter.log("Click on Page header Title | ");
				    Thread.sleep(5000);
				    //Thread.sleep(1000);
				    
				 // Get the Child Documents TextValue
				    ChildGlobalDocumentvalue("//*[@id='document-details-table_info']");
				    //Reporter.log(" Get the Parent Note TextValue | ");
				    Thread.sleep(5000);
				    //Thread.sleep(3000);
					  
				    /*//Click on listed Document
				    assertTextXpath("//*[@id='document-details-table']/tbody/tr[1]/td[2]");
				    clickByXpath("//*[@id='document-details-table']/tbody/tr[1]/td[2]");
				    //Reporter.log("Click on Document to upload | ");
				    Thread.sleep(3000);
					  
				    //Click on Document to download
				    assertTextXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
				    clickByXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[3]");
				    //Reporter.log("Click on Document to upload | ");
				    Thread.sleep(3000);*/
		 	   
				    // Click on Close button		  
				    assertTextXpath("//div[4]/div/div/div[3]/button");
				    clickByXpath("//div[4]/div/div/div[3]/button");
				    //Reporter.log("Click on CLose Button | ");
				    Thread.sleep(3000); 
				    Thread.sleep(2000); 
				    
	  }
	  
	  @Test(priority=55, enabled = true)
	  public void Child_CascadeIcon_MediaRelated() throws IOException, InterruptedException {
				    
				    
		  //Click on Control Type Filter drop-down
		  clickByXpath("//*[@id='control-type']");
		  Thread.sleep(3000);
		  clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[1]/div/ul/li[3]/a");
		  Thread.sleep(5000);
		  Thread.sleep(5000); 
		  Thread.sleep(5000); 	
		  
		  //Click on + Icon to open Control 
		  assertTextXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
		  clickByXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
		  //Reporter.log("Click on + Icon to open Control | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  //Click on Parent cascade Icon
		  /*clickByXpath("//*[@id='1-control']/td[2]/table/tbody/tr[1]/td[3]/cw-cascade/span/span/button");
		  // clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[3]/cw-cascade/span/span/button");
		  Thread.sleep(3000);		   	 
		  
		  //Click on Close button in Parent cascade Icon
		  assertTextXpath("html/body/div[4]/div/div/div[1]/button");
		  clickByXpath("html/body/div[4]/div/div/div[1]/button");
		  Thread.sleep(3000); 	*/
						  
	  }	
	  
	  @Test(priority=56, enabled = true)
	  public void Child_Response_MediaRelated() throws IOException, InterruptedException {
		  
		  // Get the Parent Response Color
		  //ParentResponseColor("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[4]/cw-s-response-choices/div/div/label[1]");
		  ChildMediaResponseColor("//tr[4]/td[2]/table/tbody/tr/td[5]/cw-s-response-choices/div/div/label[1]");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);	
		  
	  }
	  
	  @Test(priority=57, enabled = true)
	  public void Child_Notes_MediaRelated() throws IOException, InterruptedException {
		  
		  // Click on Notes button 
		  //clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[6]/div/a");
		  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[7]/div/a/i");
		  // Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  // Get the Parent Note TextValue
		  ChildMediaNotevalue("//*[@id='note-details-table_info']");
		  //Reporter.log(" Get the Child Note TextValue | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  // Click on Close Button in note pop-up window
		  assertTextXpath("//div[4]/div/div/div[3]/button");
		  clickByXpath("//div[4]/div/div/div[3]/button");
		  //Reporter.log("Click on Close Button in note pop-up window | ");
		  Thread.sleep(3000);
		  Thread.sleep(2000);
		  
	  }
	  
	  @Test(priority=58, enabled = true)
	  public void Child_Documents_MediaRelated() throws IOException, InterruptedException {
		  
		  //Click on Document to upload
		  //clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[7]/a/a");
		  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[8]/a/a/i");
		  //Reporter.log("Click on Document to upload | ");
		  Thread.sleep(5000);
		  
		  // Get the Parent Documents TextValue
		  ChildMediaDocumentvalue("//*[@id='document-details-table_info']");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  // Click on Close button		  
		  assertTextXpath("//div[4]/div/div/div[3]/button");
		  clickByXpath("//div[4]/div/div/div[3]/button");
		  Thread.sleep(3000); 
		  Thread.sleep(2000); 
		  
		  // Click on '-' Icon to close Controls
		  assertTextXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
		  clickByXpath("//*[@id='container-body']/tr[3]/td[3]/span[1]");
		  //Reporter.log("Click on '-' Icon to close Controls | ");
		  Thread.sleep(3000);
						  	
	  }
	  
	  @Test(priority=59, enabled = true)
	  public void Child_CascadeIcon_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
	  	     
	   		// Click on Filter button		  
	   	  assertTextXpath("//*[@id='cw-panelbar']/div/div[4]/ul/li[1]/cw-filter/div/span[1]/i");
	   	  clickByXpath("//*[@id='cw-panelbar']/div/div[4]/ul/li[1]/cw-filter/div/span[1]/i");
	   	  //Reporter.log("Click on CLose Button | ");
	   	  Thread.sleep(5000); 
	   	  // Thread.sleep(2000);
	   	  
	   	  
	   	 //Enter Custom Control textbox
	     	assertTextXpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div/ul/li/input");
	     	sendvaluebyxpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[1]/div[2]/div/div/ul/li/input", "Edit Sample custom controls");
	     	//Reporter.log("Enter Created Entity Name in Search box | ");
	     	enter();
	     	Thread.sleep(3000);
	     	
	     	//CLick on Submit button
	     	assertTextXpath("html/body/div[4]/div/div/div[3]/button[2]");
	     	clickByXpath("html/body/div[4]/div/div/div[3]/button[2]");
	     	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
	     	Thread.sleep(3000);
	     	Thread.sleep(3000);
	     	
	     	 // Expand the icon		  
	      	assertTextXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
	      	clickByXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
	      	Thread.sleep(5000); 
	      	Thread.sleep(2000); 
	   	    
	   	  //Click on Child cascade Icon
	   	  //assertTextXpath("//*[@id='0-control']/td[2]/table/tbody/tr/td[3]/cw-cascade/span/span/button");
	   	  //clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr/td[3]/cw-cascade/span/span/button");
	   	  //Thread.sleep(5000);		   	 
	    	     
	   	  //Click on Close button in Parent cascade Icon
	   	  //assertTextXpath("html/body/div[4]/div/div/div[1]/button");
	   	 // clickByXpath("html/body/div[4]/div/div/div[1]/button");
	   	  Thread.sleep(5000); 	
	  }
	  
	  @Test(priority=60, enabled = true)
	  public void Child_Response_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(8000);
	    	     
	      // Get the Parent Response Color
		  ChildCustomControlResponseColor("//td[5]/cw-s-response-choices/div/div/label[1]");
	   	  //Reporter.log(" Get the Parent Note TextValue | ");
	   	  Thread.sleep(3000);	
	    	     
	  }
	  
	  @Test(priority=61, enabled = true)
	  public void Child_Notes_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
	       // Click on Notes button 
		  assertTextXpath("//td[7]/div/a");
		  clickByXpath("//td[7]/div/a");
	   	  // Reporter.log("Click on Notes button | ");
	   	  Thread.sleep(3000);
	   	  //Thread.sleep(3000);
	   		  
	   	  // Get the Parent Note TextValue
	   	  ChildCustomControlNotevalue("//*[@id='note-details-table_info']");
	   	  //Reporter.log(" Get the Child Note TextValue | ");
	   	  Thread.sleep(3000);
	   	  //Thread.sleep(3000);
	   		  
	   	// Click on Close Button in note pop-up window
	   	  assertTextXpath("//div[4]/div/div/div[3]/button");
	   	  clickByXpath("//div[4]/div/div/div[3]/button");
	   	  //Reporter.log("Click on Close Button in note pop-up window | ");
	   	  Thread.sleep(5000);
	   	  Thread.sleep(2000);
	   	  
	  }
	  
	  @Test(priority=62, enabled = true)
	  public void Child_Documents_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
	   		  
	      //Click on Document to upload
		  assertTextXpath("//td[8]/a/a/i");
		  clickByXpath("//td[8]/a/a/i");
	   	  //Reporter.log("Click on Document to upload | ");
	   	  Thread.sleep(5000);
	   	  
	   	  // Get the Parent Documents TextValue
	   	  ChildCustomControlDocumentvalue("//*[@id='document-details-table_info']");
	   	  //Reporter.log(" Get the Parent Note TextValue | ");
	   	  Thread.sleep(3000);
	   	  //Thread.sleep(3000);
	   		   
	   	  // Click on Close button		  
	   	  assertTextXpath("//div[4]/div/div/div[3]/button");
	   	  clickByXpath("//div[4]/div/div/div[3]/button");
	   	  	Thread.sleep(5000); 
	   	  	Thread.sleep(2000); 
	   	  	
	   	    //Click on 'Clear Filter' Button 
	   	  	assertTextXpath("//i[2]");
	   	  	clickByXpath("//i[2]");
	   	  	Reporter.log("Click on 'Clear Filter' Button  | ");
	   	  	Thread.sleep(8000);
	   	  	Thread.sleep(5000);
	  }
	  
	  
	  
	  @Test(priority=63, enabled = true)
	  public void Child_Response_NewControl() throws IOException, InterruptedException {					  
				    
				 //Click on Control Type Filter drop-down
					clickByXpath("//*[@id='view-filter']");
					Thread.sleep(3000);
					clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[2]/div/ul/li[3]/a");
					Thread.sleep(5000);
					Thread.sleep(5000); 
					Thread.sleep(5000);
					
					 // Get the Parent New COntrol Response Color
					ChildNewControlResponseColor("//tr[4]/td[2]/table/tbody/tr/td[5]/cw-s-response-choices/div/div/label[4]");
					//Reporter.log(" Get the Parent Note TextValue | ");
					Thread.sleep(3000);
	  }
	  
	  @Test(priority=64, enabled = true)
	  public void Child_Notes_NewControl() throws IOException, InterruptedException {
	  
							   	
		  // Click on Notes button 
		  assertTextXpath("//tr[4]/td[2]/table/tbody/tr/td[7]/div/a");
		  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[7]/div/a");
	   	  // Reporter.log("Click on Notes button | ");
	   	  Thread.sleep(3000);
	   	  //Thread.sleep(3000);
				    
				     // Get the Child Note TextValue
					  ChildNewControlNotevalue("//*[@id='note-details-table_info']");
					 // Reporter.log(" Get the Child Note TextValue | ");
					  Thread.sleep(3000);
					  //Thread.sleep(3000);
					  
					// Click on Close Button in note pop-up window
					    assertTextXpath("//div[4]/div/div/div[3]/button");
					    clickByXpath("//div[4]/div/div/div[3]/button");
					    //Reporter.log("Click on Close Button in note pop-up window | ");
					    Thread.sleep(5000);
					    //Thread.sleep(3000);
					    //Thread.sleep(3000);
					    Thread.sleep(3000);
					    
	  }
	  
	  @Test(priority=65, enabled = true)
	  public void Child_Documents_NewControl() throws IOException, InterruptedException {
					    
		//Click on Document to upload
		  assertTextXpath("//tr[4]/td[2]/table/tbody/tr/td[8]/a/a");
		  clickByXpath("//tr[4]/td[2]/table/tbody/tr/td[8]/a/a");
		  //Reporter.log("Click on Document to upload | ");
		  Thread.sleep(5000);
		  
		  //Checking Cascade Statistics
		  assertEquals("//*[@id='document-details-table']/thead/tr/th[3]", "Cascade Statistics");
		  //Reporter.log("Click on Page header Title | ");
		  Thread.sleep(2000);
		  //Thread.sleep(1000);
		  
		  // Get the Child Documents TextValue
		  ChildNewControlDocumentvalue("//*[@id='document-details-table_info']");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  // Click on Close button		  
		  assertTextXpath("//div[4]/div/div/div[3]/button");
		  clickByXpath("//div[4]/div/div/div[3]/button");
		  //Reporter.log("Click on CLose Button | ");
		  Thread.sleep(3000); 
		  Thread.sleep(2000);
		  
		//Click on Control Type Filter drop-down
			clickByXpath("//*[@id='view-filter']");
			Thread.sleep(3000);
			clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[2]/div/ul/li[1]/a");
			Thread.sleep(5000);
			Thread.sleep(5000);
		  
	  }
	  
 
	  @Test(priority=66, enabled = true)
	  public void Compare_Response_GlobalRelated() throws IOException, InterruptedException {
	   	     
		      //Get the Compare the Response Color
		       CompareResponseColor("ParentResponse","ChildResponse");
			   Thread.sleep(1000);	
			   
			 //Get the Compare the Response Color
		       CompareResponseColor1("ParentResponse1","ChildResponse1");
			   Thread.sleep(1000);	
			   
			 //Get the Compare the Response Color
		       CompareResponseColor2("ParentResponse2","ChildResponse2");
			   Thread.sleep(1000);	
			   
			 //Get the Compare the Response Color
		       CompareResponseColor3("ParentResponse3","ChildResponse3");
			   Thread.sleep(1000);	
	  }
	   	     
	  @Test(priority=67, enabled = true)
	  public void Compare_Notes_GlobalRelated() throws IOException, InterruptedException {
	   
		  //Thread.sleep(3000);
		  
	
		  // Get the Compare the Note TextValue
		  CompareGlobalNotevalue("ParentGlobalNote","ChildGlobalNote");
		  Thread.sleep(3000);
			  
		  
	  }
	  
	  @Test(priority=68, enabled = true)
	  public void Compare_Documents_GlobalRelated() throws IOException, InterruptedException {
	   
		//  Thread.sleep(3000);
		// Get the Compare the Documents TextValue
		    CompareGlobalDocumentvalue("ParentGlobalDocument","ChildGlobalDocument");
		    Thread.sleep(3000);
		 
	  }  
	  
	  
	  @Test(priority=69, enabled = true)
	  public void Compare_Response_MediaRelated() throws IOException, InterruptedException {
	   	     
		      //Get the Compare the Response Color
		       CompareMediaResponseColor("ParentMediaResponse","ChildMediaResponse");
			   Thread.sleep(1000);	
			   
			/* //Get the Compare the Response Color
		       CompareResponseColor1("ParentResponse1","ChildResponse1");
			   Thread.sleep(1000);	
			   
			 //Get the Compare the Response Color
		       CompareResponseColor2("ParentResponse2","ChildResponse2");
			   Thread.sleep(1000);	
			   
			 //Get the Compare the Response Color
		       CompareResponseColor3("ParentResponse3","ChildResponse3");
			   Thread.sleep(1000);	*/
	  }
	   	     
	  @Test(priority=70, enabled = true)
	  public void Compare_Notes_MediaRelated() throws IOException, InterruptedException {
	   
		  //Thread.sleep(3000);
		  
	
		  // Get the Compare the Note TextValue
		  CompareMediaNotevalue("ParentMediaNote","ChildMediaNote");
		  Thread.sleep(3000);
			  
		  
	  }
	  
	  @Test(priority=71, enabled = true)
	  public void Compare_Documents_MediaRelated() throws IOException, InterruptedException {
	   
		//  Thread.sleep(3000);
		// Get the Compare the Documents TextValue
		    CompareMediaDocumentvalue("ParentMediaDocument","ChildMediaDocument");
		    Thread.sleep(3000);
		 
	  }  
	  
	  @Test(priority=72, enabled = true)
	   public void Compare_Response_NewCustomControl() throws IOException, InterruptedException {
		  
		//  Thread.sleep(3000);
		     
		  // Get the Compare the Response Color
		  CompareCustomControlResponseColor("ParentCustomControlResponse","ChildCustomControlResponse");
		Thread.sleep(3000);
	  	

}
	  
	  @Test(priority=73, enabled = true)
	   public void Compare_Notes_NewCustomControl() throws IOException, InterruptedException {
		  
		//  Thread.sleep(3000);
		  
		// Get the Compare the Note TextValue
		  CompareCustomControlNotevalue("ParentCustomControlNote","ChildCustomControlNote");
		  Thread.sleep(3000);
		 
		  }	
	  
	  @Test(priority=74, enabled = true)
	  public void Compare_Documents_NewCustomControl() throws IOException, InterruptedException {
	   
		//  Thread.sleep(5000);
		// Get the Compare the Documents TextValue
		    CompareCustomControlDocumentvalue("ParentCustomControlDocument","ChildCustomControlDocument");
		    Thread.sleep(3000);
		 
	  }  
	  
	  
	  @Test(priority=75, enabled = true)
	  public void Compare_Response_NewControl() throws IOException, InterruptedException {
		  
		  
		  // Get the Compare the Response Color
		  CompareNewControlResponseColor("ParentNewControlResponseColor","ChildNewControlResponseColor");
		  Thread.sleep(3000);
		  
	  }
	  
	  
	  @Test(priority=76, enabled = true)
	  public void Compare_Notes_NewControl() throws IOException, InterruptedException {
		  
		  
		  // Get the Compare the Response Color
		  CompareNewControlNotevalue("ParentNewControlNote","ChildNewControlNote");
		  Thread.sleep(3000);
		  
	  }
	  
	  
	  @Test(priority=77, enabled = true)
	  public void Compare_Documents_NewControl() throws IOException, InterruptedException {
		  
		  
		  
		  // Get the Compare the Response Color
		  CompareNewControlDocumentvalue("ParentNewControlDocumentvalue","ChildNewControlDocumentvalue");
		  Thread.sleep(3000);
		  
	  }
		
	  
}

