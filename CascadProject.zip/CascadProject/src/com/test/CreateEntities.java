package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class CreateEntities extends WrapperClass {
	

	  public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "ParentStageAgain";
	  String ChildEntity = "ChildStageAgain";
	  String GrantChildEntity = "GrantChildStageAgain";
	  String GreatGrantChildEntity = "GreatGrantChildStageAgain";
	  String GreatGreatGrantChildEntity = "Great-GreatGrantChildStageAgain";
	  
	  @Test(priority=1, enabled = true)
	   public void Create_ChildEntity_Cascading() throws IOException, InterruptedException {
		  	  
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		  
		   //Close Dashboard 
	 	    assertTextXpath("//*[@id='sidebar-left']/ul/li[1]/a/span[2]");
			clickByXpath("//*[@id='sidebar-left']/ul/li[1]/a/span[2]");
			Thread.sleep(5000);
		  
		     //Click on Full screen
	 	    assertTextXpath("//*[@id='fullscreen']/i");
			clickByXpath("//*[@id='fullscreen']/i");
			Thread.sleep(5000);
					   
			// Testcase 1
		   //Click on Manage Account Module
			assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
			clickByXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
			Reporter.log("Click on Manage Account Module | ");
			Thread.sleep(3000);
			//Thread.sleep(3000);
			   
			//Click on Cascading Sub-Module
			assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[7]/a");
			clickByXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[7]/a");
			Reporter.log("Click on Cascading Sub-Module | ");
			Thread.sleep(5000);
			//Thread.sleep(3000);
			
			//Click on Entity List button for continue
			assertTextXpath("//*[@id='introscreen']/div/div/div[2]/div[1]/a");
			clickByXpath("//*[@id='introscreen']/div/div/div[2]/div[1]/a");
			Reporter.log("Click on Cascading Sub-Module | ");
			Thread.sleep(5000);
			Thread.sleep(3000);
	     
	     //Click on New Button
	     assertTextXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     clickByXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     Reporter.log("Click on New Button | ");
	     Thread.sleep(5000);
	     Thread.sleep(2000);
	     
	     //Enter Entity name
	     sendvaluebyxpath("//*[@id='entity-name']", ChildEntity);
	     Reporter.log("Enter Entity name | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='industry-type']", "Healthcare");
	     Reporter.log("Select Industry Type from drop-down | ");
	     Thread.sleep(2000);		
	     //Thread.sleep(3000);
	     
	     //Select Sub-Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='clearwater-entity-type']", "Clinical Research");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select State from drop-down
	     selectByXpath_Visibletext("//*[@id='state']", "AZ - Arizona");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(3000);
	     //Thread.sleep(3000);
	     		     
	     //Enter the Number of Employees 
	     sendvaluebyxpath("//*[@id='number_of_employees']", "1000");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	     //Select the Products IRM|Analysis� 
	     assertTextXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     clickByXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     Reporter.log("Select the Products IRM|Analysis�  | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     Thread.sleep(1000);
	     
	     //Enter the ParentEntity Name in drop-down
	     selectByXpath_Visibletext("//*[@id='parent-entity']", ParentEntity);
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	     //Select Yes for this entity be a parent and cascade data to other entities
	     assertTextXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     clickByXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     Reporter.log("Select Yes for this entity be a parent and cascade data to other entities | ");
	     Thread.sleep(3000);
	     //Thread.sleep(3000);
	     
	     // Click on Save button
	     assertTextXpath("//*[@id='submit-button']");
	     clickByXpath("//*[@id='submit-button']");
	     Reporter.log("Click on Save button | ");
	     Thread.sleep(5000);
	     Thread.sleep(3000);
	    
	  }
	  
	  @Test(priority=2, enabled = true)
	   public void Create_GrandChildEntity_Cascading() throws IOException, InterruptedException {
	     
	     //Click on New Button
	     assertTextXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     clickByXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     Reporter.log("Click on New Button | ");
	     Thread.sleep(5000);
	     Thread.sleep(3000);
	     		     
	   //Enter Entity name
	     sendvaluebyxpath("//*[@id='entity-name']", GrantChildEntity);
	     Reporter.log("Enter Entity name | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='industry-type']", "Healthcare");
	     Reporter.log("Select Industry Type from drop-down | ");
	     Thread.sleep(2000);		
	     //Thread.sleep(3000);
	     
	     //Select Sub-Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='clearwater-entity-type']", "Clinical Research");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select State from drop-down
	     selectByXpath_Visibletext("//*[@id='state']", "AZ - Arizona");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Enter the Number of Employees 
	     sendvaluebyxpath("//*[@id='number_of_employees']", "1000");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	     //Select the Products IRM|Analysis� 
	     assertTextXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     clickByXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     Reporter.log("Select the Products IRM|Analysis�  | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     Thread.sleep(1000);
	     
	     //Enter the ParentEntity Name in drop-down
	     selectByXpath_Visibletext("//*[@id='parent-entity']", ChildEntity);
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	     //Select Yes for this entity be a parent and cascade data to other entities
	     assertTextXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     clickByXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     Reporter.log("Select Yes for this entity be a parent and cascade data to other entities | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     
	     // Click on Save button
	     assertTextXpath("//*[@id='submit-button']");
	     clickByXpath("//*[@id='submit-button']");
	     Reporter.log("Click on Save button | ");
	     Thread.sleep(5000);
	     Thread.sleep(3000);
	    
	  }
	  
	  @Test(priority=3, enabled = true)
	   public void Create_GreatGrandChildEntity_Cascading() throws IOException, InterruptedException {
	     
	     //Click on New Button
	     assertTextXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     clickByXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     Reporter.log("Click on New Button | ");
	     Thread.sleep(5000);
	     Thread.sleep(3000);
	     
	     //Enter Entity name
	     sendvaluebyxpath("//*[@id='entity-name']", GreatGrantChildEntity);
	     Reporter.log("Enter Entity name | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='industry-type']", "Healthcare");
	     Reporter.log("Select Industry Type from drop-down | ");
	     Thread.sleep(2000);		
	     //Thread.sleep(3000);
	     
	     //Select Sub-Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='clearwater-entity-type']", "Clinical Research");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select State from drop-down
	     selectByXpath_Visibletext("//*[@id='state']", "AZ - Arizona");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		        
	     		     
	     //Enter the Number of Employees 
	     sendvaluebyxpath("//*[@id='number_of_employees']", "1000");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	     //Select the Products IRM|Analysis� 
	     assertTextXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     clickByXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     Reporter.log("Select the Products IRM|Analysis�  | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     Thread.sleep(1000);
	     
	     //Enter the ParentEntity Name in drop-down
	     selectByXpath_Visibletext("//*[@id='parent-entity']", GrantChildEntity);
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	     //Select Yes for this entity be a parent and cascade data to other entities
	     assertTextXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     clickByXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     Reporter.log("Select Yes for this entity be a parent and cascade data to other entities | ");
	     Thread.sleep(3000);
	     Thread.sleep(3000);
	     
	     // Click on Save button
	     assertTextXpath("//*[@id='submit-button']");
	     clickByXpath("//*[@id='submit-button']");
	     Reporter.log("Click on Save button | ");
	     Thread.sleep(5000);
	     Thread.sleep(2000);
	     
	  }
	  
	  @Test(priority=4, enabled = true)
	   public void Create_GreatGreatGrantChildEntity_Cascading() throws IOException, InterruptedException {
	     
	     
	   //Click on New Button
	     assertTextXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     clickByXpath("//*[@id='locations_wrapper']/div[1]/div[1]/div/a[1]");
	     Reporter.log("Click on New Button | ");
	     Thread.sleep(5000);
	     Thread.sleep(3000);
	     		     
	   //Enter Entity name
	     sendvaluebyxpath("//*[@id='entity-name']", GreatGreatGrantChildEntity);
	     Reporter.log("Enter Entity name | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='industry-type']", "Healthcare");
	     Reporter.log("Select Industry Type from drop-down | ");
	     Thread.sleep(2000);		
	     //Thread.sleep(3000);
	     
	     //Select Sub-Industry Type from drop-down
	     selectByXpath_Visibletext("//*[@id='clearwater-entity-type']", "Clinical Research");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Select State from drop-down
	     selectByXpath_Visibletext("//*[@id='state']", "AZ - Arizona");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     		     
	     //Enter the Number of Employees 
	     sendvaluebyxpath("//*[@id='number_of_employees']", "1000");
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	     //Select the Products IRM|Analysis� 
	     assertTextXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     clickByXpath("//*[@id='locations-form']/div[2]/div[1]/div/div[2]/div[1]/div/div/label");
	     Reporter.log("Select the Products IRM|Analysis�  | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
	     
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     ArrowDown();
	     Thread.sleep(1000);
	     
	     //Enter the ParentEntity Name in drop-down
	     selectByXpath_Visibletext("//*[@id='parent-entity']", GreatGrantChildEntity);
	     Reporter.log("Select Sub-Industry Type from drop-down | ");
	     Thread.sleep(2000);	
	     //Thread.sleep(3000);
	     
	    /* //Select Yes for this entity be a parent and cascade data to other entities
	     assertTextXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     clickByXpath("//*[@id='locations-form']/div[3]/div[2]/div[2]/div/div[1]/label");
	     Reporter.log("Select Yes for this entity be a parent and cascade data to other entities | ");
	     Thread.sleep(2000);
	     //Thread.sleep(3000);
*/	     
	     // Click on Save button
	     assertTextXpath("//*[@id='submit-button']");
	     clickByXpath("//*[@id='submit-button']");
	     Reporter.log("Click on Save button | ");
	     Thread.sleep(8000);
	     Thread.sleep(8000);
	     
	  // Click on Entity Mangement modules
	     assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[4]/a/span[2]");
	     clickByXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[4]/a/span[2]");
	     Reporter.log("Click on Entity Mangement modules | ");
	     Thread.sleep(8000);
	     
	    
	  } 
}
