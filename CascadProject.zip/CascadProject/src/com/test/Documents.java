package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Documents extends WrapperClass{
	
	  public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "ParentDemo";
	  String ChildEntity = "ChildDemo";
	  String GrantChildEntity = "GrantChildDemo";
	  String GreatGrantChildEntity = "GreatGrantChildDemo";
	
	   
	  @Test(priority=41, enabled = true)
	  public void Documents_GloablRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(3000);
		  
		//Select Documents from Left Navigate Bar
		  assertTextXpath("//*[@id='sidebar-left']/ul/li[7]/a/span[2]");
		  clickByXpath("//*[@id='sidebar-left']/ul/li[7]/a/span[2]");
		  Reporter.log("Select Documents from Left Navigate Bar ");
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  // Select Parent Entity from drop down
	 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   Thread.sleep(3000);
		   
		  //Enter Created Entity Name in Search box
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		   //Reporter.log("Enter Created Entity Name in Search box | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   
		   //Select the Searched Entity
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		  
		  // Click on Notes button 
		    assertTextXpath("//*[@id='content']/tr[1]/td[6]/span/a");
		    clickByXpath("//*[@id='content']/tr[1]/td[6]/span/a");
		    //Reporter.log("Click on Notes button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		     // Get the Child Note TextValue
			  ParentDocumentNotevalue("//*[@id='note-details-table_info']");
			 // Reporter.log(" Get the Child Note TextValue | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			// Click on Close Button in note pop-up window
			  assertTextXpath("//div[4]/div/div/div[3]/button");
			  clickByXpath("//div[4]/div/div/div[3]/button");
			  //Reporter.log("Click on Close Button in note pop-up window | ");
			  Thread.sleep(5000);
			  Thread.sleep(3000);
			  
			// Expand the Documents
			  assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
			  clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
			  Thread.sleep(5000);
			
		    // Click on Notes button 
			  assertTextXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
			  clickByXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
			  //Reporter.log("Click on Notes button | ");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  
			  // Get the Child Note TextValue
			  ParentNotevalue("//*[@id='note-details-table_info']");
			  // Reporter.log(" Get the Child Note TextValue | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			// Click on Close Button in note pop-up window
			  assertTextXpath("//div[4]/div/div/div[3]/button");
			  clickByXpath("//div[4]/div/div/div[3]/button");
			  //Reporter.log("Click on Close Button in note pop-up window | ");
			  Thread.sleep(5000);
			  Thread.sleep(3000);	    
			  
			// Expand the Documents
			  assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
			  clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
			  Thread.sleep(5000);
			  
			  Thread.sleep(3000);			
				  
			 // Select Parent Entity from drop down
			  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			  clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			  Thread.sleep(3000);
			  
			//Enter Created Entity Name in Search box
			  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
			  sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
			  //Reporter.log("Enter Created Entity Name in Search box | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
				   
		   //Select the Searched Entity
	    	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
	    	Thread.sleep(5000);
	    	Thread.sleep(5000);
	    	Thread.sleep(5000);
				  
	    	// Click on Notes button 
	    	assertTextXpath("//*[@id='content']/tr[1]/td[6]/span/a");
	    	clickByXpath("//*[@id='content']/tr[1]/td[6]/span/a");
	    	//Reporter.log("Click on Notes button | ");
	    	Thread.sleep(5000);
	    	//Thread.sleep(3000);
	    	
	    	// Get the Child Note TextValue
	    	ChildDocumentNotevalue("//*[@id='note-details-table_info']");
	    	// Reporter.log(" Get the Child Note TextValue | ");
	    	Thread.sleep(3000);
	    	//Thread.sleep(3000);
	    	
	    	// Click on Close Button in note pop-up window
	    	assertTextXpath("//div[4]/div/div/div[3]/button");
	    	clickByXpath("//div[4]/div/div/div[3]/button");
	    	//Reporter.log("Click on Close Button in note pop-up window | ");
	    	Thread.sleep(5000);
	    	Thread.sleep(3000);
	    	
	    	// Expand the Documents
	    	assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	Thread.sleep(5000);
	    	
	    // Click on Notes button 
	    	assertTextXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
	    	clickByXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
	    	//Reporter.log("Click on Notes button | ");
	    	Thread.sleep(5000);
	    	//Thread.sleep(3000);
	    	
	    	// Get the Child Note TextValue
	    	ChildNotevalue("//*[@id='note-details-table_info']");
	    	// Reporter.log(" Get the Child Note TextValue | ");
	    	Thread.sleep(3000);
	    	//Thread.sleep(3000);
	    	
	    	// Click on Close Button in note pop-up window
	    	assertTextXpath("//div[4]/div/div/div[3]/button");
	    	clickByXpath("//div[4]/div/div/div[3]/button");
	    	//Reporter.log("Click on Close Button in note pop-up window | ");
	    	Thread.sleep(5000);
	    	Thread.sleep(3000);	    
	    	
	    	// Expand the Documents
	    	assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	Thread.sleep(5000);
	       	
	  }	
	  	
	 
	  @Test(priority=42, enabled = true)
	  public void DocumentNotes_GlobalRelated() throws IOException, InterruptedException {
	   
		  //Thread.sleep(3000);		  
	
		  // Get the Compare the Note TextValue
		  CompareDocumentNotevalue("ParentDocumentNote","ChildDocumentNote");
		  Thread.sleep(3000);
			  	  
	  }
	  
	  @Test(priority=43, enabled = true)
	  public void DocumentSubRowsNotes_GlobalRelated() throws IOException, InterruptedException {
	   
		//  Thread.sleep(3000);
		// Get the Compare the Documents TextValue
		    CompareNotevalue("ParentNote","ChildNote");
		    Thread.sleep(3000);		 
	  }  
	  
	  @Test(priority=37, enabled = true)
	  public void Documents_GloablRelated_NewCustomControl() throws IOException, InterruptedException {
	   
		  Thread.sleep(3000);
		  
		//Select Documents from Left Navigate Bar
		  assertTextXpath("//*[@id='sidebar-left']/ul/li[7]/a/span[2]");
		  clickByXpath("//*[@id='sidebar-left']/ul/li[7]/a/span[2]");
		  Reporter.log("Select Documents from Left Navigate Bar ");
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  // Select Parent Entity from drop down
	 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   Thread.sleep(3000);
		   
		  //Enter Created Entity Name in Search box
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		   //Reporter.log("Enter Created Entity Name in Search box | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   
		   //Select the Searched Entity
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		 
				
				// Click on Filter Button 
		  		try {
		  			assertTextXpath("//cw-filter/div/span/i");
		  			clickByXpath("//cw-filter/div/span/i");
		  			Reporter.log("Click on Filter Button | ");
		  		}catch(Exception e)
		  		{
		  			e.printStackTrace();
		  			Reporter.log("Click on Filter Button doesn't clicked | ");
		  		}
		  		Thread.sleep(5000);
		  		//Thread.sleep(3000);
		  		//Thread.sleep(3000);
		   
		  		 //Enter Custom Control textbox
		  		assertTextXpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div/ul/li/input");
		  		sendvaluebyxpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div/ul/li/input", "TestCustomControl");
		  		Thread.sleep(2000);
		  		//Reporter.log("Enter Created Entity Name in Search box | ");
		  		enter();
		  		Thread.sleep(3000);
		  	

		  		//Click on Submit button in Filter Pop-up
		  		try {
		  			assertTextXpath("html/body/div[4]/div/div/div[3]/button[2]");
		  			clickByXpath("html/body/div[4]/div/div/div[3]/button[2]");
		  			Reporter.log("Click on Submit button in Filter Pop-up | ");
		  			Thread.sleep(3000);
		  		}catch(Exception e)
		  		{
		  			e.printStackTrace();
		  			Reporter.log("Click on Submit button in Filter Pop-up  doesn't select | ");
		  		}
		  		Thread.sleep(5000); 
		  		//Thread.sleep(3000);   
		  		//Thread.sleep(3000);   
		       
  
		  // Click on Notes button 
		    assertTextXpath("//*[@id='content']/tr[1]/td[6]/span/a");
		    clickByXpath("//*[@id='content']/tr[1]/td[6]/span/a");
		    //Reporter.log("Click on Notes button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		     // Get the Child Note TextValue
			  ParentDocumentNotevalue("//*[@id='note-details-table_info']");
			 // Reporter.log(" Get the Child Note TextValue | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			// Click on Close Button in note pop-up window
			  assertTextXpath("//div[4]/div/div/div[3]/button");
			  clickByXpath("//div[4]/div/div/div[3]/button");
			  //Reporter.log("Click on Close Button in note pop-up window | ");
			  Thread.sleep(5000);
			  Thread.sleep(3000);
			  
			// Expand the Documents
			  assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
			  clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
			  Thread.sleep(5000);
			
		    // Click on Notes button 
			  assertTextXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
			  clickByXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
			  //Reporter.log("Click on Notes button | ");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  
			  // Get the Child Note TextValue
			  ParentNotevalue("//*[@id='note-details-table_info']");
			  // Reporter.log(" Get the Child Note TextValue | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			// Click on Close Button in note pop-up window
			  assertTextXpath("//div[4]/div/div/div[3]/button");
			  clickByXpath("//div[4]/div/div/div[3]/button");
			  //Reporter.log("Click on Close Button in note pop-up window | ");
			  Thread.sleep(5000);
			  Thread.sleep(3000);	    
			  
			// Expand the Documents
			  assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
			  clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
			  Thread.sleep(5000);
			  
			  Thread.sleep(3000);			
				  
			 // Select Parent Entity from drop down
			  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			  clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			  Thread.sleep(3000);
			  
			//Enter Created Entity Name in Search box
			  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
			  sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
			  //Reporter.log("Enter Created Entity Name in Search box | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
				   
		   //Select the Searched Entity
	    	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
	    	Thread.sleep(5000);
	    	Thread.sleep(5000);
	    	Thread.sleep(5000);
	    	
	    	// Click on Filter Button 
	  		try {
	  			assertTextXpath("//cw-filter/div/span/i");
	  			clickByXpath("//cw-filter/div/span/i");
	  			Reporter.log("Click on Filter Button | ");
	  		}catch(Exception e)
	  		{
	  			e.printStackTrace();
	  			Reporter.log("Click on Filter Button doesn't clicked | ");
	  		}
	  		Thread.sleep(5000);
	  		//Thread.sleep(3000);
	  		//Thread.sleep(3000);
	   
	  		 //Enter Custom Control textbox
	  		assertTextXpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div/ul/li/input");
	  		sendvaluebyxpath("html/body/div[4]/div/div/div[2]/div/div[2]/div[2]/div[1]/div/div/ul/li/input", "TestCustomControl");
	  		Thread.sleep(2000);
	  		//Reporter.log("Enter Created Entity Name in Search box | ");
	  		enter();
	  		Thread.sleep(3000);
	  	

	  		//Click on Submit button in Filter Pop-up
	  		try {
	  			assertTextXpath("html/body/div[4]/div/div/div[3]/button[2]");
	  			clickByXpath("html/body/div[4]/div/div/div[3]/button[2]");
	  			Reporter.log("Click on Submit button in Filter Pop-up | ");
	  			Thread.sleep(3000);
	  		}catch(Exception e)
	  		{
	  			e.printStackTrace();
	  			Reporter.log("Click on Submit button in Filter Pop-up  doesn't select | ");
	  		}
	  		Thread.sleep(5000); 
	  		//Thread.sleep(3000);   
	  		//Thread.sleep(3000);  
				  
	    	// Click on Notes button 
	    	assertTextXpath("//*[@id='content']/tr[1]/td[6]/span/a");
	    	clickByXpath("//*[@id='content']/tr[1]/td[6]/span/a");
	    	//Reporter.log("Click on Notes button | ");
	    	Thread.sleep(5000);
	    	//Thread.sleep(3000);
	    	
	    	// Get the Child Note TextValue
	    	ChildDocumentNotevalue("//*[@id='note-details-table_info']");
	    	// Reporter.log(" Get the Child Note TextValue | ");
	    	Thread.sleep(3000);
	    	//Thread.sleep(3000);
	    	
	    	// Click on Close Button in note pop-up window
	    	assertTextXpath("//div[4]/div/div/div[3]/button");
	    	clickByXpath("//div[4]/div/div/div[3]/button");
	    	//Reporter.log("Click on Close Button in note pop-up window | ");
	    	Thread.sleep(5000);
	    	Thread.sleep(3000);
	    	
	    	// Expand the Documents
	    	assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	Thread.sleep(5000);
	    	
	    // Click on Notes button 
	    	assertTextXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
	    	clickByXpath("//*[@id='content']/tr[2]/td/table/tbody/tr[1]/td[7]/div/span/a");
	    	//Reporter.log("Click on Notes button | ");
	    	Thread.sleep(5000);
	    	//Thread.sleep(3000);
	    	
	    	// Get the Child Note TextValue
	    	ChildNotevalue("//*[@id='note-details-table_info']");
	    	// Reporter.log(" Get the Child Note TextValue | ");
	    	Thread.sleep(3000);
	    	//Thread.sleep(3000);
	    	
	    	// Click on Close Button in note pop-up window
	    	assertTextXpath("//div[4]/div/div/div[3]/button");
	    	clickByXpath("//div[4]/div/div/div[3]/button");
	    	//Reporter.log("Click on Close Button in note pop-up window | ");
	    	Thread.sleep(5000);
	    	Thread.sleep(3000);	    
	    	
	    	// Expand the Documents
	    	assertTextXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	clickByXpath("//*[@id='content']/tr[1]/td[1]/span");
	    	Thread.sleep(5000);
	       	
	  }	
	  	
	 
	  @Test(priority=38, enabled = true)
	  public void DocumentNotes_GlobalRelated_NewCustomControl() throws IOException, InterruptedException {
	   
		  //Thread.sleep(3000);		  
	
		  // Get the Compare the Note TextValue
		  CompareDocumentNotevalue("ParentDocumentNote","ChildDocumentNote");
		  Thread.sleep(3000);
			  	  
	  }
	  
	  @Test(priority=39, enabled = true)
	  public void DocumentSubRowsNotes_GlobalRelated_NewCustomControl() throws IOException, InterruptedException {
	   
		//  Thread.sleep(3000);
		// Get the Compare the Documents TextValue
		    CompareNotevalue("ParentNote","ChildNote");
		    Thread.sleep(3000);		 
	  }  
}
