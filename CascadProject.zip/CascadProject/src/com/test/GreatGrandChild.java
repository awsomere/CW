package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class GreatGrandChild extends WrapperClass {


	
	  public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "SampleParent";
	  String ChildEntity = "SampleChild";
	  String GrantChildEntity = "SampleGrantChild";
	  String GreatGrantChildEntity = "SampleGreatGrantChild";
	  
	  
	  @Test(priority=4, enabled = true)
	   public void NavigatePage_GrandChildCascadingProfilesList() throws IOException, InterruptedException {
		  
		        Thread.sleep(5000);
		        Thread.sleep(5000);
		        Thread.sleep(5000);
			
		        //Click on Full screen
		 	    assertTextXpath("//*[@id='fullscreen']/i");
				clickByXpath("//*[@id='fullscreen']/i");
				Thread.sleep(5000);
				//Thread.sleep(3000);
				//Thread.sleep(3000);
				//Thread.sleep(3000);
				
				// Testcase 1
				//Click on Manage Account Module
				assertTextXpath("//*[@id='sidebar-left']/ul/li[8]/a/span[2]");
				clickByXpath("//*[@id='sidebar-left']/ul/li[8]/a/span[2]");
				Reporter.log("Click on Manage Account Module | ");
				Thread.sleep(5000);
				//Thread.sleep(3000);
				
				//Click on Cascading Sub-Module
				assertTextXpath("//*[@id='sidebar-left']/ul/li[8]/ul/li[5]/a");
				clickByXpath("//*[@id='sidebar-left']/ul/li[8]/ul/li[5]/a");
				Reporter.log("Click on Cascading Sub-Module | ");
				Thread.sleep(5000);
				Thread.sleep(3000);
	}
	   
	   
	   @Test(priority=5, enabled = true)
	   public void PageHearder_GrandChildCascadingProfilesList() throws IOException, InterruptedException {
		   
		   Thread.sleep(3000);
		   
		// Testcase 2
		   // Click on Page header Icon
		   assertTextXpath("//h2/i");
		   Reporter.log("Click on Page header Icon | ");
		   Thread.sleep(2000);
		   mouseHoverByXpath("//h2/i");
		   Thread.sleep(3000);
		   
		   // Click on Page header Title
		   assertEquals("//h2", "Cascading Profiles List");
		   Reporter.log("Click on Page header Title | ");
		   Thread.sleep(2000);
		   mouseHoverByXpath("//h2");
		   Thread.sleep(3000);
	   }
	   
	   @Test(priority=6, enabled = true)
	   public void PanelBar_GrandChildCascadingProfilesList() throws IOException, InterruptedException {
			   
		   Thread.sleep(3000);
		   
		   //// Testcase 3
		   // Click on Page breadcrumb
		   assertEquals("//ol", "Manage Account Cascading Cascading Profiles List");
		   Reporter.log("Click on Page breadcrumb | ");
		   Thread.sleep(2000);
		   mouseHoverByXpath("//ol");
		   Thread.sleep(2000); 
		   
	   }
	   
	   @Test(priority=7, enabled = true)
	   public void PageLevelHelp_GrandChildCascadingProfilesList() throws IOException, InterruptedException {
		   
		   Thread.sleep(3000);
		   
		// Testcase 4
		   // Click on Page info
		   assertTextXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[2]/cw-page-help/button");
		   clickByXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[2]/cw-page-help/button");
		   Reporter.log("Click on Page info | ");
		   Thread.sleep(3000);
		   clickByXpath("html/body/div[4]/div/div/div[3]/button");
		   Thread.sleep(3000);
		   
	   }
		
	   @Test(priority=8, enabled = true)
	   public void RiskManagementMap_GrandChildCascadingProfilesList() throws IOException, InterruptedException {
		   
		   Thread.sleep(3000); 
		   
		// Testcase 5
		   // Click on Risk Management Map
		   assertTextXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[3]/cw-appmap/button");
		   clickByXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[3]/cw-appmap/button");
		   Reporter.log("Click on Risk Management Map | ");
		   Thread.sleep(3000);
		   clickByXpath("html/body/div[4]/div/div/div[3]/button");
		   Thread.sleep(5000);
	   }
	   
	   @Test(priority=9, enabled = true)
	   public void PageHearder_GrandChildCascadingProfilesForm() throws IOException, InterruptedException {
		 
		   Thread.sleep(5000);
		   
		 //Click on New button
		   assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		   clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		   Reporter.log("Click on New button | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   Thread.sleep(2000);
		   
		// Testcase 6
		   // Click on Page header Icon
		   assertTextXpath("//h2/i");
		   Reporter.log("Click on Page header Icon | ");
		   Thread.sleep(1000);
		   mouseHoverByXpath("//h2/i");
		   Thread.sleep(2000);
		   
		   /*// Click on Page header Title
		   assertEquals("//h2", "Create cascading profiles for your account");
		   Reporter.log("Click on Page header Title | ");
		   Thread.sleep(2000);
		   mouseHoverByXpath("//h2");
		   Thread.sleep(3000);*/
		   
	   }
		   
		   @Test(priority=10, enabled = true)
		   public void PanelBar_GrandChildCascadingProfilesForm() throws IOException, InterruptedException {
			   
			// Testcase 7
		   // Click on Page breadcrumb
		   assertEquals("//ol", "Manage Account Cascading Profiles Cascading Profiles Form");
		   Reporter.log("Click on Page breadcrumb | ");
		   Thread.sleep(1000);
		   mouseHoverByXpath("//ol");
		   Thread.sleep(2000); 
		   
		   }
		   
		   @Test(priority=11, enabled = true)
		   public void PageLevelHelp_GrandChildCascadingProfilesForm() throws IOException, InterruptedException {
		   
			// Testcase 8   
		   // Click on Page info
		   assertTextXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[2]/cw-page-help/button");
		   clickByXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[2]/cw-page-help/button");
		   Reporter.log("Click on Page info | ");
		   Thread.sleep(3000);
		   clickByXpath("html/body/div[4]/div/div/div[3]/button");
		   Thread.sleep(3000);
		   
		   }
		   
		   @Test(priority=12, enabled = true)
		   public void RiskManagementMap_GrandChildCascadingProfilesForm() throws IOException, InterruptedException {
			 
			// Testcase 9
		   // Click on Risk Management Map
		   assertTextXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[3]/cw-appmap/button");
		   clickByXpath("//*[@id='cw-panelbar']/div/div[2]/ul/li[3]/cw-appmap/button");
		   Reporter.log("Click on Risk Management Map | ");
		   Thread.sleep(3000);
		   clickByXpath("html/body/div[4]/div/div/div[3]/button");
		   Thread.sleep(3000);
		   
		// Testcase 10
		   // Cick on Cascading Profiles link
		   clickByXpath("//*[@id='page-content']/div[1]/div/ol/li[2]/a");
		   Thread.sleep(4000);
		   
		// Testcase 11
		   // Cick on Cascading link
		   clickByXpath("//*[@id='page-content']/div[1]/div/ol/li[2]/a");
		   Thread.sleep(4000);
		  
		// Testcase 12
		// Cick on Manage Account link
		   clickByXpath("//*[@id='page-content']/div[1]/div/ol/li[1]/a");
		   Thread.sleep(4000);
		   
		    //Click on Full screen
	 	    assertTextXpath("//*[@id='fullscreen']/i");
			clickByXpath("//*[@id='fullscreen']/i");
			Thread.sleep(5000);
			   
			//Click on Cascading Sub-Module
			assertTextXpath("//*[@id='sidebar-left']/ul/li[8]/ul/li[5]/a");
			clickByXpath(".//*[@id='sidebar-left']/ul/li[8]/ul/li[5]/a");
			Reporter.log("Click on Cascading Sub-Module | ");
			Thread.sleep(5000);
			//Thread.sleep(3000);	
		  		   
		 /*//Click on cancel Button
		   assertTextXpath("//*[@id='submitButton']/span[2]/a");
		   clickByXpath("//*[@id='submitButton']/span[2]/a");
		   Reporter.log("Click on Save button |");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
*/		   
	   }
	/*	   
	 @Test(priority=13, enabled = false)
	 public void ColumnHeaders() throws IOException, InterruptedException {
	
		 Thread.sleep(3000);
	 }
	 
	   @Test(priority=14, enabled = false)
	   public void ChkCancelBtn() throws IOException, InterruptedException {
		 
		   Thread.sleep(5000);  
		  
	   }
		  */
		  
	 @Test(priority=15, enabled = true)
    public void ChkAllFields_MediaCascading() throws IOException, InterruptedException {
			 
	     Thread.sleep(2000);
		
	  // Testcase 13
	     //Click on New button
		  assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		  clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		  Reporter.log("Click on New button | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  Thread.sleep(3000);
	     
	     //Click on Profile Type drop-down
		  assertTextXpath("//*[@id='type_id']");
		  clickByXpath("//*[@id='type_id']");
		  Reporter.log("Click on Profile Type drop-down | ");
		  Thread.sleep(1000);
		  clickByXpath("//option[3]");		    
		  //Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  //Click on Save Button
		  assertTextXpath("//div[3]/div/div/span");
		  clickByXpath("//div[3]/div/div/span");
		  Reporter.log("Click on Save button |");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  Thread.sleep(3000);
		  
		// Testcase 14
		  //Enter the Cascad Profile name
		  assertTextXpath("//div/input");
		  sendvaluebyxpath("//div/input", "ChkAllFields MediaCascading");
		  Reporter.log("Enter the Cascad Profile name | ");
		  Thread.sleep(3000);
		  	  
		  //Enter Description 
		  assertTextXpath("//textarea");
		  sendvaluebyxpath("//textarea", "Description test");
		  Reporter.log("Enter Description | ");
		  Thread.sleep(3000);
		  
		  //Click on Save Button
		  assertTextXpath("//div[3]/div/div/span");
		  clickByXpath("//div[3]/div/div/span");
		  Reporter.log("Click on Save button |");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  Thread.sleep(3000);
		  
		// Testcase 15
		//Click on Add Checkbox 
		  assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[1]/div");
		  clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[1]/div");
		  Reporter.log("Click on Add Checkbox  | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		//Click on Save Button
		  assertTextXpath("//div[3]/div/div/span");
		  clickByXpath("//div[3]/div/div/span");
		  Reporter.log("Click on Save button |");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  Thread.sleep(3000);
		  	
		// Testcase 16
		  //Click on Select Media/Asset Groups for this profile 
		  assertTextXpath("//div[2]/div/div/button");
		  clickByXpath("//div[2]/div/div/button");
		  Reporter.log("Click on Select Media/Asset Groups for this profile  | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		//Click on Save Button
		  assertTextXpath("//div[3]/div/div/span");
		  clickByXpath("//div[3]/div/div/span");
		  Reporter.log("Click on Save button |");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  ArrowUp();
		  Thread.sleep(3000);
		  
		// Testcase 17
		  //Click on Select Child locations this profile will cascade to 
		  assertTextXpath("//cw-multi-controls/div/div[2]/div/div/button");
		  clickByXpath("//cw-multi-controls/div/div[2]/div/div/button");
		  Reporter.log("Click on Select Child locations this profile will cascade to | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		  //Click on Save Button
		  assertTextXpath("//div[3]/div/div/span");
		  clickByXpath("//div[3]/div/div/span");
		  Reporter.log("Click on Save button |");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
	   }	
	   	
	   @Test(priority=16, enabled = true)
	   public void Edit_ParentOperation_Cascading() throws IOException, InterruptedException {
		   
		   Thread.sleep(5000);
		   		   					   	   
		   //Click on New button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		   Reporter.log("Click on New button | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   Thread.sleep(3000);
		   
		    //Click on Profile Type drop-down
		    assertTextXpath("//*[@id='type_id']");
		    clickByXpath("//*[@id='type_id']");
		    Reporter.log("Click on Profile Type drop-down | ");
		    Thread.sleep(1000);
		    clickByXpath("//option[3]");		    
		    //Thread.sleep(3000);
		    //Thread.sleep(3000);
		    	    
		    //Enter the Cascad Profile name
		    assertTextXpath("//div/input");
		    sendvaluebyxpath("//div/input", "Edit ParentOperation Cascading");
		    Reporter.log("Enter the Cascad Profile name | ");
		    Thread.sleep(3000);
		    
		    //Enter Description 
		    assertTextXpath("//textarea");
		    sendvaluebyxpath("//textarea", "Description test");
		    Reporter.log("Enter Description | ");
		    Thread.sleep(3000);
		    	
		 // Testcase 18
		    //Click on Edit Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		    Reporter.log("Click on Edit Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    	   		    
		    //Click on Select Media/Asset Groups for this profile 
		    assertTextXpath("//div[2]/div/div/button");
		    clickByXpath("//div[2]/div/div/button");
		    Reporter.log("Click on Select Media/Asset Groups for this profile  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Select Child locations this profile will cascade to 
		    assertTextXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    clickByXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    Reporter.log("Click on Select Child locations this profile will cascade to | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		       
		    //Click on Save Button
		    assertTextXpath("//div[3]/div/div/span");
		    clickByXpath("//div[3]/div/div/span");
		    Reporter.log("Click on Save button |");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
	   }
	   
	   @Test(priority=17, enabled = true)
	   public void Delete_ParentOperation_MediaCascading() throws IOException, InterruptedException {
		 
		   Thread.sleep(5000);
		    
		   //Click on New button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		   Reporter.log("Click on New button | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   Thread.sleep(3000);
		   
		    //Click on Profile Type drop-down
		    assertTextXpath("//*[@id='type_id']");
		    clickByXpath("//*[@id='type_id']");
		    Reporter.log("Click on Profile Type drop-down | ");
		    Thread.sleep(1000);
		    clickByXpath("//option[3]");		    
		    //Thread.sleep(3000);
		    //Thread.sleep(3000);
		    	    
		    //Enter the Cascad Profile name
		    assertTextXpath("//div/input");
		    sendvaluebyxpath("//div/input", "Delete ParentOperation MediaCascading");
		    Reporter.log("Enter the Cascad Profile name | ");
		    Thread.sleep(3000);
		    
		    //Enter Description 
		    assertTextXpath("//textarea");
		    sendvaluebyxpath("//textarea", "Description test");
		    Reporter.log("Enter Description | ");
		    Thread.sleep(3000);
		    
		 // Testcase 19
		    //Click on Delete Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		    Reporter.log("Click on Delete Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Select Media/Asset Groups for this profile 
		    assertTextXpath("//div[2]/div/div/button");
		    clickByXpath("//div[2]/div/div/button");
		    Reporter.log("Click on Select Media/Asset Groups for this profile  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Select Child locations this profile will cascade to 
		    assertTextXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    clickByXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    Reporter.log("Click on Select Child locations this profile will cascade to | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		       
		    //Click on Save Button
		    assertTextXpath("//div[3]/div/div/span");
		    clickByXpath("//div[3]/div/div/span");
		    Reporter.log("Click on Save button |");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
	   }
	   
	   @Test(priority=18, enabled = true)
	   public void Edit_ChildPermission_MediaCascading() throws IOException, InterruptedException {
		 
		   Thread.sleep(5000);
		  
		   //Click on New button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		   Reporter.log("Click on New button | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   Thread.sleep(3000);
		   
		    //Click on Profile Type drop-down
		    assertTextXpath("//*[@id='type_id']");
		    clickByXpath("//*[@id='type_id']");
		    Reporter.log("Click on Profile Type drop-down | ");
		    Thread.sleep(1000);
		    clickByXpath("//option[3]");		    
		    //Thread.sleep(3000);
		    //Thread.sleep(3000);
		    	    
		    //Enter the Cascad Profile name
		    assertTextXpath("//div/input");
		    sendvaluebyxpath("//div/input", "Edit ChildPermission MediaCascading");
		    Reporter.log("Enter the Cascad Profile name | ");
		    Thread.sleep(3000);
		    
		    //Enter Description 
		    assertTextXpath("//textarea");
		    sendvaluebyxpath("//textarea", "Description test");
		    Reporter.log("Enter Description | ");
		    Thread.sleep(3000);
		    
		 // Testcase 20
		    //Click on Edit Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
		    Reporter.log("Click on Edit Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Select Media/Asset Groups for this profile 
		    assertTextXpath("//div[2]/div/div/button");
		    clickByXpath("//div[2]/div/div/button");
		    Reporter.log("Click on Select Media/Asset Groups for this profile  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Select Child locations this profile will cascade to 
		    assertTextXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    clickByXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    Reporter.log("Click on Select Child locations this profile will cascade to | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		       
		    //Click on Save Button
		    assertTextXpath("//div[3]/div/div/span");
		    clickByXpath("//div[3]/div/div/span");
		    Reporter.log("Click on Save button |");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
	   }
	   
	   @Test(priority=19, enabled = true)
	   public void Delete_ChildPermission_MediaCascading() throws IOException, InterruptedException {
		 
		   Thread.sleep(5000);
		   
		   //Click on New button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
		   Reporter.log("Click on New button | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   Thread.sleep(3000);
		   
		    //Click on Profile Type drop-down
		    assertTextXpath("//*[@id='type_id']");
		    clickByXpath("//*[@id='type_id']");
		    Reporter.log("Click on Profile Type drop-down | ");
		    Thread.sleep(1000);
		    clickByXpath("//option[3]");		    
		    //Thread.sleep(3000);
		    //Thread.sleep(3000);
		    	    
		    //Enter the Cascad Profile name
		    assertTextXpath("//div/input");
		    sendvaluebyxpath("//div/input", "Delete ChildPermission MediaCascading");
		    Reporter.log("Enter the Cascad Profile name | ");
		    Thread.sleep(3000);
		    
		    //Enter Description 
		    assertTextXpath("//textarea");
		    sendvaluebyxpath("//textarea", "Description test");
		    Reporter.log("Enter Description | ");
		    Thread.sleep(3000);
		    
		 // Testcase 21
		    //Click on Delete Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
		    Reporter.log("Click on Delete Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Select Media/Asset Groups for this profile 
		    assertTextXpath("//div[2]/div/div/button");
		    clickByXpath("//div[2]/div/div/button");
		    Reporter.log("Click on Select Media/Asset Groups for this profile  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Select Child locations this profile will cascade to 
		    assertTextXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    clickByXpath("//cw-multi-controls/div/div[2]/div/div/button");
		    Reporter.log("Click on Select Child locations this profile will cascade to | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		       
		    //Click on Save Button
		    assertTextXpath("//div[3]/div/div/span");
		    clickByXpath("//div[3]/div/div/span");
		    Reporter.log("Click on Save button |");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
	   }
	   
	 @Test(priority=20, enabled = true)
	     public void ChkAllFields_AdminCascading() throws IOException, InterruptedException {
				 
		     Thread.sleep(5000);
			
		  // Testcase 22
		     //Click on New button
			  assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			  clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			  Reporter.log("Click on New button | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  Thread.sleep(3000);
		     			  
			  //Click on Save Button
			  assertTextXpath("//div[3]/div/div/span");
			  clickByXpath("//div[3]/div/div/span");
			  Reporter.log("Click on Save button |");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			   
			// Testcase 23
			  //Click on Profile Type drop-down
			    assertTextXpath("//*[@id='type_id']");
			    clickByXpath("//*[@id='type_id']");
			    Reporter.log("Click on Profile Type drop-down | ");
			    Thread.sleep(1000);
			    clickByXpath("//option[2]");		    
			    //Thread.sleep(3000);
			    //Thread.sleep(3000);
			    	    
			    //Enter the Cascad Profile name
			    assertTextXpath("//div/input");
			    sendvaluebyxpath("//div/input", "ChkAllFields AdminCascading");
			    Reporter.log("Enter the Cascad Profile name | ");
			    Thread.sleep(3000);
			  
			  //Click on Save Button
			  assertTextXpath("//div[3]/div/div/span");
			  clickByXpath("//div[3]/div/div/span");
			  Reporter.log("Click on Save button |");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  
			// Testcase 24
			   //Enter Description 
			    assertTextXpath("//textarea");
			    sendvaluebyxpath("//textarea", "Description test");
			    Reporter.log("Enter Description | ");
			    Thread.sleep(3000);
			  
			  //Click on Add Checkbox 
			    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[1]/div");
			    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[1]/div");
			    Reporter.log("Click on Add Checkbox  | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			  
			//Click on Save Button
			  assertTextXpath("//div[3]/div/div/span");
			  clickByXpath("//div[3]/div/div/span");
			  Reporter.log("Click on Save button |");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  	
			// Testcase 25
			//Click on Select Child locations this profile will cascade to 
			  assertTextXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			  clickByXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			  Reporter.log("Click on Select Child locations this profile will cascade to | ");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  
			  //Click on Save Button
			  assertTextXpath("//div[3]/div/div/span");
			  clickByXpath("//div[3]/div/div/span");
			  Reporter.log("Click on Save button |");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
		   }	
		   	
		   @Test(priority=21, enabled = true)
		   public void Edit_ParentOperation_AdminCascading() throws IOException, InterruptedException {
			   
			   Thread.sleep(5000);
			   	   	   
			   //Click on New button
			    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			   Reporter.log("Click on New button | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);
			   Thread.sleep(3000);
			   
			   //Click on Profile Type drop-down
			    assertTextXpath("//*[@id='type_id']");
			    clickByXpath("//*[@id='type_id']");
			    Reporter.log("Click on Profile Type drop-down | ");
			    Thread.sleep(1000);
			    clickByXpath("//option[2]");		    
			    //Thread.sleep(3000);
			    //Thread.sleep(3000);
			    	    
			    //Enter the Cascad Profile name
			    assertTextXpath("//div/input");
			    sendvaluebyxpath("//div/input", "Edit ParentOperation AdminCascading");
			    Reporter.log("Enter the Cascad Profile name | ");
			    Thread.sleep(3000);
			    
			    //Enter Description 
			    assertTextXpath("//textarea");
			    sendvaluebyxpath("//textarea", "Description test");
			    Reporter.log("Enter Description | ");
			    Thread.sleep(3000);
			    	
			 // Testcase 26
			    //Click on Edit Checkbox 
			    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
			    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
			    Reporter.log("Click on Edit Checkbox  | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			    	   		    
			  //Click on Select Child locations this profile will cascade to 
			    assertTextXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    clickByXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    Reporter.log("Click on Select Child locations this profile will cascade to | ");
			    Thread.sleep(5000);
			    //Thread.sleep(3000);
			       
			    //Click on Save Button
			    assertTextXpath("//div[3]/div/div/span");
			    clickByXpath("//div[3]/div/div/span");
			    Reporter.log("Click on Save button |");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			    
		   }
		   
		   @Test(priority=22, enabled = true)
		   public void Delete_ParentOperation_AdminCascading() throws IOException, InterruptedException {
			 
			   Thread.sleep(5000);
			    
			   //Click on New button
			    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			   Reporter.log("Click on New button | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);
			   Thread.sleep(3000);
			   
			   //Click on Profile Type drop-down
			    assertTextXpath("//*[@id='type_id']");
			    clickByXpath("//*[@id='type_id']");
			    Reporter.log("Click on Profile Type drop-down | ");
			    Thread.sleep(1000);
			    clickByXpath("//option[2]");		    
			    //Thread.sleep(3000);
			    //Thread.sleep(3000);
			    	    
			    //Enter the Cascad Profile name
			    assertTextXpath("//div/input");
			    sendvaluebyxpath("//div/input", "Delete ParentOperation AdminCascading");
			    Reporter.log("Enter the Cascad Profile name | ");
			    Thread.sleep(3000);
			    
			    //Enter Description 
			    assertTextXpath("//textarea");
			    sendvaluebyxpath("//textarea", "Description test");
			    Reporter.log("Enter Description | ");
			    Thread.sleep(3000);
			    
			 // Testcase 27
			    //Click on Delete Checkbox 
			    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
			    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
			    Reporter.log("Click on Delete Checkbox  | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			    
			  //Click on Select Child locations this profile will cascade to 
			    assertTextXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    clickByXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    Reporter.log("Click on Select Child locations this profile will cascade to | ");
			    Thread.sleep(5000);
			    //Thread.sleep(3000);
			       
			    //Click on Save Button
			    assertTextXpath("//div[3]/div/div/span");
			    clickByXpath("//div[3]/div/div/span");
			    Reporter.log("Click on Save button |");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
		   }
		   
		   @Test(priority=23, enabled = true)
		   public void Edit_ChildPermision_AdminCascading() throws IOException, InterruptedException {
			 
			   Thread.sleep(5000);
			  
			   //Click on New button
			    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			   Reporter.log("Click on New button | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);
			   Thread.sleep(3000);
			   
			   //Click on Profile Type drop-down
			    assertTextXpath("//*[@id='type_id']");
			    clickByXpath("//*[@id='type_id']");
			    Reporter.log("Click on Profile Type drop-down | ");
			    Thread.sleep(1000);
			    clickByXpath("//option[2]");		    
			    //Thread.sleep(3000);
			    //Thread.sleep(3000);
			    	    
			    //Enter the Cascad Profile name
			    assertTextXpath("//div/input");
			    sendvaluebyxpath("//div/input", "Edit ChildPermision AdminCascading");
			    Reporter.log("Enter the Cascad Profile name | ");
			    Thread.sleep(3000);
			    
			    //Enter Description 
			    assertTextXpath("//textarea");
			    sendvaluebyxpath("//textarea", "Description test");
			    Reporter.log("Enter Description | ");
			    Thread.sleep(3000);
			    
			 // Testcase 28			    
			    //Click on Edit Checkbox 
			    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
			    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
			    Reporter.log("Click on Edit Checkbox  | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			    
			    //Click on Select Child locations this profile will cascade to 
			    assertTextXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    clickByXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    Reporter.log("Click on Select Child locations this profile will cascade to | ");
			    Thread.sleep(5000);
			    //Thread.sleep(3000);
			       
			    //Click on Save Button
			    assertTextXpath("//div[3]/div/div/span");
			    clickByXpath("//div[3]/div/div/span");
			    Reporter.log("Click on Save button |");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
		   }
		   
		   @Test(priority=24, enabled = true)
		   public void Delete_ChildPermission_AdminCascading() throws IOException, InterruptedException {
			 
			   Thread.sleep(5000);
			   
			   //Click on New button
			    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[1]");
			   Reporter.log("Click on New button | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);
			   Thread.sleep(3000);
			   
			    //Click on Profile Type drop-down
			    assertTextXpath("//*[@id='type_id']");
			    clickByXpath("//*[@id='type_id']");
			    Reporter.log("Click on Profile Type drop-down | ");
			    Thread.sleep(1000);
			    clickByXpath("//option[2]");		    
			    //Thread.sleep(3000);
			    //Thread.sleep(3000);
			    	    
			    //Enter the Cascad Profile name
			    assertTextXpath("//div/input");
			    sendvaluebyxpath("//div/input", "Delete ChildPermission AdminCascading");
			    Reporter.log("Enter the Cascad Profile name | ");
			    Thread.sleep(3000);
			    
			    //Enter Description 
			    assertTextXpath("//textarea");
			    sendvaluebyxpath("//textarea", "Description test");
			    Reporter.log("Enter Description | ");
			    Thread.sleep(3000);
			    
			 // Testcase 29
			    //Click on Delete Checkbox 
			    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
			    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
			    Reporter.log("Click on Delete Checkbox  | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			    
			  //Click on Select Child locations this profile will cascade to 
			    assertTextXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    clickByXpath("html/body/section/section/div[4]/div/form/div[2]/div[2]/div/div[2]/div[2]/cw-multi-controls/div/div[2]/div/div/button[1]");
			    Reporter.log("Click on Select Child locations this profile will cascade to | ");
			    Thread.sleep(5000);
			    //Thread.sleep(3000);
			       
			    //Click on Save Button
			    assertTextXpath("//div[3]/div/div/span");
			    clickByXpath("//div[3]/div/div/span");
			    Reporter.log("Click on Save button |");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
		   }
		   
		 @Test(priority=25, enabled = true)
		 public void ViewBtn_CascadingProfilesList() throws IOException, InterruptedException { 
		 
			 Thread.sleep(3000);
			 
			// Testcase 30
			 //Click on the listed Cascading 
		    assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
		    clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
		    Reporter.log("Click on View button | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		       
		    //Click on View Button 
		    assertTextXpath("//a[2]/span");
		    clickByXpath("//a[2]/span");
		    Reporter.log("Click on View button | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on cancel Button
		    assertTextXpath("//span/a");
		    clickByXpath("//span/a");
		    Reporter.log("Click on cancel button |");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		 }
		 
		 @Test(priority=26, enabled = true)
		 public void EditBtn_AdministrativeControls_CascadingProfilesList() throws IOException, InterruptedException { 
		    
			 Thread.sleep(3000);
			 
			// Testcase 31
		    //Click on the listed Cascading 
		    assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
		    clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
		    Reporter.log("Click on View button | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Edit Button 
		    assertTextXpath("//a[3]/span/i");
		    clickByXpath("//a[3]/span/i");
		    Reporter.log("Click on Edit button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		  //Enter the Cascad Profile name
		    assertTextXpath("//*[@id='name']");
		    sendvaluebyxpath("//*[@id='name']", "Edit AdministrativeControls Cascading");
		    Reporter.log("Enter the Cascad Profile name | ");
		    Thread.sleep(3000);
		    
		    //Enter Description 
		    assertTextXpath("//*[@id='description']");
		    sendvaluebyxpath("//*[@id='description']", "Edit Description test");
		    Reporter.log("Enter Description | ");
		    Thread.sleep(3000);
		    
		    //Click on Edit Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		    Reporter.log("Click on Edit Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Delete Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		    Reporter.log("Click on Delete Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Edit Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
		    Reporter.log("Click on Edit Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Delete Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
		    Reporter.log("Click on Delete Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
	    
		    //Click on Save Button 
		    assertTextXpath("//*[@id='submitButton']/span[1]");
		    clickByXpath("//*[@id='submitButton']/span[1]");
		    Reporter.log("Click on Save button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		 }
		 
		 @Test(priority=27, enabled = true)
		 public void DeleteBtn_CascadingProfilesList() throws IOException, InterruptedException { 
			 
			
			 Thread.sleep(3000);
			 
			// Testcase 32
		  //Click on the listed Cascading 
		    assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
		    clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
		    Reporter.log("Click on View button | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Delete Button 
		    assertTextXpath("//a[4]/span");
		    clickByXpath("//a[4]/span");
		    Reporter.log("Click on Edit button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		  //Click on cancel Button 
		    assertTextXpath("//div[3]/button[2]");
		    clickByXpath("//div[3]/button[2]");
		    Reporter.log("Click on cancel button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		 }
		 
		 @Test(priority=28, enabled = true)
		 public void CascadeBtn_AdministrativeControls_CascadingProfilesList() throws IOException, InterruptedException { 
		    
			 Thread.sleep(3000);
			 
			// Testcase 33
		    // Click on Cascade button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		 /* //Select Override Check-box 
		    assertTextXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    clickByXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);
		    
		    //Select Override Check-box 
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);*/
		    
		    // Click on Cascade button
		    assertTextXpath("//*[@id='submitButton']/span[1]");
		    clickByXpath("//*[@id='submitButton']/span[1]");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		    // Click on Proceed button
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Click on Proceed button | ");
		    Thread.sleep(5000);
		    Thread.sleep(3000);
	   	     	
}	
		 @Test(priority=29, enabled = true)
		 public void Search_CascadingProfilesList() throws IOException, InterruptedException { 
		    
			 Thread.sleep(3000);
			 
			// Testcase 34
			 //Search the text
			 assertTextXpath("//*[@id='cascading-profile-list_filter']/label/input");
			 sendvaluebyxpath("//*[@id='cascading-profile-list_filter']/label/input", "sample");
			 Reporter.log("Searched the Text | ");
			 Thread.sleep(5000);
			 sendvaluebyxpath("//*[@id='cascading-profile-list_filter']/label/input", " ");
			 
		 }
		 
		 @Test(priority=30, enabled = true)
		 public void EditBtn_MediaAsset_CascadingProfilesList() throws IOException, InterruptedException { 
		    
			 Thread.sleep(3000);
			 
			 //Search the text
			 assertTextXpath("//*[@id='cascading-profile-list_filter']/label/input");
			 sendvaluebyxpath("//*[@id='cascading-profile-list_filter']/label/input", "Media");
			 Reporter.log("Searched the Text | ");
			 Thread.sleep(3000);
			 
			 //Click on the listed Cascading 
			 assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 Reporter.log("Click on View button | ");
			 Thread.sleep(3000);
			 //Thread.sleep(3000);
		    
			// Testcase 35
		    //Click on Edit Button 
		    assertTextXpath("//a[3]/span/i");
		    clickByXpath("//a[3]/span/i");
		    Reporter.log("Click on Edit button | ");
		    Thread.sleep(5000);
		    Thread.sleep(3000);
		    
		  //Enter the Cascad Profile name
		    assertTextXpath("//*[@id='name']");
		    sendvaluebyxpath("//*[@id='name']", "Edit MediaAsset Cascading");
		    Reporter.log("Enter the Cascad Profile name | ");
		    Thread.sleep(3000);
		    
		    //Enter Description 
		    assertTextXpath("//*[@id='description']");
		    sendvaluebyxpath("//*[@id='description']", "Edit Description test");
		    Reporter.log("Enter Description | ");
		    Thread.sleep(3000);
		    
		    //Click on Edit Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		    Reporter.log("Click on Edit Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Delete Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		    Reporter.log("Click on Delete Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Edit Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[4]/div");
		    Reporter.log("Click on Edit Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
		    
		    //Click on Delete Checkbox 
		    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
		    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[5]/div");
		    Reporter.log("Click on Delete Checkbox  | ");
		    Thread.sleep(3000);
		    //Thread.sleep(3000);
	    
		    //Click on Save Button 
		    assertTextXpath("//*[@id='submitButton']/span[1]");
		    clickByXpath("//*[@id='submitButton']/span[1]");
		    Reporter.log("Click on Save button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		 }
	   
		 @Test(priority=31, enabled = true)
		 public void CascadeBtn_MediaAsset_CascadingProfilesList() throws IOException, InterruptedException { 
		    
			 Thread.sleep(3000);
			 			 
			//Search the text
			 assertTextXpath("//*[@id='cascading-profile-list_filter']/label/input");
			 sendvaluebyxpath("//*[@id='cascading-profile-list_filter']/label/input", "Media");
			 Reporter.log("Searched the Text | ");
			 Thread.sleep(3000);
			 
			// Testcase 36
			//Click on the listed Cascading 
			 assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 Reporter.log("Click on View button | ");
			 Thread.sleep(3000);
			 //Thread.sleep(3000);
			 
		    // Click on Cascade button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		    /*//Select Override Check-box 
		    assertTextXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    clickByXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);
		    
		    //Select Override Check-box 
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);*/
		    
		    // Click on Cascade button
		    assertTextXpath("//*[@id='submitButton']/span[1]");
		    clickByXpath("//*[@id='submitButton']/span[1]");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		    // Click on Proceed button
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Click on Proceed button | ");
		    Thread.sleep(5000);
	   	     	
}	
		 
		 @Test(priority=32, enabled = true)
		 public void Pagination__CascadingProfilesList() throws IOException, InterruptedException { 
			 
			 Thread.sleep(3000);
			 
			// Testcase 39
			// Click on Pagination button
			 assertTextXpath("//*[@id='cascading-profile-list_length']/label/select/option[1]");
			 clickByXpath("//*[@id='cascading-profile-list_length']/label/select/option[1]");
			 Reporter.log("Click on Pagination button | ");
			 Thread.sleep(5000);
			 Thread.sleep(3000);
		 }
		 
		 @Test(priority=33, enabled = false)
		 public void Sorting__CascadingProfilesList() throws IOException, InterruptedException { 
			 
			// Testcase 40
			
			 
		 }
		 }
		 