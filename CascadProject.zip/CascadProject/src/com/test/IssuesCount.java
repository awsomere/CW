package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class IssuesCount extends WrapperClass{
	
	  public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "BookParent";
	  String ChildEntity = "BookChild";
	  String GrantChildEntity = "BookGrantChild";
	  String GreatGrantChildEntity = "BookGreatGrantChild";
	
	  @Test(priority=34, enabled = true)
	  public void IRM5165() throws IOException, InterruptedException {
	   
		  Thread.sleep(3000);
		  Thread.sleep(2000);
			 
		  //Select the Asset module at sidebar-left
		   assertTextXpath("//*[@id='sidebar-left']/ul/li[3]/a/span[2]");
		   clickByXpath("//*[@id='sidebar-left']/ul/li[3]/a/span[2]");  	
		   Reporter.log("Selected the Asset module at sidebar-left | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);  
        
		   // Select the Media/Asset Groups sub-modules listed in Asset Inventory List	  
		    assertTextXpath("//*[@id='sidebar-left']/ul/li[3]/ul/li[3]/a");
	      clickByXpath("//*[@id='sidebar-left']/ul/li[3]/ul/li[3]/a");
	      Reporter.log("Select the Media/Asset Groups sub-modules listed in Asset Inventory List | ");
		    Thread.sleep(3000); 		 
	   	     
	   	      // Get the Parent MediaLabelNameValue
			   ParentMediaLabelNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[3]");
			   //Reporter.log(" Get the Parent Note TextValue | ");
			   Thread.sleep(3000);	
	
			  
			  //Click on the Created new Entity drop-down from Header 
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
		    	Thread.sleep(3000);
						   
		    	//Enter Created Entity Name in Search box
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    	sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		    	//Reporter.log("Enter Created Entity Name in Search box | ");
		    	Thread.sleep(3000);
		    	//Thread.sleep(3000);
		    	
		    	//Select the Searched Entity
				clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
				//Reporter.log("Select the Searched Entity | ");
				Thread.sleep(5000);
				Thread.sleep(5000);
				Thread.sleep(3000);			  	    		
		   	     
		   	      // Get the Parent MediaLabelNameValue
				   ChildMediaLabelNameValue("//*[@id='content']/div[2]/div[1]/div/div[2]/div[2]/div[3]");
				   //Reporter.log(" Get the Parent Note TextValue | ");
				   Thread.sleep(3000);	
				    			  
					// Get the Compare the Response Color
					CompareMediaLabelNameValue("ParentMediaLabelNameValue","ChildMediaLabelNameValue");
				    Thread.sleep(5000);
	   	     
	  }  
	   	 
	  @Test( priority=21, enabled = false)
	  public void IRM6263() throws InterruptedException, IOException {
	  
	 	  	    
	 	    // Click on Type column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[1]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[1]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Type column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[1]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[1]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on Name column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[2]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[2]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Name column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[2]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[2]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on Description column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[3]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[3]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Description column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[3]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[3]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on  Parent Add column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[4]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[4]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Parent Add column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[4]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[4]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on Parent Edit column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[5]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[5]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Parent Edit column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[5]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[5]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on Parent Delete column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[6]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[6]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Parent Delete column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[6]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[6]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on Chicld Edit column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[7]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[7]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Child Edit column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[7]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[7]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on Child Delete column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[8]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[8]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on CHil Delete column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[8]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[8]"); 
	 	    Thread.sleep(3000);
	 	    
	 	// Click on Location column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[9]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[9]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Location column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[9]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[9]"); 
	 	    Thread.sleep(3000);
	 	    
	 	    // Click on Last Updated column Header to sort for Ascending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[12]");
	 	    Thread.sleep(1000);	
	 	    sortascen("//*[@id='cascading-profile-list']/tbody/tr[*]/td[12]"); 
	 	    Thread.sleep(2000);			    
	 	    
	 	    // Click on Last Updated column Header to sort for Descending order
	 	    clickByXpath("//*[@id='cascading-profile-list']/thead/tr[2]/th[12]");
	 	    Thread.sleep(1000);	
	 	    sortdesc("//*[@id='cascading-profile-list']/tbody/tr[*]/td[12]"); 
	 	    Thread.sleep(3000);
	 	    
	 	    }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5376() throws InterruptedException, IOException {
		  
		  
		  //Control global media for document model
		  
		  // Click on Page header Title
		   assertEquals("//*[@id='document-details-table']/thead/tr/th[3]", "Cascade Statistics");
		   //Reporter.log("Click on Page header Title | ");
		   Thread.sleep(2000);
		   //Thread.sleep(1000);
		 
		  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM6669() throws InterruptedException, IOException {
		  
	  
	        // Added in Scripts 
	  
	  
	  
	  }

	  @Test( priority=21, enabled = false)
	  public void IRM6662() throws InterruptedException, IOException {
		  
	  
		  Thread.sleep(5000);
  		  
		  // Select Risk Questionnaire list sub-module under Risk Determination Module
	        try {
	        	assertTextLink("Risk Questionnaire List");
	            clickBylinktext("Risk Questionnaire List");
	            Reporter.log("Select Risk Questionnaire List | ");
	       }catch(Exception e)
		    {
		        e.printStackTrace();
		        Reporter.log("Select Risk Questionnaire List doesn't reached | ");
		    }
	        Thread.sleep(5000);
	        Thread.sleep(3000);
	        //Thread.sleep(3000);
	  
	  // Click on 'Review' button of Media/Asset
      try {
      	assertTextXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
	        clickByXpath("//*[@id='content']/tr[1]/td[7]/div/div[2]/span");
	        Reporter.log("Click on 'Review' button of Media/Asset | ");
      }catch(Exception e)
	    {
	         e.printStackTrace();
	         Reporter.log("Click on 'continue' button of Media/Asset doesn't work | ");
	    }
      Thread.sleep(5000);
      Thread.sleep(3000);
      //Thread.sleep(3000);
      
    //Expand the Controls
      assertTextXpath("//td[2]/span[1]");
      clickByXpath("//td[2]/span[1]");
      //Reporter.log("Expand the Controls | ");
      Thread.sleep(5000); 
        
     //Click on Notes button to add text
	    assertTextXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a/i");
	    clickByXpath("//*[@id='riskQuestionsControls']/tbody/tr[5]/td[7]/div/a/i");
	    //Reporter.log("Click on Notes button to add text | ");
	    Thread.sleep(5000);
	    Thread.sleep(3000);
	      
	    
	    // Click on Listed Notes
	      assertTextXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
	      clickByXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
	      //Reporter.log("Click on Notes button | ");
	      Thread.sleep(5000);
	      Thread.sleep(3000); 
	      
	      // Check whether New Edit and delete button are available
	      NotDisplayedTextByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div");
	      Thread.sleep(3000); 
		  
	       //Click on Close button in popup
		    assertTextXpath("//div[4]/div/div/div[1]/button");
		    clickByXpath("//div[4]/div/div/div[1]/button");
		    //Reporter.log("Click on Close button in popup | ");
		    Thread.sleep(5000);
		    Thread.sleep(3000);	 
		    
		    
		    //Expand the Controls
		      assertTextXpath("//td[2]/span[1]");
		      clickByXpath("//td[2]/span[1]");
		      //Reporter.log("Expand the Controls | ");
		      Thread.sleep(5000); 
	  
	  
	  
	  } 
	  
	  @Test( priority=21, enabled = false)
	  public void IRM6657() throws InterruptedException, IOException {
		  
	  
	        // Added in Scripts 
	  
	  
	  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM6565() throws InterruptedException, IOException {
		  
	  
	        // Will Updated after knowing Xpaths for Risk Likehood  
	  
	  
	  
	  }
	  
	  
	  // added afterwards
	  @Test( priority=21, enabled = false)
	  public void IRM6420() throws InterruptedException, IOException {
		  
	  
		//Click on the Created new Entity drop-down from Header 
	 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		   Thread.sleep(5000);
		   
		  //Enter Created Entity Name in Search box
		   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		   //Reporter.log("Enter Created Entity Name in Search box | ");
		   Thread.sleep(3000);
		   //Thread.sleep(3000);
		   
		   //Select the Searched Entity
		   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		   //Reporter.log("Select the Searched Entity | ");
		   Thread.sleep(5000);
		   Thread.sleep(5000);
		   Thread.sleep(5000);
	   
	 		//Click on Control Type Filter drop-down
	   	     clickByXpath("//*[@id='control-type']");
	   	     Thread.sleep(3000);
	   	     clickByXpath("//*[@id='cw-panelbar']/div/div[3]/cw-drop-list[1]/div/ul/li[3]/a");
	   	     Thread.sleep(5000);
	   	     Thread.sleep(5000); 
	   	     Thread.sleep(5000); 	
	   	     
			 //Click on + Icon to open Control 
			  assertTextXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
			  clickByXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
			  //Reporter.log("Click on + Icon to open Control | ");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  //Thread.sleep(3000);
		  
		 //Click on any other option response control in open Controls for negative scenario
		  assertTextXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[4]/cw-s-response-choices/div/div/label[2]");
		  clickByXpath("//*[@id='0-control']/td[2]/table/tbody/tr[1]/td[4]/cw-s-response-choices/div/div/label[2]");
		  Reporter.log("Click on any other option response control in open Controls | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  //Thread.sleep(3000);		  
		  
		  //Click on + Icon to open Control 
		  assertTextXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
		  clickByXpath("//*[@id='container-body']/tr[1]/td[3]/span[1]");
		  //Reporter.log("Click on + Icon to open Control | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  //Thread.sleep(3000);
	  
	  
	  
	  }  
	  @Test( priority=21, enabled = false)
	  public void IRM6235() throws InterruptedException, IOException {
		  
	  
	        // Added in Scripts 
	  
	  
	  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM6234() throws InterruptedException, IOException {
		  
	  
	        // need to updated only after issue fixed
	  
	  
	  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM6203() throws InterruptedException, IOException {
		  
	  
	        // Added in Scrpts l
	  
	  
	  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM6191() throws InterruptedException, IOException {
		  
	  
	        // need to updated now
	  
	  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM6171() throws InterruptedException, IOException {
		  
	  
	        // Added in scripts
	  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5940() throws InterruptedException, IOException {
		  
	  
	        // Added in scripts
	  
	  }
	  
	  // added afterwards
	  @Test( priority=21, enabled = false)
	  public void IRM5888() throws InterruptedException, IOException {
		  
	  
	        // Updated now
	  
	  }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5773() throws InterruptedException, IOException {
		  
	  
	        // Cant scripts it
	  
	 }
	  // Not related to cascading function
	  @Test( priority=21, enabled = false)
	  public void IRM5766() throws InterruptedException, IOException {
		  
	  
	        //Updated now in Clearwater modules wise
	  
	 }
	  @Test( priority=21, enabled = false)
	  public void IRM5437() throws InterruptedException, IOException {
		  
	  
	        //Updated now
	  
	 }
	  // Added aftrewards
	  @Test( priority=21, enabled = false)
	  public void IRM5410() throws InterruptedException, IOException {
		  
		//  5222 
	  
	        //Updated now immediately documents
		  
	  
	 }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5383() throws InterruptedException, IOException {
		  
	  
	        //Added in scripts
		  
	  
	 }
	  
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5227() throws InterruptedException, IOException {
		  
	  
	        // Added in scripts
	  
	 }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5222 () throws InterruptedException, IOException {
		  
		
	  
	        //Updated now immediately 
		  
	  
	 }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5203 () throws InterruptedException, IOException {
		  
		
	  
	        //Think and do
		  
	  
	 }
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5182() throws InterruptedException, IOException {
		  
		
	  
	        //update immdeiately
		  
	  
	 }
	  @Test( priority=21, enabled = false)
	  public void IRM5157() throws InterruptedException, IOException {
		  
		
	  
	        //Added in scripts
		  
	  
	 }
	  
	  
	  @Test( priority=21, enabled = false)
	  public void IRM5153() throws InterruptedException, IOException {
		  
	  
	        // Cant scripts it
	  
		  
	 } 
	  
	  //5120 - think and do
	  //5110 - Added in scripts
	  //5102 - Added in scripts
	  //5096 - Added in scripts
	  //5040 - Added in Scripts
	  //5030 - Added in scripts
	 //4666 - Added in scripts - recheck it
	  //4660 - Added in scripts
	  //4637 - not related to cascading
	  // 4457 - Added in scripts
      // 4455 - Updated in scripts
	  // 4450 - Added in scripts
	  // 4442 - Added in scripts
	  // 4320 & 4319 - importatnt to update
	  // 3700- Added in scripts
	  // 3371 - Added in scripts
	  // 2379 - Added in scripts
	  // 2376 - added in scripts
	  // 2374 - Added in SCripts
	  // 2337 - Added in scripts
	  // 2330 - Added in SCripts
	  // 2046 - Added in scripts
	  // 2025 - Added in scripts
	  // 1133- Added in scripts
	  // 1025 - Added in scrpts
	  // 612 - Added only after issue got fixede
	  
	//  -----------------------------------------
	  
	  
	 
	// 4320 & 4319 - Completed
	//5120 - Done
	//5153 and IRM5773 - Cant Script it
	  
	  //IRM6203 - Cant Script it
	// IRM5182 - Done
	//  IRM5203 - Done
	// 5410 - Done for Documents
	  // IRM5437 - Done for Documents
	// IRM5222 - Parent operation need to compare
	 // IRM6191 - Done 
	  //IRM6234 - done
	  
	 // IRM5888 - need to do now
	  // 4455 - How to check add edit and delete button not avaiable
	  
	  //4666 - Added in scripts - Need to took all controls Response - but done for only one
	  
	  
	  
	  
}
