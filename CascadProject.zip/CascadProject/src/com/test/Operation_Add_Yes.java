package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Operation_Add_Yes extends WrapperClass{
	
public WebDriver driver;
  String browser=null;
  String ParentEntity = "ParentCheck";
  String ChildEntity = "ChildCheck";
  String GrantChildEntity = "GrantChildCheck";
  String GreatGrantChildEntity = "GreatGrantChildCheck";
  String GreatGreatGrantChildEntity = "Great-GreatGrantChildCheck";

  @Test(priority=207, enabled = true)
  public void Parent_AddOperation_Yes() throws IOException, InterruptedException {
	  
		Thread.sleep(8000);
		  Thread.sleep(8000); 
		  Thread.sleep(8000); 
		  Thread.sleep(8000);
		  Thread.sleep(8000); 
		  Thread.sleep(8000); 
		  Thread.sleep(8000); 
		  Thread.sleep(8000); 
		  
		//Close Dashboard 
		 assertTextXpath("//*[@id='sidebar-left']/ul/li[1]/a/span[2]");
		clickByXpath("//*[@id='sidebar-left']/ul/li[1]/a/span[2]");
		Thread.sleep(8000);
    
        //Click on Full screen
        assertTextXpath("//*[@id='fullscreen']/i");
     	clickByXpath("//*[@id='fullscreen']/i");
    	Thread.sleep(8000);
    	Thread.sleep(3000);
    	//Thread.sleep(3000);		
	
 	//Click on Manage Account Module
    assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
    clickByXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
    Reporter.log("Click on Manage Account Module | ");
    Thread.sleep(3000);
    //Thread.sleep(3000);
			
    //Click on Cascading Sub-Module
    assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[7]/a");
    clickByXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[7]/a");
    Reporter.log("Click on Cascading Sub-Module | ");
    Thread.sleep(8000);
    Thread.sleep(8000);
    
    //Click on the Created new Entity drop-down from Header 
	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/a/span/span[1]");
	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/a/span/span[1]");
	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
	Thread.sleep(3000);
			   
	//Enter Created Entity Name in Search box
	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/ul/li[1]/input");
	sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/ul/li[1]/input", ParentEntity);
	//Reporter.log("Enter Created Entity Name in Search box | ");
	Thread.sleep(3000);
	//Thread.sleep(3000);
	
	//Select the Searched Entity
	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[5]/ul/li[2]/a");
	//Reporter.log("Select the Searched Entity | ");
	Thread.sleep(8000);
	Thread.sleep(8000);
	Thread.sleep(8000);   
	Thread.sleep(8000);
	Thread.sleep(8000);
	Thread.sleep(8000); 
    
    //Click on the listed Cascading 
    assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
    clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
    Reporter.log("Click on View button | ");
    Thread.sleep(3000);
    //Thread.sleep(3000);    
    
  //Click on Edit Button 
    assertTextXpath("//a[3]/span/i");
    clickByXpath("//a[3]/span/i");
    Reporter.log("Click on Edit button | ");
    Thread.sleep(8000);
    Thread.sleep(3000);
    
    //Click on Delete Checkbox 
    assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
    clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
    Reporter.log("Click on Delete Checkbox  | ");
    Thread.sleep(3000);
    //Thread.sleep(3000);

    //Click on Save Button 
    assertTextXpath("//*[@id='submitButton']/span[1]");
    clickByXpath("//*[@id='submitButton']/span[1]");
    Reporter.log("Click on Save button | ");
    Thread.sleep(8000);
    Thread.sleep(3000);
    
}

@Test(priority=208, enabled = true)
public void Parent_Add_Response_GlobalControls() throws IOException, InterruptedException {
	

	  Thread.sleep(8000);
			  
		  //Select Risk Determination sidebar-left Module
		    try {
		    	assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	 	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	 	        Reporter.log("Select Risk Determination sidebar-left Module | ");
	        }catch(Exception e)
			{
		        e.printStackTrace();
			    Reporter.log("Select Risk Determination sidebar-left Module doesn't reached | ");
			}
	        Thread.sleep(3000);
	        //Thread.sleep(3000);
	        
	        //Select Controls - Global/Media sub-module under Risk determination Module 
			  assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
			  clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
			  Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
			  Thread.sleep(8000);
			  Thread.sleep(8000);
			  //Thread.sleep(3000);
			  		  
			 //Click on Control Type Filter drop-down
			  clickByXpath("//*[@id='control-type']");
			  Thread.sleep(3000);
			  clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[1]/div/ul/li[2]/a");
			  Thread.sleep(8000);
			  Thread.sleep(8000); 
			  Thread.sleep(8000); 	
			  Thread.sleep(8000); 
			  Thread.sleep(8000); 
			  
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  Thread.sleep(8000);
			   	 
			  //Update any other Response 
			  clickByXpath("//*[@id='container-body']/tr[25]/td[4]/cw-s-response-choices/div/div/label[1]");
			  Thread.sleep(3000); 
			  
			 // Get the Parent Response Color
			  ParentResponseColor1("//*[@id='container-body']/tr[25]/td[4]/cw-s-response-choices/div/div/label[1]");
			  //Reporter.log(" Get the Parent Note TextValue | ");
			  Thread.sleep(5000);
         }

        @Test(priority=209, enabled = true)
        public void Parent_Add_Notes_GlobalControls() throws IOException, InterruptedException {
	  
			  // Click on Notes button 
			  assertTextXpath("//*[@id='container-body']/tr[25]/td[6]/div/a");
			  clickByXpath("//*[@id='container-body']/tr[25]/td[6]/div/a");
			  Reporter.log("Click on Notes button | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  
			  // Click on New Button in Notes pop-up window
			  assertTextXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[1]/span");
			  clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[1]/span");
			  Reporter.log("Click on New Button in Notes pop-up window | ");
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
			  
			  // Enter some text in notes Editor 
			  assertTextXpath("//*[@id='DTE_Field_text']");
			  sendvaluebyxpath("//*[@id='DTE_Field_text']", "Add Operation - Yes");
			  Reporter.log("Enter some text in notes Editor | ");
			  Thread.sleep(5000);
			  Thread.sleep(3000);
			  
			  // Click on Create Button in Create Note pop-up window
			  assertTextXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
			  clickByXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
			  Reporter.log("Click on Create Button in Create Note pop-up window | ");
			  Thread.sleep(5000);
			  Thread.sleep(3000);
			  
			// Get the Parent Note TextValue
			  ParentGlobalNotevalue("//*[@id='note-details-table_info']");
			  //Reporter.log(" Get the Parent Note TextValue | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  			  
			  // Click on Close Button in note pop-up window
			  assertTextXpath("html/body/div[4]/div/div/div[1]/button");
			  clickByXpath("html/body/div[4]/div/div/div[1]/button");
			  Reporter.log("Click on Close Button in note pop-up window | ");
			  Thread.sleep(3000);
			  //Thread.sleep(3000);
			  //Thread.sleep(3000);
			  Thread.sleep(4000);
			  
         }
	
        @Test(priority=210, enabled = true)
        public void Parent_Add_Documents_GlobalControls() throws IOException, InterruptedException {
	  
			  //Click on Document to upload
			    assertTextXpath("//*[@id='container-body']/tr[25]/td[7]/a/a");
			    clickByXpath("//*[@id='container-body']/tr[25]/td[7]/a/a");
			    Reporter.log("Click on Document to upload | ");
			    Thread.sleep(8000);
			    
			    //Click on New button from document pop-up
			    assertTextXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[1]/span");
			    clickByXpath("//*[@id='document-details-table_wrapper']/div[1]/div[1]/div/a[1]/span");
			    Reporter.log("Click on New button from document pop-up | ");
			    Thread.sleep(8000);
			    
			    //Click on Choose File from document pop-up
			    assertTextXpath("html/body/div[6]/div/div/div/div[3]/div/form/div/div[1]/div/div[1]/div/div/div[1]/div[1]/button");
			    clickByXpath("html/body/div[6]/div/div/div/div[3]/div/form/div/div[1]/div/div[1]/div/div/div[1]/div[1]/button");
			    Reporter.log("Click on Choose File from document pop-up | ");
			    Thread.sleep(8000);
			    
			    // Using AutoIT
		        Runtime.getRuntime().exec("C:\\Users\\User\\eclipse-workspace\\ClearWater\\AutoIT\\importfiles\\Fileupload4.exe"); //Uploading xls file using AutoIT
		        Reporter.log("Given Filepath of pdf file | ");
		        Thread.sleep(8000);
		        Thread.sleep(3000);
		        //Thread.sleep(8000);
		        
		        //Click on Upload button from document pop-up
			    assertTextXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
			    clickByXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
			    Reporter.log("Click on Upload button from document pop-up | ");
			    Thread.sleep(8000);
			    Thread.sleep(3000);
		
			    // Get the Parent Documents TextValue
				  ParentGlobalDocumentvalue("//*[@id='document-details-table_info']");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
			    			    
			    // Click on Close button		  
			    assertTextXpath("//div[4]/div/div/div[3]/button");
			    clickByXpath("//div[4]/div/div/div[3]/button");
			    Reporter.log("Click on CLose Button | ");
			    Thread.sleep(8000); 
			    Thread.sleep(3000); 
			    
              }

              @Test(priority=211, enabled = true)
              public void Parent_AddOperation_Yes_Cascading() throws IOException, InterruptedException {
			    
			  //Click on Full screen
			    assertTextXpath("//*[@id='fullscreen']/i");
				clickByXpath("//*[@id='fullscreen']/i");
				Thread.sleep(8000);
				//Thread.sleep(3000);
				//Thread.sleep(3000);		
		 	
		     	//Click on Manage Account Module
			    assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
			    clickByXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
			    Reporter.log("Click on Manage Account Module | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
						
			    //Click on Cascading Sub-Module
			    assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[7]/a");
			    clickByXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[7]/a");
			    Reporter.log("Click on Cascading Sub-Module | ");
			    Thread.sleep(8000);
			    Thread.sleep(8000);
			    
			    //Click on the listed Cascading 
			    assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			    clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			    Reporter.log("Click on View button | ");
			    Thread.sleep(3000);
			    //Thread.sleep(3000);
			  
			    // Click on Cascade button
			    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
			    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
			    Reporter.log("Click on Cascade button | ");
			    Thread.sleep(8000);
			    //Thread.sleep(3000);
			    
			    // Click on Cascade button
			    assertTextXpath("//*[@id='submitButton']/span[1]");
			    clickByXpath("//*[@id='submitButton']/span[1]");
			    Reporter.log("Click on Cascade button | ");
			    Thread.sleep(8000);
			    //Thread.sleep(3000);
			    
			    // Click on Proceed button
			    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
			    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
			    Reporter.log("Click on Proceed button | ");
			    Thread.sleep(8000);
			    Thread.sleep(8000);
			    Thread.sleep(8000);
			    Thread.sleep(8000);
			    
           }

            @Test(priority=212, enabled = true)
            public void Navigate_ChildEntity() throws IOException, InterruptedException {
			    
			   //Select Risk Determination sidebar-left Module
			    try {
			    	assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
		 	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
		 	        Reporter.log("Select Risk Determination sidebar-left Module | ");
		        }catch(Exception e)
				{
			        e.printStackTrace();
				    Reporter.log("Select Risk Determination sidebar-left Module doesn't reached | ");
				}
		        Thread.sleep(8000);
		        //Thread.sleep(3000);
		        
		        //Select Controls - Global/Media sub-module under Risk determination Module 
				  assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
				  clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
				  Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
				  Thread.sleep(8000);
				  Thread.sleep(8000);
				  //Thread.sleep(3000);	
			    
			    //Click on the Created new Entity drop-down from Header 
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
		    	Thread.sleep(3000);
						   
		    	//Enter Created Entity Name in Search box
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    	sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		    	//Reporter.log("Enter Created Entity Name in Search box | ");
		    	Thread.sleep(3000);
		    	//Thread.sleep(3000);
		    	
		    	//Select the Searched Entity
				clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
				//Reporter.log("Select the Searched Entity | ");
				Thread.sleep(8000);
				Thread.sleep(8000);
				Thread.sleep(8000);
				Thread.sleep(8000);
				
				//Click on Control Type Filter drop-down
				  clickByXpath("//*[@id='control-type']");
				  Thread.sleep(3000);
				  clickByXpath("//*[@id='cw-panelbar']/div/div[4]/cw-drop-list[1]/div/ul/li[2]/a");
				  Thread.sleep(8000);
				  Thread.sleep(8000); 
				  Thread.sleep(8000); 
				  Thread.sleep(8000);
				  
              }

         @Test(priority=213, enabled = true)
        public void Child_Get_Response_GlobalControls() throws IOException, InterruptedException {
				  
        	 ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  ArrowDown();
			  Thread.sleep(8000);
				  
				  // Get the Parent Response Color
				  ChildResponseColor1("//*[@id='container-body']/tr[25]/td[4]/cw-s-response-choices/div/div/label[1]");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(1000);
				  
                  }

         @Test(priority=214, enabled = true)
         public void Child_Get_Notes_GlobalControls() throws IOException, InterruptedException {
				  
				  // Click on Notes button 
				  assertTextXpath("//*[@id='container-body']/tr[25]/td[6]/div/a");
				  clickByXpath("//*[@id='container-body']/tr[25]/td[6]/div/a");
				  Reporter.log("Click on Notes button | ");
				  Thread.sleep(3000);
				  Thread.sleep(3000);
				  
				// Get the Parent Note TextValue
				  ChildGlobalNotevalue("//*[@id='note-details-table_info']");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(3000);
				  //Thread.sleep(3000);
				  			  
				  // Click on Close Button in note pop-up window
				  assertTextXpath("html/body/div[4]/div/div/div[3]/button");
				  clickByXpath("html/body/div[4]/div/div/div[3]/button");
				  Reporter.log("Click on Close Button in note pop-up window | ");
				  Thread.sleep(8000);
				  
				  
         }

        @Test(priority=215, enabled = true)
        public void Child_Get_Documents_GlobalControls() throws IOException, InterruptedException {
	  
				  //Click on Document to upload
				    assertTextXpath("//*[@id='container-body']/tr[25]/td[7]/a/a");
				    clickByXpath("//*[@id='container-body']/tr[25]/td[7]/a/a");
				    Reporter.log("Click on Document to upload | ");
				    Thread.sleep(8000);
			
				    // Get the Parent Documents TextValue
					ChildGlobalDocumentvalue("//*[@id='document-details-table_info']");
					  //Reporter.log(" Get the Parent Note TextValue | ");
					  Thread.sleep(3000);
					  //Thread.sleep(3000);
				    			    
				    // Click on Close button		  
				    assertTextXpath("//div[4]/div/div/div[3]/button");
				    clickByXpath("//div[4]/div/div/div[3]/button");
				    Reporter.log("Click on CLose Button | ");
				    Thread.sleep(8000); 
				    Thread.sleep(3000); 	 
        }

              @Test(priority=216, enabled = true)
              public void Compare_Response_GlobalRelated() throws IOException, InterruptedException {
 	     
	      	
		   
		 //Get the Compare the Response Color
	       CompareResponseColor1("ParentResponse1","ChildResponse1");
		   Thread.sleep(1000);	
		   
         }
 	     
       @Test(priority=217, enabled = true)
            public void Compare_Notes_GlobalRelated() throws IOException, InterruptedException {
 
	  //Thread.sleep(3000);
	  	  // Get the Compare the Note TextValue
	CompareGlobalNotevalue("ParentGlobalNote","ChildGlobalNote");
	  Thread.sleep(3000);
		  
	  
              }

              @Test(priority=218, enabled = true)
         public void Compare_Documents_GlobalRelated() throws IOException, InterruptedException {
 
	//  Thread.sleep(3000);
	// Get the Compare the Documents TextValue
	CompareGlobalDocumentvalue("ParentGlobalDocument","ChildGlobalDocument");
	    Thread.sleep(3000);
	 
          }  
            }

