package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Operation_Delete_No extends WrapperClass{
	
public WebDriver driver;
  String browser=null;
  String ParentEntity = "ParentBook";
  String ChildEntity = "ChildBook";
  String GrantChildEntity = "GrantChildBook";
  String GreatGrantChildEntity = "GreatGrantChildBook";
  
  
  @Test(priority=289, enabled = true)
  public void Parent_Delete_Response_GlobalControls() throws IOException, InterruptedException {
	  
	  Thread.sleep(5000);
/*	  Thread.sleep(5000);
	  Thread.sleep(5000);
	  Thread.sleep(5000);
		  
		  //Select Risk Determination sidebar-left Module
		    try {
		    	assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	 	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	 	        Reporter.log("Select Risk Determination sidebar-left Module | ");
	        }catch(Exception e)
			{
		        e.printStackTrace();
			    Reporter.log("Select Risk Determination sidebar-left Module doesn't reached | ");
			}
	        Thread.sleep(3000);
	        //Thread.sleep(3000);
	        
	        //Select Controls - Global/Media sub-module under Risk determination Module 
			  assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
			  clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
			  Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
			  Thread.sleep(5000);
			  Thread.sleep(5000);
			  //Thread.sleep(3000);
*/			  		  
			//Click on the Created new Entity drop-down from Header 
				assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
				clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
				//Reporter.log("Click on the Created new Entity drop-down from Header | ");
				Thread.sleep(3000);
						   
				//Enter Created Entity Name in Search box
				assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
				sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
				//Reporter.log("Enter Created Entity Name in Search box | ");
				Thread.sleep(3000);
				//Thread.sleep(3000);
				
				//Select the Searched Entity
				clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
				//Reporter.log("Select the Searched Entity | ");
				Thread.sleep(5000);
				Thread.sleep(5000);
				Thread.sleep(5000);
				
			 //Click on Control Type Filter drop-down
			  clickByXpath("//*[@id='control-type']");
			  Thread.sleep(3000);
			  clickByXpath("//*[@id='cw-panelbar']/div/div[3]/cw-drop-list[1]/div/ul/li[2]/a");
			  Thread.sleep(5000);
			  Thread.sleep(5000); 
			  Thread.sleep(5000); 	
			  
			 // Get the Parent Response Color
			  ParentResponseColor1("//*[@id='container-body']/tr[21]/td[4]/cw-s-response-choices/div/div/label[1]");
			  //Reporter.log(" Get the Parent Note TextValue | ");
			  Thread.sleep(1000);
			  
			//Update any other Response 
			  clickByXpath("//*[@id='container-body']/tr[21]/td[5]/cw-s-response-clear/div/span/i");
			  Thread.sleep(3000); 
			  clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
			  Thread.sleep(3000); 
			  
			  
  }
  
      @Test(priority=290, enabled = true)
      public void Parent_DeleteOperation_No() throws IOException, InterruptedException {
 		   
	  
	  
	  //Click on Full screen
	    assertTextXpath("//*[@id='fullscreen']/i");
		clickByXpath("//*[@id='fullscreen']/i");
		Thread.sleep(5000);
		//Thread.sleep(2000);
		//Thread.sleep(2000);		
 	
		//Click on Manage Account Module
	    assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
	    clickByXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
	    Reporter.log("Click on Manage Account Module | ");
	    Thread.sleep(3000);
	    //Thread.sleep(3000);
				
	    //Click on Cascading Sub-Module
	    assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[5]/a");
	    clickByXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[5]/a");
	    Reporter.log("Click on Cascading Sub-Module | ");
	    Thread.sleep(5000);
	    Thread.sleep(5000);
	    
	    //Click on the listed Cascading 
	    assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
	    clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
	    Reporter.log("Click on View button | ");
	    Thread.sleep(2000);
	    //Thread.sleep(2000);
	    
	    //Click on Edit Button 
	    assertTextXpath("//a[3]/span/i");
	    clickByXpath("//a[3]/span/i");
	    Reporter.log("Click on Edit button | ");
	    Thread.sleep(5000);
	    Thread.sleep(2000);
	    
	    //Check on Add Checkbox 
		  assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		  clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[2]/div");
		  Reporter.log("Click on Add Checkbox  | ");
		  Thread.sleep(2000);
		  //Thread.sleep(2000);
		  
		//UnCheck on Delete Checkbox 
		  assertTextXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		  clickByXpath("//*[@id='cascade_profile']/div[1]/div[2]/div/div[2]/table/tbody/tr/td[3]/div");
		  Reporter.log("Click on Add Checkbox  | ");
		  Thread.sleep(2000);
		  //Thread.sleep(2000);
		  
		  ArrowDown();
		  ArrowDown();
		  ArrowDown();
		  Thread.sleep(2000);
		  
		//Click on Save Button
		  assertTextXpath("//div[3]/div/div/span");
		  clickByXpath("//div[3]/div/div/span");
		  Reporter.log("Click on Save button |");
		  Thread.sleep(8000);
		  Thread.sleep(8000);
		 
  }
 
  @Test(priority=291, enabled = true)
  public void Parent_DeleteOperation_No_Cascading() throws IOException, InterruptedException {
			    
			    
			    //Click on the listed Cascading 
			    assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			    clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			    Reporter.log("Click on View button | ");
			    Thread.sleep(2000);
			    //Thread.sleep(2000);
			  
			    // Click on Cascade button
			    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
			    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
			    Reporter.log("Click on Cascade button | ");
			    Thread.sleep(5000);
			    //Thread.sleep(2000);
			    
			    // Click on Cascade button
			    assertTextXpath("//*[@id='submitButton']/span[1]");
			    clickByXpath("//*[@id='submitButton']/span[1]");
			    Reporter.log("Click on Cascade button | ");
			    Thread.sleep(5000);
			    //Thread.sleep(2000);
			    
			    // Click on Proceed button
			    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
			    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
			    Reporter.log("Click on Proceed button | ");
			    Thread.sleep(5000);
			    Thread.sleep(5000);
			    Thread.sleep(5000);
			    Thread.sleep(5000);
			    
  }
  
  @Test(priority=292, enabled = true)
  public void Navigate_ChildEntity() throws IOException, InterruptedException {
			    
			   //Select Risk Determination sidebar-left Module
			    try {
			    	assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
		 	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
		 	        Reporter.log("Select Risk Determination sidebar-left Module | ");
		        }catch(Exception e)
				{
			        e.printStackTrace();
				    Reporter.log("Select Risk Determination sidebar-left Module doesn't reached | ");
				}
		        Thread.sleep(5000);
		        //Thread.sleep(3000);
		        
		        //Select Controls - Global/Media sub-module under Risk determination Module 
				  assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
				  clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
				  Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
				  Thread.sleep(5000);
				  Thread.sleep(5000);
				  //Thread.sleep(3000);	
			    
			    //Click on the Created new Entity drop-down from Header 
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
		    	Thread.sleep(3000);
						   
		    	//Enter Created Entity Name in Search box
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    	sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		    	//Reporter.log("Enter Created Entity Name in Search box | ");
		    	Thread.sleep(3000);
		    	//Thread.sleep(3000);
		    	
		    	//Select the Searched Entity
				clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
				//Reporter.log("Select the Searched Entity | ");
				Thread.sleep(5000);
				Thread.sleep(5000);
				Thread.sleep(5000);
				
				//Click on Control Type Filter drop-down
				  clickByXpath("//*[@id='control-type']");
				  Thread.sleep(3000);
				  clickByXpath("//*[@id='cw-panelbar']/div/div[3]/cw-drop-list[1]/div/ul/li[2]/a");
				  Thread.sleep(5000);
				  Thread.sleep(5000); 
				  Thread.sleep(5000); 
				  
  }
  
  @Test(priority=293, enabled = true)
  public void Child_Get_Response_GlobalControls() throws IOException, InterruptedException {
				  
				  
				  
				  // Get the Parent Response Color
				  ChildResponseColor1("//*[@id='container-body']/tr[21]/td[4]/cw-s-response-choices/div/div/label[1]");
				  //Reporter.log(" Get the Parent Note TextValue | ");
				  Thread.sleep(1000);
				  
  }
  
 
 
  @Test(priority=295, enabled = true)
  public void Compare_Response_GlobalRelated() throws IOException, InterruptedException {
   	     
	      	
		   
		 //Get the Compare the Response Color
	  CompareResponseColor1("ParentResponse1","ChildResponse1");
		   Thread.sleep(1000);	
		   
  }
   	     
  
}
