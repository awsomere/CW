package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Override extends WrapperClass{
	
	 public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "BookParent";
	  String ChildEntity = "BookChild";
	  String GrantChildEntity = "BookGrantChild";
	  String GreatGrantChildEntity = "BookGreatGrantChild";
	
	  @Test(priority=86, enabled = true)
	  public void DeleteResponse_Override_GlobalRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
		  
		  //Select Risk Determination sidebar-left Module
		    try {
		    	assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	 	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	 	        Reporter.log("Select Risk Determination sidebar-left Module | ");
	        }catch(Exception e)
			{
		        e.printStackTrace();
			    Reporter.log("Select Risk Determination sidebar-left Module doesn't reached | ");
			}
	        Thread.sleep(3000);
	        //Thread.sleep(3000);
      
      //Select Controls - Global/Media sub-module under Risk determination Module 
      assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
      clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
      Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
      Thread.sleep(3000);
      Thread.sleep(5000);
      //Thread.sleep(3000);
	   	     
      //Click on the Created new Entity drop-down from Header 
      assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
      clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
      //Reporter.log("Click on the Created new Entity drop-down from Header | ");
      Thread.sleep(3000);
						   
      //Enter Created Entity Name in Search box
      assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
      sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
      //Reporter.log("Enter Created Entity Name in Search box | ");
      Thread.sleep(3000);
      //Thread.sleep(3000);
		    	
      //Select the Searched Entity
      clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
      //Reporter.log("Select the Searched Entity | ");
      Thread.sleep(5000);
      Thread.sleep(5000);
      Thread.sleep(3000);
						   
      //Click on Control Type Filter drop-down
      clickByXpath("//*[@id='control-type']");
      Thread.sleep(3000);
      clickByXpath("//*[@id='cw-panelbar']/div/div[3]/cw-drop-list[1]/div/ul/li[2]/a");
      Thread.sleep(5000);
      Thread.sleep(5000); 
      Thread.sleep(5000);
      
      //Delete the Response in child entity 
      assertTextXpath("//*[@id='container-body']/tr[3]/td[5]/cw-s-response-clear/div/span/i");
      clickByXpath("//*[@id='container-body']/tr[3]/td[5]/cw-s-response-clear/div/span/i");
      Thread.sleep(5000);
      //Thread.sleep(3000);			
      
      //Click on Remove button
      assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
      clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
      Thread.sleep(5000);	
			    
	  }
	  
	  @Test(priority=87, enabled = true)
	  public void DeleteNotes_Override_GlobalRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
		  
		  // Click on Notes button 
		  assertTextXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
		  clickByXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
		  //Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
			    
		  // Click on listed notes
		  clickByXpath("//*[@id='note-details-table']/tbody/tr/td[2]");
		  // Reporter.log(" Get the Child Note TextValue | ");
		  Thread.sleep(3000);
				  
		  // Click on Delete button
		  clickByXpath("//*[@id='note-details-table_wrapper']/div[1]/div[1]/div/a[3]");
		  Thread.sleep(3000);
		  clickByXpath("html/body/div[6]/div/div/div/div[4]/div[3]/button[1]");
		  Thread.sleep(3000);				
				  
		  // Click on Close Button in note pop-up window
		  assertTextXpath("//div[4]/div/div/div[3]/button");
		  clickByXpath("//div[4]/div/div/div[3]/button");
		  //Reporter.log("Click on Close Button in note pop-up window | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  //Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		  
	   	     
	  }  
	 
	  @Test(priority=88, enabled = true)
	   public void NavigatePage_CascadingProfilesList() throws IOException, InterruptedException {
		  
		        //Thread.sleep(5000);
		       // Thread.sleep(5000);
		        
		        //Click on the Created new Entity drop-down from Header 
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    	//Reporter.log("Click on the Created new Entity drop-down from Header | ");
		    	Thread.sleep(3000);
						   
		    	//Enter Created Entity Name in Search box
		    	assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    	sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
		    	//Reporter.log("Enter Created Entity Name in Search box | ");
		    	Thread.sleep(3000);
		    	//Thread.sleep(3000);
		    	
		    	//Select the Searched Entity
				clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
				//Reporter.log("Select the Searched Entity | ");
				Thread.sleep(5000);
				Thread.sleep(5000);
				Thread.sleep(5000);				        
			
		        //Click on Full screen
		 	    assertTextXpath("//*[@id='fullscreen']/i");
				clickByXpath("//*[@id='fullscreen']/i");
				Thread.sleep(5000);
				Thread.sleep(3000);
				//Thread.sleep(3000);
				//Thread.sleep(3000);
				
				// Testcase 1
				//Click on Manage Account Module
				assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
				clickByXpath("//*[@id='sidebar-left']/ul/li[9]/a/span[2]");
				Reporter.log("Click on Manage Account Module | ");
				Thread.sleep(5000);
				//Thread.sleep(3000);
				
				//Click on Cascading Sub-Module
				assertTextXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[5]/a");
				clickByXpath("//*[@id='sidebar-left']/ul/li[9]/ul/li[5]/a");
				Reporter.log("Click on Cascading Sub-Module | ");
				Thread.sleep(5000);
				Thread.sleep(3000);
				
	}
	  
	   
	  @Test(priority=89, enabled = true)
		 public void CascadeBtn_AdministrativeControls_CascadingProfilesList() throws IOException, InterruptedException { 
		    
			 Thread.sleep(3000);
			 
			// Testcase 32
			 //Click on the listed Cascading 
			 assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 Reporter.log("Click on View button | ");
			 Thread.sleep(3000);
			 //Thread.sleep(3000);
			 
			// Testcase 33
		    // Click on Cascade button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		    //Select Override Check-box 
		    assertTextXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    clickByXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);
		    
		    //Select Override Check-box 
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);
		    
		    // Click on Cascade button
		    assertTextXpath("//*[@id='submitButton']/span[1]");
		    clickByXpath("//*[@id='submitButton']/span[1]");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		    // Click on Proceed button
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Click on Proceed button | ");
		    Thread.sleep(5000);
		    Thread.sleep(3000);
	   	     	
     }	
	  @Test(priority=90, enabled = true)
		 public void CascadeBtn_MediaAsset_CascadingProfilesList() throws IOException, InterruptedException { 
		    
			 Thread.sleep(3000);
			 			 
			//Search the text
			 assertTextXpath("//*[@id='cascading-profile-list_filter']/label/input");
			 sendvaluebyxpath("//*[@id='cascading-profile-list_filter']/label/input", "Media");
			 Reporter.log("Searched the Text | ");
			 Thread.sleep(3000);
			 
			// Testcase 36
			//Click on the listed Cascading 
			 assertTextXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 clickByXpath("//*[@id='cascading-profile-list']/tbody/tr/td[2]");
			 Reporter.log("Click on View button | ");
			 Thread.sleep(3000);
			 //Thread.sleep(3000);
			 
		    // Click on Cascade button
		    assertTextXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    clickByXpath("//*[@id='cascading-profile-list_wrapper']/div[1]/div[1]/div/a[5]/span");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		    //Select Override Check-box 
		    assertTextXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    clickByXpath("//*[@id='body-content']/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div/label");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);
		    
		    //Select Override Check-box 
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Select Override Check-box  | ");
		    Thread.sleep(5000);
		    
		    // Click on Cascade button
		    assertTextXpath("//*[@id='submitButton']/span[1]");
		    clickByXpath("//*[@id='submitButton']/span[1]");
		    Reporter.log("Click on Cascade button | ");
		    Thread.sleep(5000);
		    //Thread.sleep(3000);
		    
		    // Click on Proceed button
		    assertTextXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    clickByXpath("html/body/div[4]/div/div/div[3]/button[1]");
		    Reporter.log("Click on Proceed button | ");
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(5000);
	   	     	
}	
	   	     
	   @Test(priority=91, enabled = true)
	   public void CHkDeleteResponseReappers_Override_GlobalRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		 
	 //Select Risk Determination sidebar-left Module
	    try {
	    	assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	        clickByXpath("//*[@id='sidebar-left']/ul/li[4]/a/span[2]");
	        Reporter.log("Select Risk Determination sidebar-left Module | ");
      }catch(Exception e)
		{
	        e.printStackTrace();
		    Reporter.log("Select Risk Determination sidebar-left Module doesn't reached | ");
		}
      Thread.sleep(3000);
      //Thread.sleep(3000);
      
         //Select Controls - Global/Media sub-module under Risk determination Module 
		  assertTextXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
		  clickByXpath("//*[@id='sidebar-left']/ul/li[4]/ul/li[1]/a");
		  Reporter.log("Select Controls - Global/Media sub-module under Risk determination Module | ");
		  Thread.sleep(3000);
		  Thread.sleep(5000);
		  //Thread.sleep(3000);	   	 
		  
		  //Click on Control Type Filter drop-down
	      clickByXpath("//*[@id='control-type']");
	      Thread.sleep(3000);
	      clickByXpath("//*[@id='cw-panelbar']/div/div[3]/cw-drop-list[1]/div/ul/li[2]/a");
	      Thread.sleep(5000);
	      Thread.sleep(5000); 
	      Thread.sleep(5000);
		  
		// Get the Parent Response Color
		   ParentResponseColor("//*[@id='container-body']/tr[3]/td[4]/cw-s-response-choices/div/div/label[4]");
		   //Reporter.log(" Get the Parent Note TextValue | ");
		   Thread.sleep(3000);	
  	     
     	// Click on Notes button 
		  assertTextXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
		  clickByXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
		  //Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		 // Get the Parent Note TextValue
		  ParentNotevalue("//*[@id='note-details-table_info']");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		// Click on Close Button in note pop-up window
		  assertTextXpath("//div[4]/div/div/div[3]/button");
		  clickByXpath("//div[4]/div/div/div[3]/button");
		  //Reporter.log("Click on Close Button in note pop-up window | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);		  
		  
		  //Click on the Created new Entity drop-down from Header 
		  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		  clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		  //Reporter.log("Click on the Created new Entity drop-down from Header | ");
		  Thread.sleep(3000);
		  
		  //Enter Created Entity Name in Search box
		  assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		  sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		  //Reporter.log("Enter Created Entity Name in Search box | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		    	
		  //Select the Searched Entity
		  clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		  //Reporter.log("Select the Searched Entity | ");
		  Thread.sleep(5000);
		  Thread.sleep(5000);
		  Thread.sleep(3000);
		  
		  //Click on Control Type Filter drop-down
		  clickByXpath("//*[@id='control-type']");
		  Thread.sleep(3000);
		  clickByXpath("//*[@id='cw-panelbar']/div/div[3]/cw-drop-list[1]/div/ul/li[2]/a");
		  Thread.sleep(5000);
		  Thread.sleep(5000); 
		  Thread.sleep(5000);
						   		
		// Get the Parent Response Color
		   ChildResponseColor("//*[@id='container-body']/tr[3]/td[4]/cw-s-response-choices/div/div/label[4]");
		   //Reporter.log(" Get the Parent Note TextValue | ");
		   Thread.sleep(3000);	
 
		  
	  }	
	  
	  @Test(priority=92, enabled = true)
	  public void ChkDeleteNotesreappears_Override_GlobalRelated() throws IOException, InterruptedException {
	   
		  Thread.sleep(5000);
		  
		// Click on Notes button 
		  assertTextXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
		  clickByXpath("//*[@id='container-body']/tr[3]/td[6]/div/a");
		  //Reporter.log("Click on Notes button | ");
		  Thread.sleep(5000);
		  //Thread.sleep(3000);
		  
		 // Get the Parent Note TextValue
		  ChildNotevalue("//*[@id='note-details-table_info']");
		  //Reporter.log(" Get the Parent Note TextValue | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);
		  
		// Click on Close Button in note pop-up window
		  assertTextXpath("//div[4]/div/div/div[3]/button");
		  clickByXpath("//div[4]/div/div/div[3]/button");
		  //Reporter.log("Click on Close Button in note pop-up window | ");
		  Thread.sleep(3000);
		  //Thread.sleep(3000);		
		  
	   	     
	  } 
	  
	  @Test(priority=93, enabled = true)
      public void DeletedResponseReappears_Child_GlobalRelated() throws IOException, InterruptedException {
	  
          // Get the Compare the Response Color
            CompareResponseColor("ParentResponse","ChildResponse");
           Thread.sleep(3000);

	      }  

          @Test(priority=94, enabled = true)
          public void DeletedNotesReappears_Child_GlobalRelated() throws IOException, InterruptedException {

           // Thread.sleep(5000);

            // Get the Compare the Note TextValue
            CompareNotevalue("ParentNote","ChildNote");
             Thread.sleep(3000);

                }

}
