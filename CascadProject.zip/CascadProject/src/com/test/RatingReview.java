package com.test;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
	
public class RatingReview extends WrapperClass{
		
	public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "ParentStageAgain";
	  String ChildEntity = "ChildStageAgain";
	  String GrantChildEntity = "GrantChildStageAgain";
	  String GreatGrantChildEntity = "GreatGrantChildStageAgain";
	  String GreatGreatGrantChildEntity = "Great-GreatGrantChildStageAgain"; 
	
 @Test(priority=115, enabled = true)
 public void Navigate_ParentEntity() throws IOException, InterruptedException {
			   
	 Thread.sleep(3000);		 
	 
	 //Click on rating review sub-module
	 assertTextLink("Rating Review");
	 clickBylinktext("Rating Review");
	 Reporter.log("Click on Rating review sub-module | ");
	 Thread.sleep(8000);
	 Thread.sleep(8000);
	 Thread.sleep(8000);
	  Thread.sleep(8000);
	  Thread.sleep(5000);
	 //Thread.sleep(3000);
	 
	 // Select Parent Entity from drop down
	 assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
	 clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
	 Thread.sleep(5000);
	 
	 //Enter Created Entity Name in Search box
	 assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
	 sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
	 //Reporter.log("Enter Created Entity Name in Search box | ");
	 Thread.sleep(3000);
	 //Thread.sleep(3000);
	 
	 //Select the Searched Entity
	 clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
	 //Reporter.log("Select the Searched Entity | ");
	 Thread.sleep(5000);
	 Thread.sleep(5000);
	 Thread.sleep(3000);
	 Thread.sleep(4000);
	 
 }
 
 	@Test(priority=116, enabled = true)
 	public void Parent_CascadeIcon_RiskRelated() throws IOException, InterruptedException {
 		
			 
 		//Sort the Vulnerability link to get Risk Notes 
 		clickByXpath("//*[@id='rating_review']/thead/tr[1]/th[1]/span[1]/span");
 		//Reporter.log("Select the Searched Entity | ");
	    Thread.sleep(5000);
	    Thread.sleep(2000);
	    /*clickByXpath("//*[@id='rating_review']/thead/tr[1]/th[6]/span[1]/span");
	    Thread.sleep(5000);
	    Thread.sleep(5000);*/
			   
		 //Click on Parent cascade Icon
	   /* assertTextXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
	    clickByXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
	    Thread.sleep(5000);
	    
	    //Click on Close button in Parent cascade Icon
	    assertTextXpath("html/body/div[4]/div/div/div[1]/button");
	    clickByXpath("html/body/div[4]/div/div/div[1]/button");
	    Thread.sleep(5000);	*/
	    
 	}
 	
 	@Test(priority=117, enabled = true)
 	public void Parent_RiskLikelihood_RiskRelated() throws IOException, InterruptedException {
 		
 		// Get the ParentRiskLikelihood
 		ParentRiskLikelihoodvalue("//*[@id='content']/tr[1]/td[9]/cw-rr-risk-choices/div/button");
 		//Reporter.log(" Get the Parent Note TextValue | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 		
 		
 	}
 	
 	@Test(priority=118, enabled = true)
 	public void Parent_RiskImpact_RiskRelated() throws IOException, InterruptedException {
 		
 		// Get the ParentRiskImpact
 		ParentRiskImpactvalue("//*[@id='content']/tr[1]/td[10]/cw-rr-risk-choices/div/button");
 		//Reporter.log(" Get the Parent Note TextValue | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 	}
 	
 	@Test(priority=119, enabled = true)
 	public void Parent_RiskRating_RiskRelated() throws IOException, InterruptedException {
 		
 		// Get the Risk Rating Value
 		ParentRiskRatingvalue("//*[@id='content']/tr[1]/td[11]/div/div/span");
 		//Reporter.log(" Get the Parent Note TextValue | ");
	    Thread.sleep(3000);
	    //Thread.sleep(3000);
	    
 	}
 	
 	@Test(priority=120, enabled = true)
 	public void Parent_Notes_RiskRelated() throws IOException, InterruptedException {
 		
 		//Click on Notes button to add text
 		assertTextXpath("//*[@id='content']/tr[1]/td[13]/div/a");
 		clickByXpath("//*[@id='content']/tr[1]/td[13]/div/a");
 		//Reporter.log("Click on Notes button to add text | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 		
 		// Get the Parent Note TextValue
 		ParentNotevalue("//*[@id='note-details-table_info']");
 		// Reporter.log(" Get the Parent Note TextValue | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 		
 		// Click on Close Button in note pop-up window
 		assertTextXpath("//div[4]/div/div/div[1]/button");
 		clickByXpath("//div[4]/div/div/div[1]/button");
 		//Reporter.log("Click on Close Button in note pop-up window | ");
 		Thread.sleep(3000);
 		Thread.sleep(3000);
			    
 }
		 
		 
 	@Test(priority=121, enabled = true)
 	public void Navigate_ChildEntity() throws IOException, InterruptedException {
 		
 		// Select Child Entity from drop down
 		assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
 		clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
 		Thread.sleep(5000);
 		
 		//Enter Created Entity Name in Search box
 		assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
 		sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
 		//Reporter.log("Enter Created Entity Name in Search box | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 		
 		//Select the Searched Entity
 		clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
 		// Reporter.log("Select the Searched Entity | ");
 		Thread.sleep(5000);
 		Thread.sleep(5000);
 		Thread.sleep(8000); 
 		Thread.sleep(8000); 		
	    Thread.sleep(8000);
	    Thread.sleep(8000); 		
	    Thread.sleep(8000);
	    Thread.sleep(8000);
 		Thread.sleep(5000);
 		
 	}
 	
 	@Test(priority=122, enabled = true)
 	public void Child_CascadeIcon_RiskRelated() throws IOException, InterruptedException {
 		
 		//Sort the Vulnerability link to get Risk Notes 
 		clickByXpath("//*[@id='rating_review']/thead/tr[1]/th[1]/span[1]/span");
 		//Reporter.log("Select the Searched Entity | ");
 		Thread.sleep(8000);
 		Thread.sleep(8000);
 		Thread.sleep(8000); 		
	    Thread.sleep(8000);
 		/*clickByXpath("//*[@id='rating_review']/thead/tr[1]/th[6]/span[1]/span");
		Thread.sleep(5000);
	    Thread.sleep(5000);*/
				   	
 		//Click on Child cascade Icon
 		/*assertTextXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
 		clickByXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
 		Thread.sleep(5000);
 		
 		//Click on Close button in Child cascade Icon
 		assertTextXpath("html/body/div[4]/div/div/div[1]/button");
 		clickByXpath("html/body/div[4]/div/div/div[1]/button");*/
 		Thread.sleep(5000);	   
 	}
		 
 	@Test(priority=123, enabled = true)
 	public void Child_RiskLikelihood_RiskRelated() throws IOException, InterruptedException {
 		
 		// Get the Child RiskLikelihood
 		ChildRiskLikelihoodvalue("//*[@id='content']/tr[1]/td[9]/cw-rr-risk-choices/div/button");
 		//Reporter.log(" Get the Parent Note TextValue | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 		
 	}
 	@Test(priority=124, enabled = true)
 	public void Child_RiskImpact_RiskRelated() throws IOException, InterruptedException {
 		
 		// Get the Child RiskImpact
 		ChildRiskImpactvalue("//*[@id='content']/tr[1]/td[10]/cw-rr-risk-choices/div/button");
 		//Reporter.log(" Get the Parent Note TextValue | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 	}
 		
 	@Test(priority=125, enabled = true)
 	public void Child_RiskRating_RiskRelated() throws IOException, InterruptedException {
 		
 			// Get the Risk Rating Value
 		ChildRiskRatingvalue("//*[@id='content']/tr[1]/td[11]/div/div/span");
 		//Reporter.log(" Get the Parent Note TextValue | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);	   
				    
 	}
 	
 	@Test(priority=126, enabled = true)
 	public void Child_Notes_RiskRelated() throws IOException, InterruptedException {
 		
 		//Click on Notes button to add text
 		assertTextXpath("//*[@id='content']/tr[1]/td[13]/div/a");
 		clickByXpath("//*[@id='content']/tr[1]/td[13]/div/a");
 		// Reporter.log("Click on Notes button to add text | ");
 		Thread.sleep(3000);
 		//Thread.sleep(3000);
 			
 		// Get the Child Note TextValue
	    ChildNotevalue("//*[@id='note-details-table_info']");
	    //Reporter.log(" Get the Parent Note TextValue | ");
	    Thread.sleep(3000);
	    //Thread.sleep(3000);
	    	
				    // Click on Close Button in note pop-up window
				    assertTextXpath("//div[4]/div/div/div[1]/button");
				    clickByXpath("//div[4]/div/div/div[1]/button");
				    //Reporter.log("Click on Close Button in note pop-up window | ");
				    Thread.sleep(3000);
				    Thread.sleep(3000);
				    
		 }
		 
		 @Test(priority=127, enabled = true)
		   public void Compare_RiskLikelihood_RiskRelated_RatingReview() throws IOException, InterruptedException {
			    
				 // Get the Compare RiskLikelihood
				    CompareRiskLikelihood("ParentRiskLikelihood","ChildRiskLikelihood");
				    Thread.sleep(3000);
					  
		 }
		 
		 @Test(priority=128, enabled = true)
		   public void Compare_RiskImpact_RiskRelated_RatingReview() throws IOException, InterruptedException {
			   
			// Thread.sleep(5000);
			 // Get the Compare Riskimpact
			    CompareRiskImpact("ParentRiskImpact","ChildRiskImpact");
			    Thread.sleep(3000);
			 
		 }
		 
		 @Test(priority=129, enabled = true)
		   public void Compare_RiskRating_RiskRelated_RatingReview() throws IOException, InterruptedException {
			   
			// Thread.sleep(5000);
			 
			// Get the Compare RiskRating 
			    CompareRiskRatingvalue("ParentRiskRating","ChildRiskRating");
			    Thread.sleep(3000);
			 
		 }
		 
		 @Test(priority=130, enabled = true)
		   public void Compare_Notes_RiskRelated_RatingReview() throws IOException, InterruptedException {
			   
			 //Thread.sleep(5000);
			 
			 // Get the Compare the Note TextValue
			  CompareNotevalue("ParentNote","ChildNote");
			  Thread.sleep(3000);
	   
			 
		 }
	}

