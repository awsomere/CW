package com.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class RiskImplementation extends WrapperClass{
	
	public WebDriver driver;
	  String browser=null;
	  String ParentEntity = "ParentProductionNov5";
	  String ChildEntity = "ChildProductionNov5";
	  String GrantChildEntity = "GrantChildProductionNov5";
	  String GreatGrantChildEntity = "GreatGrantChildProductionNov5";
	  String GreatGreatGrantChildEntity = "Great-GreatGrantChildProductionNov5"; 

	  @Test(priority=180, enabled = true)
	   public void Navigate_ParentyEntity_RiskActionPlan() throws IOException, InterruptedException {
		   
		  Thread.sleep(5000);
		  		 
		//Click on Risk Action Plan Sub-module
	        assertTextLink("Risk Action Plan");
	        clickBylinktext("Risk Action Plan");
	        Reporter.log("Click on Risk Action Plan Sub-module | ");
	        Thread.sleep(5000);
	        Thread.sleep(5000);
	        Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
	        
	        // Select Parent Entity from drop down
		 	   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
			   Thread.sleep(5000);
			   
			  //Enter Created Entity Name in Search box
			   assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
			   sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ParentEntity);
			   //Reporter.log("Enter Created Entity Name in Search box | ");
			   Thread.sleep(3000);
			   //Thread.sleep(3000);
			   
			   //Select the Searched Entity
			   clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
			   //Reporter.log("Select the Searched Entity | ");
			   Thread.sleep(5000);
			   Thread.sleep(5000);
			   Thread.sleep(5000);
			   
	  }
	  
	  
	  @Test(priority=181, enabled = true)
	   public void Parent_CascadeIcon_RiskActionPlan() throws IOException, InterruptedException {	   		   
		  
		  
		  Thread.sleep(5000);
		  
	       /*//Click on Parent cascade Icon
	        assertTextXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
	       clickByXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
	       Thread.sleep(5000);
			   
	       //Click on Close button in Parent cascade Icon
	       assertTextXpath("html/body/div[5]/div/div/div[1]/button");
	       clickByXpath("html/body/div[5]/div/div/div[1]/button");
	       Thread.sleep(5000); */
	       
	  }
	  
	  @Test(priority=182, enabled = true)
	  public void Parent_ImplementationManager_RiskActionPlan() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
		   
	     // Get the Implementation Manager
		   ParentImplementationManagervalue("//*[@id='content']/tr[1]/td[5]/div/select");
		   Thread.sleep(5000);
		   
	  }
	  @Test(priority=183, enabled = true)
	  public void Parent_Duedate_RiskActionPlan() throws IOException, InterruptedException {
		  
		  Thread.sleep(3000);
	  
		   // Get the Duedate
		   ParentDueDatevalue("//*[@id='content']/tr[1]/td[7]/div/input");
		   Thread.sleep(5000); 
		   
	  }
	  
	  @Test(priority=184, enabled = true)
	  public void Parent_CompleteDate_RiskActionPlan() throws IOException, InterruptedException {
		  
		   
		   // Get the COmpleted Date
		   ParentCompleteDatevalue("//*[@id='content']/tr[1]/td[8]/div/input");
		   Thread.sleep(5000);  
		   
	  }
	  
	  @Test(priority=185, enabled = true)
	  public void Parent_PlannedStatus_RiskActionPlan() throws IOException, InterruptedException {
		  
		   // Get the Planned status 
		   ParentPlannedStatusvalue("//*[@id='content']/tr[1]/td[9]/div/select");
		   Thread.sleep(5000); 
		   
	  }
	  
	  @Test(priority=186, enabled = true)
	  public void Parent_CascadeIcon_RiskReconciliationList() throws IOException, InterruptedException {
		  
		   
		 //Select Risk Reconciliation List
	       clickBylinktext("Risk Reconciliation");
	       Reporter.log("Select Risk Reconciliation sub-Module | ");
	       Thread.sleep(5000);
	       Thread.sleep(3000);
	       
	     //Click on Parent cascade Icon
	     /*   assertTextXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
	       clickByXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
	       Thread.sleep(5000);
			   
	       //Click on Close button in Parent cascade Icon
	       assertTextXpath("html/body/div[4]/div/div/div[1]/button");
	       clickByXpath("html/body/div[4]/div/div/div[1]/button");*/
	       Thread.sleep(5000); 
	  }
	  
	  @Test(priority=187, enabled = true)
	  public void Parent_ReconciliationRiskLikelihood_RiskReconciliationList() throws IOException, InterruptedException {
		  
	    // Get the Reconciliation RiskLikelihood
		   ParentReconciliationRiskLikelihoodvalue("//*[@id='riskLikelihoodSelect']/cw-simple-risk-choices/div/button");
		   Thread.sleep(5000); 
		   
	  }
	  
	  @Test(priority=188, enabled = true)
	  public void Parent_ReconciliationRiskImpact_RiskReconciliationList() throws IOException, InterruptedException {
		  
		// Get the Reconciliation RiskImpact
		   ParentReconciliationRiskImpactvalue("//*[@id='riskImpactSelect']/cw-simple-risk-choices/div/button");
		   Thread.sleep(5000); 
		   
	  }
	       
	  @Test(priority=189, enabled = true)
	  public void Parent_ReconciliationRiskRating_RiskReconciliationList() throws IOException, InterruptedException {
		  
		  // Get the Reconciliation RiskRating
		   ParentReconciliationRiskRatingvalue("//*[@id='content']/tr[1]/td[17]/div/div");
		   Thread.sleep(5000); 
		   
		 //Click on Risk Action Plan Sub-module
	        assertTextLink("Risk Action Plan");
	        clickBylinktext("Risk Action Plan");
	        Reporter.log("Click on Risk Action Plan Sub-module | ");
	        Thread.sleep(5000);
	        Thread.sleep(5000);
		   
	  }
	  

	   @Test(priority=190, enabled = true)
	   public void Navigate_ChildEntity_RiskActionPlan() throws IOException, InterruptedException {
		   
	  Thread.sleep(3000);		 
	     		    
		   // Select Child Entity from drop down
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/a/span/span[1]");
		    Thread.sleep(5000);
		    
		    //Enter Created Entity Name in Search box
		    assertTextXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input");
		    sendvaluebyxpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[1]/input", ChildEntity);
		    //Reporter.log("Enter Created Entity Name in Search box | ");
		    Thread.sleep(3000);
			//Thread.sleep(3000);
		    
		    //Select the Searched Entity
		    clickByXpath("//*[@id='header']/div[2]/div/ul[2]/li[6]/ul/li[2]/a");
		    //Reporter.log("Select the Searched Entity | ");
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(5000);
		    Thread.sleep(5000);
			  Thread.sleep(5000);
			  Thread.sleep(5000);
			    Thread.sleep(5000);
			    Thread.sleep(5000);
			  Thread.sleep(5000);
	  }
	  
	  @Test(priority=191, enabled = true)
	   public void Child_CascadeIcon_RiskActionPlan() throws IOException, InterruptedException {	   		   
		  
			   
		       /*//Click on Child cascade Icon
		        assertTextXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
		       clickByXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
		       Thread.sleep(5000);
				   
		       //Click on Close button in Parent cascade Icon
		       assertTextXpath("html/body/div[5]/div/div/div[1]/button");
		       clickByXpath("html/body/div[5]/div/div/div[1]/button");
*/		       Thread.sleep(5000); 
	  }
	  
	  @Test(priority=192, enabled = true)
	  public void Child_ImplementationManager_RiskActionPlan() throws IOException, InterruptedException {
		  
			   
			   // Get the Implementation Manager
			   ChildImplementationManagervalue("//*[@id='content']/tr[1]/td[5]/div/select");
			   Thread.sleep(5000); 
			   
	  }
		
	  @Test(priority=193, enabled = true)
	  public void Child_DueDate_RiskActionPlan() throws IOException, InterruptedException {
		  
			   // Get the Duedate
			   ChildDueDatevalue("//*[@id='content']/tr[1]/td[7]/div/input");
			   Thread.sleep(5000); 
			   
	  }
	  
	  @Test(priority=194, enabled = true)
	  public void Child_CompleteDate_RiskActionPlan() throws IOException, InterruptedException {
		  
			   // Get the COmpleted Date
			   ChildCompleteDatevalue("//*[@id='content']/tr[1]/td[8]/div/input");
			   Thread.sleep(5000); 
			   
	  }
	  
	  @Test(priority=195, enabled = true)
	  public void Child_PlannedStatus_RiskActionPlan() throws IOException, InterruptedException {
		  
			   
			   // Get the Planned status 
			   ChildPlannedStatusvalue("//*[@id='content']/tr[1]/td[9]/div/select");
			   Thread.sleep(5000); 
			   
	  }
	  
	  @Test(priority=196, enabled = true)
	  public void Child_CascadeIcon_RiskReconciliationList() throws IOException, InterruptedException {
		  
			   
			 //Select Risk Reconciliation List
		      /* clickBylinktext("Risk Reconciliation");
		       Reporter.log("Select Risk Reconciliation sub-Module | ");
		       Thread.sleep(5000);
		       Thread.sleep(3000);
		       
		     //Click on Child cascade Icon
		        assertTextXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
		       clickByXpath("//*[@id='content']/tr[1]/td[2]/cw-cascade/span/span/button");
		       Thread.sleep(5000);
				   
		       //Click on Close button in Parent cascade Icon
		       assertTextXpath("html/body/div[4]/div/div/div[1]/button");
		       clickByXpath("html/body/div[4]/div/div/div[1]/button");*/
		       Thread.sleep(5000); 
		       
	  }
			
	  
	  @Test(priority=197, enabled = true)
	  public void Child_ReconciliationRiskLikelihood_RiskReconciliationList() throws IOException, InterruptedException {
		  
		  
		    // Get the Reconciliation RiskLikelihood
			   ChildReconciliationRiskLikelihoodvalue("//*[@id='riskLikelihoodSelect']/cw-simple-risk-choices/div/button");
			   Thread.sleep(5000); 
			   
	  }
		
	  @Test(priority=198, enabled = true)
	  public void Child_ReconciliationRiskImpact_RiskReconciliationList() throws IOException, InterruptedException {
		  
			// Get the Reconciliation RiskImpact
			   ChildReconciliationRiskImpactvalue("//*[@id='riskImpactSelect']/cw-simple-risk-choices/div/button");
			   Thread.sleep(5000); 
			   
	  }
	  
	  @Test(priority=199, enabled = true)
	  public void Child_ReconciliationRiskRating_RiskReconciliationList() throws IOException, InterruptedException {
		         
			  // Get the Reconciliation RiskRating
			   ChildReconciliationRiskRatingvalue("//*[@id='content']/tr[1]/td[17]/div/div");
			   Thread.sleep(2000); 
			  
			 //Click on Risk Response List Sub-module
		        assertTextLink("Risk Response List");
		        clickBylinktext("Risk Response List");
		        Reporter.log("Click on Risk Response List Sub-module | ");
		        Thread.sleep(5000);
		        Thread.sleep(3000); 
		        Thread.sleep(5000);
			    Thread.sleep(5000);
			    Thread.sleep(5000);
		        
	  }
		    	
	  @Test(priority=200, enabled = true)
	   public void Compare_RiskTreatmentType_RiskActionPlan() throws IOException, InterruptedException {
		  
			 //Compare RiskTreatmentTypevalue
			  CompareImplementationManagervalue("ParentImplementationManagervalue","ChildImplementationManagervalue");
			  Thread.sleep(2000);
			  
	  }
	  
	  @Test(priority=201, enabled = true)
	   public void Compare_DueDatevalue_RiskActionPlan() throws IOException, InterruptedException {
		  
			  
			//Compare Effectiveness value
		    CompareDueDatevalue("ParentDueDatevalue","ChildDueDatevalue");
		     Thread.sleep(2000);
		     
	  }
	  
	  @Test(priority=202, enabled = true)
	   public void Compare_CompleteDatevalue_RiskActionPlan() throws IOException, InterruptedException {
		  		     
		   //Compare EstimatedCost value 
		  CompareCompleteDatevalue("ParentCompleteDatevalue","ChildCompleteDatevalue");
		      Thread.sleep(2000);
		      
	  }
	  
	  @Test(priority=203, enabled = true)
	   public void Compare_PlannedStatusvalue_RiskActionPlan() throws IOException, InterruptedException {
		      
		    //Compare Feasibility value
		  ComparePlannedStatusvalue("ParentPlannedStatusvalue","ChildPlannedStatusvalue");
		      Thread.sleep(2000);
		      
	  }
	  
	  @Test(priority=204, enabled = true)
	   public void Compare_ReconciliationRiskLikelihood_RiskReconciliationList() throws IOException, InterruptedException {
		  		      		      
		    //Compare Action value   
		  CompareReconciliationRiskLikelihood("ParentReconciliationRiskLikelihoodvalue","ChildReconciliationRiskLikelihoodvalue");
		      Thread.sleep(2000);
		      
	  }
	  @Test(priority=205, enabled = true)
	   public void Compare_ReconciliationRiskImpact_RiskReconciliationList() throws IOException, InterruptedException {
		 		      
		    //Compare Note value
		  CompareReconciliationRiskImpactvalue("ParentReconciliationRiskImpactvalue","ChildReconciliationRiskImpactvalue");
		      Thread.sleep(2000);
		      
	  }
		     
	  
	  @Test(priority=206, enabled = true)
	   public void Compare_ReconciliationRiskRating_RiskReconciliationList() throws IOException, InterruptedException {
	
		    //Compare RiskLikelihood value
		  CompareReconciliationRiskRatingvalue("ParentReconciliationRiskRatingvalue","ChildReconciliationRiskRatingvalue");
		      Thread.sleep(2000);
	  
	  }


}
